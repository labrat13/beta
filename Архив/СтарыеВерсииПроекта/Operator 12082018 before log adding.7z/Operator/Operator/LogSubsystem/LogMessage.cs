﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operator.LogSubsystem
{
    /// <summary>
    /// NR-Текстовое собщение лога
    /// </summary>
    public class LogMessage
    {
        #region fields
        /// <summary>
        /// Код - аббревиатура сообщения
        /// </summary>
        private LogMessageCode m_MsgCode;

        /// <summary>
        /// Текст сообщения
        /// </summary>
        private string m_MsgText;

        /// <summary>
        /// Таймштамп сообщения
        /// </summary>
        private DateTime m_MsgTime;

#endregion
        /// <summary>
        /// NT-Конструктор по умолчанию
        /// </summary>
        public LogMessage()
        {
            m_MsgCode = LogMessageCode.Unknown;
            m_MsgText = String.Empty;
            m_MsgTime = DateTime.Now;
        }

        /// <summary>
        /// NT-Конструктор  с параметрами. Таймштамп создается автоматически.
        /// </summary>
        /// <param name="code">Код - аббревиатура сообщения</param>
        /// <param name="text">Текст сообщения</param>
        public LogMessage(LogMessageCode code, string text)
        {
            m_MsgCode = code;
            m_MsgText = text;
            m_MsgTime = DateTime.Now;
        }

        /// <summary>
        /// NR-Конструктор - парсер строки
        /// </summary>
        public LogMessage(string textline)
        {
            this.parse(textline);
        }

        #region properties
        /// <summary>
        /// Код - аббревиатура сообщения
        /// </summary>
        public LogMessageCode MsgCode
        {
            get { return m_MsgCode; }
            set { m_MsgCode = value; }
        }
        /// <summary>
        /// Текст сообщения
        /// </summary>
        public string MsgText
        {
            get { return m_MsgText; }
            set { m_MsgText = value; }
        }
        /// <summary>
        /// Таймштамп сообщения
        /// </summary>
        public DateTime MsgTime
        {
            get { return m_MsgTime; }
            set { m_MsgTime = value; }
        }

        #endregion

        /// <summary>
        /// NR-Собрать строку текста
        /// </summary>
        public String getAsString()
        {
            throw new System.NotImplementedException();//TODO: 
        }

        /// <summary>
        /// NR-Распарсить сообщение лога из текста
        /// </summary>
        /// <param name="text">Текст сообщения</param>
        private void parse(string text)
        {
            throw new System.NotImplementedException();//TODO: 
        }

        /// <summary>
        /// NT-Текст для отладки
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("{0};{1};{2}", this.m_MsgCode.ToString(), this.m_MsgText, this.m_MsgTime.ToShortTimeString());
        }
    }
}
