﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operator
{
    /// <summary>
    /// Собственно Оператор как движок 
    /// </summary>
    public class OperatorEngine
    {
        #region Fields
        /// <summary>
        /// Объект контроллера лога
        /// </summary>
        private LogSubsystem.LogController m_Log;

        #endregion

        #region Events
        /// <summary>
        /// NR-команда обратной связи
        /// </summary>
        public event System.EventHandler<Engine.TextEventArgs> BackCommandEvent;

        /// <summary>
        /// NR-Вывод на консоль
        /// </summary>
        public event System.EventHandler<Engine.TextEventArgs> ConsoleOutputEvent;

        /// <summary>
        /// NR-Вывод в строку состояния окна
        /// </summary>
        public event System.EventHandler<Engine.TextEventArgs> StateChangedEvent;

        #endregion

        /// <summary>
        /// NR-Конструктор
        /// </summary>
        public OperatorEngine()
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать движок здесь
        }

        #region Properties
        /// <summary>
        /// Объект контроллера лога
        /// </summary>
        public LogSubsystem.LogController Log
        {
            get { return m_Log; }
            set { m_Log = value; }
        }

        #endregion
        /// <summary>
        /// NR-Initialize engine
        /// </summary>
        public void Init()
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать движок здесь
        }

        /// <summary>
        /// NR-Finalize engine
        /// </summary>
        public void Close()
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать движок здесь
        }



        /// <summary>
        /// NR-Событие канала времени - секундные импульсы
        /// </summary>
        public void СобытиеСекунд()
        {
            //Этот код сейчас выполняется потоком таймера окна Оператор
            ;//throw new System.NotImplementedException();//TODO: Доделать канал секунд здесь
            this.m_Log.timer1Second();//передаем импульсы в лог для механизма таймаута файлов лога
            return;
        }

        /// <summary>
        /// NR-Событие канала хоткеев - название сработавшего хоткея
        /// </summary>
        public void СобытиеХоткей(String hotkeyName)
        {
            ; //throw new System.NotImplementedException();//TODO: Доделать канал хоткеев здесь
        }

        /// <summary>
        /// NR-Событие канала ввода пользователя - введенный текст
        /// </summary>
        public void СобытиеВводКонсоли(String text)
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать канал консоли здесь
        }

        /// <summary>
        /// NR-Событие канала лога - сообщение для лога
        /// </summary>
        public void СобытиеЗаписьВЛог(LogSubsystem.LogMessage msg)
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать лог здесь
        }

        /// <summary>
        /// NR-Событие управления исполнением процедуры
        /// </summary>
        public void СобытиеУправленияИсполнением(Engine.FlowControlCommandCode cmd)
        {
            //throw new System.NotImplementedException();//TODO: Доделать канал управления здесь
            //TODO: тут надо вызвать соответствующий метод Исполнителя
            //и исполнитель должен внести запись в лог, что поступила соответствующая команда.
            //Можно просто передать cmd команду Исполнителю отсюда.
            //Это первоочередная команда, она не должна ждать.
        }

        /// <summary>
        /// NR-Событие Запуск Оператор
        /// </summary>
        public void СобытиеЗапускаОператор()
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать движок здесь
        }

        /// <summary>
        /// NR-Событие Завершение Оператор
        /// </summary>
        public void СобытиеЗавершенияОператор()
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать движок здесь
        }

        /// <summary>
        /// NR-События питания и сеанса пользователя
        /// </summary>
        /// <remarks>
        /// События сеанса пользователя: 
        /// - событие блокировки сеанса
        /// - событие восстановления сеанса
        /// События питания:
        /// - подключение сети
        /// - отключение сети
        /// - изменение состояния питания
        /// - TODO: тут надо еще проработать значение событий питания
        /// </remarks>
        /// <param name="code">Код события смены состояния системы</param>
        public void СобытиеПитанияИСеанса(Engine.SystemStateCode code)
        {
            ;//throw new System.NotImplementedException();//TODO: Доделать код событий питания и сеанса пользователя здесь
        }
    }
}
