﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Operator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

#region *** Notify icon functions and handlers ***

        // Одиночный клик правой кнопкой мыши по иконке трея - показ контекстного меню иконки трея

        //TODO: Тут надо придумать целую систему из очереди сообщений для показа через балун.
        //Даже если их много, каждая должна ждать, пока предыдущая или истечет или будет кликнута пользователем.
        //Это асинхронный процесс, и я пока не могу предложить код для этого.
        //Но это явно должно быть выделено в отдельный класс, поскольку код сложный.
        
        /// <summary>
        /// Отрицательная реакция на сообщение
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_BalloonTipClosed(object sender, EventArgs e)
        {
            //Это событие генерируется и при закрытии балуна нажатием на крестик, и по истечении таймаута балуна.
            //Тут надо перейти к показу балуна со следующим сообщением, если он есть в очереди.
            //Но я знаю, что код здесь выполняется асинхронно и не блокирует основной процесс.
        }
        /// <summary>
        /// Положительная реакция на сообщение
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {
            //Тут должна быть запущена некоторая процедура, которая зависит от содержания сообщения.
            //А остальные сообщения в это время должны ждать, пока пользователь не закончит эту работу.
            //То есть, это не асинхронные события, а прямой вызов функции-обработчика.
            //А потом надо перейти к показу балуна со следующим сообщением, если он есть в очереди.
            //Но я знаю, что код здесь выполняется асинхронно и не блокирует основной процесс.

            //Сейчас просто восстанавливаем окно из трея, чтобы посмотреть что произошло в окне.
            NotifyFormExpand();
        }
        /// <summary>
        /// Двойной клик любой кнопкой мыши - разворачивание окна из трея
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            NotifyFormExpand();
        }
        /// <summary>
        /// Действия при свертывании окна в трей
        /// </summary>
        private void NotifyFormCollapse()
        {
            notifyIcon1.Visible = true;
            notifyIcon1.ShowBalloonTip(3000);
            this.ShowInTaskbar = false;
        }
        /// <summary>
        /// Действия при восстановлении окна из трея
        /// </summary>
        private void NotifyFormExpand()
        {
            Show();
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            notifyIcon1.Visible = false;
        }
        /// <summary>
        /// Одиночный клик правой кнопкой мыши - показ контекстного меню автоматически
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            ;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            //Свернуть окно в трей
            if (this.WindowState == FormWindowState.Minimized)
            {
                NotifyFormCollapse();
            }
        }


        /// <summary>
        /// Пункт Показать из контекстного меню трея
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NotifyFormExpand();
        }
        /// <summary>
        /// Пункт Закрыть приложение из контекстного меню трея
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ShowBaloon(String Title, String text, System.Windows.Forms.ToolTipIcon icon, int time)
        {
            //Этот вызов не изменяет установленные ранее тексты и иконку
            //Но он не показывает ничего, если notifyIcon невидим
            notifyIcon1.ShowBalloonTip(time, Title, text, icon);
            return;
        }

#endregion










    }
}
