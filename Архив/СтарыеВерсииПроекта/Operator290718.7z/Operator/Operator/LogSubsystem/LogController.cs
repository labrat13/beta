﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Operator.LogSubsystem
{
    /// <summary>
    /// NR-Менеджер лога
    /// </summary>
    public class LogController
    {
        //TODO: Доделать класс здесь
        //тут нужно управлять текущим сеансом лога
        //нужно отделять его от других сеансов лога. Поэтому нужен ИдентификаторСеансаЛога и класс СеансЛога.
        //Хотя читать и перебирать все записи лога не нужно, это проще, чем Тапп.
        //Но нужно опознавать другие сеансы лога.

        //Для многопоточной схемы этот класс вообще можно превратить в циклический исполнитель команд.
        //Команды буферизовать в списке, поток лога их выбирает и исполняет А если команд нет - спит.
        //Тогда еще нужен канал обраной связи для сообщений об ошибках в логе. 
        //Хотя, если ошибка произойдет, то, наверно, надо закрывать приложение? 

        /// <summary>
        /// Константа версия подсистемы лога. 
        /// Хранится здесь как в специальном месте для констант подсистемы лога.
        /// </summary>
        public const string СтрокаВерсииПодсистемыЛога = "1.0.0.0";
        /// <summary>
        /// Объект версии подсистемы лога - держим постоянно тут, чтобы проверять на совместимость 
        /// все места, где используется версия подсистемы лога. 
        /// </summary>
        internal OperatorVersion m_ВерсияПодсистемыЛога;
        /// <summary>
        /// Значение из НастройкиСолюшена, здесь кешируется.
        /// </summary>
        private string m_КаталогЛоговСолюшена;
        /// <summary>
        /// Счетчик таймера для файлов лога
        /// </summary>
        private int m_timerCounter;
        /// <summary>
        /// Предел таймера для файлов лога
        /// </summary>
        private int m_logTimeoutInterval;

        /// <summary>
        /// NR-Добавлено сообщение основного лога
        /// </summary>
        public event EventHandler<LogMessageAddedEventArgs> MessageAddedEvent;

        /// <summary>
        /// NR-Конструктор
        /// </summary>
        public LogController()
        {
            throw new System.NotImplementedException();

            m_timerCounter = 0;//сбросить счетчик файлов лога
            m_logTimeoutInterval = 60;//Типично 1 минута до закрытия файлов лога. TODO: Значение надо загружать из настроек оператора.
        }

        //Можно просто получать это значение из объекта НастройкиСолюшена в Движок
        
        /// <summary>
        /// NR-Начать работу и Открыть сеанс лога
        /// </summary>
        /// <param name="sett">настройки</param>
        public void Open(OperatorSettings sett)
        {
            throw new System.NotImplementedException();//TODO: add code here
        }

        /// <summary>
        /// NR-Завершить работу подсистемы лога
        /// </summary>
        public void Close()
        {
            throw new System.NotImplementedException();//TODO: add code here
        }

        /// <summary>
        /// NR-Добавить нераспознанную команду
        /// </summary>
        /// <param name="text">Текст команды</param>
        public void AddUnrecognizedCommand(string text)
        {
            throw new System.NotImplementedException();//TODO: add code here
            this.resetTimeCounter();//сбросить счетчик таймаута закрытия файлов
        }

        /// <summary>
        /// NR-Добавить ввод-вывод с консоли
        /// </summary>
        /// <param name="input">Направление: ввод с консоли</param>
        /// <param name="line">строка текста</param>
        public void AddConsoleInputOutput(bool input, string line)
        {
            throw new System.NotImplementedException();//TODO: add code here

            this.resetTimeCounter();//сбросить счетчик таймаута закрытия файлов
        }

        /// <summary>
        /// NR-Добавить сообщение в общий лог
        /// </summary>
        /// <param name="msg">Объект сообщения лога</param>
        public void AddGeneralMessage(LogSubsystem.LogMessage msg)
        {
            throw new System.NotImplementedException();//TODO: add code here

            this.resetTimeCounter();//сбросить счетчик таймаута закрытия файлов
        }

        /// <summary>
        /// NR-
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return base.ToString();//TODO: add code here
        }

        #region File Timeout functions
        /// <summary>
        /// NT-Сбросить счетчик таймера файлов лога
        /// </summary>
        private void resetTimeCounter()
        {
            //Interlocked. - нет функции для обнуления счетчика
            this.m_timerCounter = 0;
            return;
        }

        /// <summary>
        /// NR-Вход событий от таймера по 1с для закрытия файлов лога по таймауту
        /// </summary>
        public void timer1Second()
        {
            //Этот код исполняется только потоком окна 

            //TODO: тут надо буферизовать команду закрытия файлов для разделения потоков.
            //можно просто флаг выставить, что поток, обслуживающий лог, должен закрыть файлы лога.
            //Сейчас же эту работу делает поток таймера главного окна. Это неправильно.
            //Но эту команду надо передавать событием, чтобы поток лога мог спать на WaitHandle.

            m_timerCounter++;
            if (m_timerCounter >= m_logTimeoutInterval)
            {
                //Закрыть файлы лога, поскольку таймаут вышел
                CloseLogFiles();
                //Счетчик не сбрасываем, пусть считает дальше. 
            }
            return;
        }
        /// <summary>
        /// NR-Закрыть все файлы лога по таймауту
        /// </summary>
        private void CloseLogFiles()
        {
            throw new NotImplementedException();
        }
        #endregion

    }
}
