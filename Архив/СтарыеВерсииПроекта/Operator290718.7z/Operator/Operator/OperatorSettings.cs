﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Operator
{
    /// <summary>
    /// Настройки приложения Оператор
    /// </summary>
    public class OperatorSettings
    {

        #region fields
        /// <summary>
        /// Путь к папке лога относительно каталога с приложением Оператор, или абсолютный путь файла.
        /// </summary>
        /// <remarks>
        /// Абсолютный путь содержит : .
        /// Относительный путь удобен для переноски Оператора - где распаковал, оттуда и работает.
        /// Относительный путь начинается с /
        /// </remarks>
        private string m_logFolderPath;

        /// <summary>
        /// таймаут бездействия лога, в секундах, до закрытия файлов лога.
        /// </summary>
        /// <remarks>
        /// В миллисекундах нельзя - код считает секунды от таймера.
        /// </remarks>
        private int m_logTimeoff;

        /// <summary>
        /// Версия Оператор, в которой был создан лог.
        /// </summary>
        private OperatorVersion m_Version;


        #endregion

        public OperatorSettings()
        {
            throw new System.NotImplementedException();
        }

        #region Properties
        /// <summary>
        /// Путь к папке лога относительно каталога с приложением Оператор, или абсолютный путь файла.
        /// </summary>
        /// <remarks>
        /// Абсолютный путь содержит : .
        /// Относительный путь удобен для переноски Оператора - где распаковал, оттуда и работает.
        /// Относительный путь начинается с /
        /// </remarks>
        public string LogFolderPath
        {
            get { return m_logFolderPath; }
            set { m_logFolderPath = value; }
        }

        /// <summary>
        /// таймаут бездействия лога, в миллисекундах, до закрытия файлов лога.
        /// </summary>
        public int LogTimeoff
        {
            get { return m_logTimeoff; }
            set { m_logTimeoff = value; }
        }

        /// <summary>
        /// Версия Оператор, в которой был создан файл настроек.
        /// </summary>
        public OperatorVersion Version
        {
            get { return m_Version; }
            set { m_Version = value; }
        }

        #endregion

        
        
        /// <summary>
        /// NR-Загрузить настройки из файла
        /// </summary>
        /// <param name="filePath"></param>
        public void Load(String filePath)
        {
            //TODO: add code here
            
            //TODO: проверить версию Оператора в загружаемом файле лога.
            //Если не совпадает, выдать исключение.
            return;
        }
        /// <summary>
        /// NR-Сохранить настройки в файл
        /// </summary>
        /// <param name="filePath"></param>
        public void Save(String filePath)
        {
            //TODO: add code here

            return;
        }
        /// <summary>
        /// NR-Установить значения по умолчанию
        /// </summary>
        public void SetDefault()
        {
            //TODO: add code here
            this.m_logFolderPath = "//Log";//относительно каталога Оператор
            this.m_logTimeoff = 60; //60 секунд таймаут
            this.m_Version = new OperatorVersion(Assembly.GetExecutingAssembly().GetName().Version);
            return;
        }

        public override string ToString()
        {
            return base.ToString();
        }

    }
}
