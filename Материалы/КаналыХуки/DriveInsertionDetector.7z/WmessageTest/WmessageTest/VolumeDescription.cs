﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace WmessageTest
{
    /// <summary>
    /// Класс представляет описание тома, полностью взятое из объекта DriveInfo
    /// </summary>
    /// <remarks>
    /// Объект DriveInfo не сохраняет данные о диске, который уже удален. 
    /// А мне надо сохранять, чтобы приложение знало, какой диск удален.
    /// Поэтому все данные безопасно копируются в собственные переменные класса.
    /// </remarks>
    public class VolumeDescription
    {
        private long m_AvailableFreeSpace;
        
        private string m_DriveFormat;

        private DriveType m_DriveType;

        private bool m_isReady;

        private string m_Name;

        private string m_VolumeLabel;

        private long m_TotalFreeSpace;

        private long m_TotalSize;

        private string m_VolumePath;

        /// <summary>
        /// Путь к тому
        /// </summary>
        public string VolumePath
        {
            get { return m_VolumePath; }
            set { m_VolumePath = value; }
        }
        /// <summary>
        /// Доступное свободное место на томе
        /// </summary>
        public long AvailableFreeSpace
        {
            get { return m_AvailableFreeSpace; }
            set { m_AvailableFreeSpace = value; }
        }
        /// <summary>
        /// Название файловой системы тома
        /// </summary>
        public string DriveFormat
        {
            get { return m_DriveFormat; }
            set { m_DriveFormat = value; }
        }
        /// <summary>
        /// Енум тип тома: CD-ROM итп.
        /// </summary>
        public DriveType DriveType
        {
            get { return m_DriveType; }
            set { m_DriveType = value; }
        }
        /// <summary>
        /// Флаг, что том доступен для использования
        /// </summary>
        public bool IsReady
        {
            get { return m_isReady; }
            set { m_isReady = value; }
        }

        /// <summary>
        /// Общий размер тома
        /// </summary>
        public long TotalSize
        {
            get { return m_TotalSize; }
            set { m_TotalSize = value; }
        }
         /// <summary>
        /// Полное свободное место на томе
        /// </summary>
        public long TotalFreeSpace
        {
            get { return m_TotalFreeSpace; }
            set { m_TotalFreeSpace = value; }
        }
        /// <summary>
        /// Метка тома
        /// </summary>
        public string VolumeLabel
        {
            get { return m_VolumeLabel; }
            set { m_VolumeLabel = value; }
        }
        /// <summary>
        /// Имя тома
        /// </summary>
        public string Name
        {
            get { return m_Name; }
            set { m_Name = value; }
        }

        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="path">Путь к тому</param>
        public VolumeDescription(string path)
        {
            DriveInfo di = new DriveInfo(path);
            this.m_VolumePath = path;
            //сюда все полезные свойства скопировать из DriveInfo
            //но они там могут вызывать исключения при чтении, 
            //поэтому надо изолировать здесь код от этих исключений.
            //При исключении тут будут записываться значения ошибки (-1 или пустая строка, итд)
            this.m_AvailableFreeSpace = safeGet1(di);
            this.m_DriveFormat = safeGet2(di);
            this.m_DriveType = safeGet3(di);
            this.m_isReady = safeGet4(di);
            this.m_Name = safeGet5(di);
            this.m_TotalFreeSpace = safeGet6(di);
            this.m_TotalSize = safeGet7(di);
            this.m_VolumeLabel = safeGet8(di);

            return;
        }

        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private string safeGet8(DriveInfo di)
        {
            string result = "";
            try
            {
                result = di.VolumeLabel;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }
        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private long safeGet7(DriveInfo di)
        {
            long result = -1;
            try
            {
                result = di.TotalSize;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }
        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private long safeGet6(DriveInfo di)
        {
            long result = -1;
            try
            {
                result = di.TotalFreeSpace;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }
        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private string safeGet5(DriveInfo di)
        {
            string result = "";
            try
            {
                result = di.Name;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }


        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private bool safeGet4(DriveInfo di)
        {
            bool result = false;
            try
            {
                result = di.IsReady;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }
        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private DriveType safeGet3(DriveInfo di)
        {
            DriveType result = DriveType.Unknown;
            try
            {
                result = di.DriveType;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }
        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private string safeGet2(DriveInfo di)
        {
            string result = "";
            try
            {
                result = di.DriveFormat;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }
        /// <summary>
        /// Вспомогательная функция изоляции исключений при доступе к свойствам тома
        /// </summary>
        /// <param name="di">Объект DriveInfo</param>
        /// <returns>Значение соответствующего поля или значение ошибки (-1, String.Empty)</returns>
        private long safeGet1(DriveInfo di)
        {
            long result = -1;
            try
            {
                result = di.AvailableFreeSpace;
            }
            catch (Exception)
            {
                ;
            }
            return result;
        }


        public override string ToString()
        {
            return String.Format("{0};{1};{2}", this.m_VolumeLabel, this.m_DriveFormat, this.m_DriveType.ToString());
        }

    }
}
