﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WmessageTest
{
    


    public class VolumeChangedEventArgs : EventArgs
    {
        private bool m_VolumeAdded;

        private VolumeDescription m_Volume;

        //public VolumeChangedEventArgs()
        //{

        //}

        public VolumeChangedEventArgs(bool volumeAdded, VolumeDescription descr)
        {
            m_VolumeAdded = volumeAdded;
            m_Volume = descr;
        }


        /// <summary>
        /// Флаг, Труе - том добавлен, Фальш - том удален
        /// </summary>
        public bool VolumeAdded
        {
            get { return m_VolumeAdded; }
        }
        /// <summary>
        /// Объект свойства тома
        /// </summary>
        public VolumeDescription Volume
        {
            get { return m_Volume; }
        }

    }
}
