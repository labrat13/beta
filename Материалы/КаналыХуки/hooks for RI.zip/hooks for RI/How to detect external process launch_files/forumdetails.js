﻿
Forums.ForumDetails =
{
    wireForumDetailLinks: function () {
        var timer = null;
        var timerStep = 1000;
        $.each($('.forumItem,.forumBreadcrumb').not('.selectAllCheckboxContainer'), function () {
            if ($(this).parents('#allCategoryPopupContainer:first').length == 0) {
                var detailstip = $(this).find('.forumDetailsTip');
                $(this).hover(function (event) {
                    event.stopPropagation();
                    $('.forumDetailsTip').hide();
                    $(this).data('hover', 1);
                    if (detailstip.children().size() == 0) {
                        timer = setTimeout(function() {}, timerStep);
                        Forums.ForumDetails.showForumDetails($(this), detailstip, timerStep - timer);
                    } else {
                        timer = setTimeout(function() { detailstip && detailstip.show(); }, timerStep);
                    }
                }, function (event) {
                    event.stopPropagation();
                    $(this).data('hover', 0);
                    detailstip && detailstip.hide();
                    if (timer) {
                        clearTimeout(timer);
                    }
                });
            }
        });
    },
    
    showForumDetails: function (forumDetailsParent, forumDetailsTip, timeRemainingBeforeLoad) {
        var forumDetailsUrl = forumDetailsParent.data('forumdetailsurl');
        $.getJSON(forumDetailsUrl,
            function (data) {
                if (!$(forumDetailsTip).data('details_loaded')) {
                    $(forumDetailsTip).data('details_loaded', true);
                    var detailsPopupContent = Forums.ForumDetails.loadForumDetails(data);
                    $(forumDetailsTip).empty().append(detailsPopupContent);
                    setTimeout(function () { if ($(forumDetailsParent).data('hover')) { forumDetailsTip && forumDetailsTip.show(); } }, timeRemainingBeforeLoad);
                }
            })
            .fail(
                function (jqXHR, textStatus, err) {
                    forumDetailsParent.next('.forumDetailsTip').html('Error: ' + err);
                }
            );
    },

    loadForumDetails: function(data) {
        var val = data;
        var forumDetailsId = 'forumDetailsTip_' + val.Name;

        var currentForumDetails = $('#' + forumDetailsId + ':first');
        if (currentForumDetails.length == 1) return currentForumDetails;
        
        var forumDetailsTemplate = $('#forumDetailsTemplate:first');
        var newForumDetails = $(forumDetailsTemplate).clone();

        $(newForumDetails).attr('id', forumDetailsId);
        $(newForumDetails).children('h3.header').prepend(val.DisplayName);
        $(newForumDetails).children('div.content').html(val.Description);
        $(newForumDetails).find('img.rss').parent().attr('href', val.RSSUrl);
        $(newForumDetails).find('.announcements span').text(val.AnnouncementsText + ': ' + val.AnnouncementCount).addClass("bold");
        if (val.ShowManageForums) {
            var manageForumsSection = $(newForumDetails).find('.manageForumSection');
            $(manageForumsSection).find('.manageForumLink').attr('href', val.ManageForumUrl).text(val.ManageForumsText);
            $(manageForumsSection).find('.manageRolesLink').attr('href', val.ManageRolesUrl).text(val.ManageRolesText);
            $(manageForumsSection).find('.addAnnouncementLink').attr('href', val.AddAnnouncementUrl).text(val.AddAnnouncementText);
            $(manageForumsSection).show();
        }

        var favoriteUnfavoriteLink = $(newForumDetails).find('a.addRemoveForum');
        $(favoriteUnfavoriteLink).attr('href', val.FavoriteUrl);
        if (val.HasFavoritePermission) {
            $(favoriteUnfavoriteLink).attr('title', val.AddToMyForumsText).attr('name', 'favorite').attr('data-reverseText', val.RemoveFromMyForumsText).attr('data-reversename', 'unfavorite').text(val.AddToMyForumsText);
        } else if (val.HasUnFavoritePermission === true) {
            $(favoriteUnfavoriteLink).attr('title', val.RemoveFromMyForumsText).attr('name', 'unfavorite').attr('data-reverseText', val.AddToMyForumsText).attr('data-reversename', 'favorite').text(val.RemoveFromMyForumsText);
        }

        var favoriteUnfavoriteLinkName = $(favoriteUnfavoriteLink).attr('name');
        if (typeof favoriteUnfavoriteLinkName !== 'undefined' && favoriteUnfavoriteLinkName !== false) {
            $(favoriteUnfavoriteLink).show();
        }

        $(newForumDetails).find("a.addRemoveForum").click(function(evt) {
            var isFavorite = $(this).attr('name') === 'favorite';
            var link = $(this);

            $.post($(link).attr("href"), { isFavorited: isFavorite }, function(results) {
                if (results.success) {
                    var currentText = $(link).text();
                    var currentName = $(link).attr('name');
                    var reverseText = $(link).attr('data-reverseText');
                    var reverseName = $(link).attr('data-reversename');
                    $(link).attr('title', reverseText).attr('name', reverseName).attr('data-reverseText', currentText).attr('data-reversename', currentName);
                    $(link).text(reverseText);
                }
            }, "json");
            return false;
        });
        
        return newForumDetails;

    }
}