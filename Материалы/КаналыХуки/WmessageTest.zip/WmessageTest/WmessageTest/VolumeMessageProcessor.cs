﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;

namespace WmessageTest
{
    //TODO: 
    //Из-за того, что класс статический, и инициализируется при первом сигнальном сообщении, 
    //вставка флешки показывает все имеющиеся диски, а не только флешку.
    //Надо инициализировать словарь отдельно, при запуске программы, а не как сейчас.

    //И класс драйвинфо неправильно использован - тут надо собственный класс ставить, а то 
    //драйвинфо не сохраняет данные о диске, который уже удален. 
    //Надо сохранять, чтобы приложение знало, какой диск удален.


    public static class VolumeMessageProcessor
    {
        /// <summary>
        /// A device or piece of media has been inserted and is now available.
        /// </summary>
        private const int DBT_DEVICEARRIVAL = 0x8000;
        /// <summary>
        /// A device or piece of media has been removed.
        /// </summary>
        private const int DBT_DEVICEREMOVECOMPLETE = 0x8004;
        ///// <summary>
        ///// A device has been added to or removed from the system.
        ///// </summary>
        //private const int DBT_DEVNODES_CHANGED = 0x0007;
        /// <summary>
        /// код сообщения окну
        /// </summary>
        private const int WM_DEVICECHANGE = 0x0219;

        /// <summary>
        /// Внутренний список томов для выявления новых или отсутствующих
        /// </summary>
        internal static Dictionary<string, VolumeDescription> internalVolumeDictionary = null;



        internal static void ProcessMessage(System.Windows.Forms.Message m)
        {
            //инициализировать весь движок
            if (internalVolumeDictionary == null)
                initializeEngine();
            //тут обработать сообщение
            if (m.Msg == WM_DEVICECHANGE)
            {
                int w = m.WParam.ToInt32();
                if ((w == DBT_DEVICEARRIVAL) || (w == DBT_DEVICEREMOVECOMPLETE))
                {
                    checkExistingVolumes();
                }
            }
            return;
        }



        /// <summary>
        /// Тут инициализировать все переменные менеджера для первой работы
        /// </summary>
        private static void initializeEngine()
        {
            internalVolumeDictionary = new Dictionary<string, VolumeDescription>();
        }
        /// <summary>
        /// RT-Проверить здесь все существующие тома и сгенерировать события для новых и отсутствующих томов
        /// </summary>
        private static void checkExistingVolumes()
        {
            //получить существующие тома дисков
            
            string[] sar = Environment.GetLogicalDrives();

            //проверять и отсутствующие в словаре, и отсутствующие в списке
            List<String> list1 = new List<string>(internalVolumeDictionary.Keys);//содержимое словаря
            List<String> list2 = new List<string>(sar);//содержимое списка томов
            List<String> listR1 = new List<string>();//отсутствующие в словаре но присутствующие в списке томов
            List<String> listR2 = new List<string>();//отсутствующие в списке томов, но присутствующие в словаре
            CompareTwoLists(list1, list2, listR1, listR2, null);

            //1 присутствующие в словаре но отсутствующие в списке - удалить из словаря
            foreach (String s in listR2)
            {
                VolumeDescription v = internalVolumeDictionary[s];
                internalVolumeDictionary.Remove(s);
                OnVolumeChanged(false, v);//отсылаем сообщение о отключении тома
            }
            //2 отсутствующие в словаре но присутствующие в списке - найти и добавить в словарь
            foreach (String ss in listR1)
            {
                VolumeDescription v = new VolumeDescription(ss);
                internalVolumeDictionary.Add(ss, v);
                OnVolumeChanged(true, v);//отсылаем сообщение о подключении тома
            }
            return; //вроде бы все сделали
        }

        private static void OnVolumeChanged(bool p, VolumeDescription v)
        {
            ;//TODO: add code here
        }

        /// <summary>
        /// RT-Библиотечно-подобная функция для сравнения двух списков строк. Возвращает разные и одинаковые строки из этих списков
        /// </summary>
        /// <param name="list1">Первый исходный набор строк</param>
        /// <param name="list2">Второй исходный набор строк</param>
        /// <param name="listR1">Список строк, отсутствующих в первом списке. Передайте Null, если не нужен.</param>
        /// <param name="listR2">Список строк, отсутствующих во втором списке. Передайте Null, если не нужен.</param>
        /// <param name="listE">Список строк присутствующих в обоих списках. Передайте Null, если не нужен.</param>
        private static void CompareTwoLists(List<string> list1, List<string> list2, List<string> listR1, List<string> listR2, List<string> listE)
        {
            if ((listE != null) || (listR2 != null)) //Оптимизация: если выходной список не требуется, то и не зачем считать вообще
            {
                for (int i = 0; i < list1.Count; i++)
                {
                    String s1 = list1[i];
                    if (list2.Contains(s1))
                    {
                        //это общая строка, добавить ее в список общих строк, если он доступен
                        if (listE != null) //а тут надо проверять, так как цикл общий с listR2
                            listE.Add(s1);
                    }
                    else
                    {
                        //это разностная строка, добавить ее в список отсутствующих во втором списке, если он доступен
                        if (listR2 != null) //а тут надо проверять, так как цикл общий с listE
                            listR2.Add(s1);

                    }
                }
            }
            //теперь наоборот, но уже в общий список строки не добавляем
            if (listR1 != null) //Оптимизация: если выходной список не требуется, то и не зачем считать вообще
            {
                for (int i = 0; i < list2.Count; i++)
                {
                    String s2 = list2[i];
                    if (!list1.Contains(s2))
                    {
                        //это разностная строка, добавить ее в список отсутствующих в первом списке, если он доступен
                        //if (listR1 != null) уже проверено перед началом цикла
                            listR1.Add(s2);
                    }
                }
            }
            return;
        }

    }
}
