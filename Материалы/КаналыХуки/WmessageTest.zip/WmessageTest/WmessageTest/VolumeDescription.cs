﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace WmessageTest
{
    public class VolumeDescription
    {
        public VolumeDescription(string path)
        {
            DriveInfo di = new DriveInfo(path);
            //TODO: add code here - сюда все полезные свойства скопировать из DriveInfo
        }
    }
}
