﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WmessageTest
{
    public partial class Form1 : Form
    {
        StreamWriter log;
        public Form1()
        {
            InitializeComponent();
            log = new StreamWriter("C:\\MessageDump.csv", false, Encoding.GetEncoding(1251));
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            //write  messages to dump
            string s = String.Format("{0};{1};{2};{3};", m.HWnd.ToInt64(), MsgToText(m.Msg), m.WParam.ToInt64(),m.LParam.ToInt64());
            if(log != null)
                log.WriteLine(s);
            //test volume event processor
            VolumeMessageProcessor.ProcessMessage(m);
        }

        private string MsgToText(int p)
        {
            String result = p.ToString();
            try
            {
                //конвертируем число в енум и потом в название енума
                string s = Enum.GetName(typeof(WindowsMessage), p);
                if (!String.IsNullOrEmpty(s))
                    result = s;
            }
            catch
            {
                //не удалось конвертировать число в енум
                ;
            }
            return result;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            log.Flush();
            log.Close();
            log = null;
        }
    }
}
/* приложение получает сообщения при вставке и извлечении флешки - как вручную, так и программно извлекать.
 * Но также и при подключении сетевых дисков, дисководов, сиди-дисков, разных устройств и вообще, при монтировании тома
 * Так что целесообразно просто ловить события монтирования и демонтирования томов для моих целей, а потом уже составлять список новых или отсутствующих томов и соответственно генерировать свои события.
 * 
460472	WM_DEVICECHANGE	7	0
460472	WM_DEVICECHANGE	7	0
460472	WM_DEVICECHANGE	7	0
460472	WM_DEVICECHANGE	32772	65858228

7 = DBT_DEVNODES_CHANGED - A device has been added to or removed from the system.
32772 = 0X8004 = DBT_DEVICEREMOVECOMPLETE - A device or piece of media has been removed.
65858228 = УАЗАТЕЛЬ НА СТРУКТУРУ ДАННЫХ DEV_BROADCAST_HDR Structure
32768 = 0х8000 = DBT_DEVICEARRIVAL - A device or piece of media has been inserted and is now available.
 

 * еЩЕ ОДИН ОПЫТ
 * вставка флешки
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	32768	1241692
722590	WM_DEVICECHANGE	7	0

 * отключение флешки через иконку таскбара
 * 
 * 722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	32772	1241692

 * вставка флешки
 * 722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	32768	1241692
722590	WM_DEVICECHANGE	7	0

 * извлечение флешки вручную 
 * 722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	7	0
722590	WM_DEVICECHANGE	32772	1241692

 * Выводы:
 * Извлечение флешки поисходит однотипно, заканчивается сообщением 
 * 722590	WM_DEVICECHANGE	32772	1241692
 * 
 * вставка флешки происходит с разным количеством сообщений
 * 722590	WM_DEVICECHANGE	7	0
 * затем идет сообщение
 * 722590	WM_DEVICECHANGE	32768	1241692
 * затем иногда идет 
 * 722590	WM_DEVICECHANGE	7	0
*/

/* тест 2 подключение плеера
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241692   - A device or piece of media has been removed.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241692  - A device or piece of media has been removed.

 * подключение смартфона
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241692   - A device or piece of media has been removed.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241692   - A device or piece of media has been removed.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0

 * отключение смартфона
 * 131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241692 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	49615	7	66
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241692   - A device or piece of media has been removed.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32768	1241684 - A device or piece of media has been inserted and is now available.
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241684   - A device or piece of media has been removed.

 * 
 * отключение плеера
 * 131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	7	0
131874	WM_DEVICECHANGE	32772	1241692   - A device or piece of media has been removed.

 * 
 * 
*/