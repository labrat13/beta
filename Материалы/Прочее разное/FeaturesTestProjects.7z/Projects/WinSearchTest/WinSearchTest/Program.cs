﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace WinSearchTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var connection = new OleDbConnection(@"Provider=Search.CollatorDSO;Extended Properties=""Application=Windows""");

            // File name search (case insensitive), also searches sub directories
            var query1 = @"SELECT System.ItemName FROM SystemIndex " +
                        @"WHERE scope ='file:C:/' AND System.ItemName LIKE '%Test%'";

            // File name search (case insensitive), does not search sub directories
            var query2 = @"SELECT System.ItemName FROM SystemIndex " +
                        @"WHERE directory = 'file:C:/' AND System.ItemName LIKE '%Test%' ";

            // Folder name search (case insensitive)
            var query3 = @"SELECT System.ItemName FROM SystemIndex " +
                        @"WHERE scope = 'file:C:/' AND System.ItemType = 'Directory' AND System.Itemname LIKE '%Test%' ";

            // Folder name search (case insensitive), does not search sub directories
            var query4 = @"SELECT System.ItemName FROM SystemIndex " +
                        @"WHERE directory = 'file:C:/' AND System.ItemType = 'Directory' AND System.Itemname LIKE '%Test%' ";

            connection.Open();

            var command = new OleDbCommand(query4, connection);

            using (var r = command.ExecuteReader())
            {
                while (r.Read())
                {
                    Console.WriteLine(r[0]);
                }
            }

            connection.Close();

            Console.ReadKey();

        }
    }
}
