﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;


namespace RecycleBinTest
{

    /// <summary>
    /// Create an structure which will store recycle query information.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    public struct SHQUERYRBINFO
    {
        public Int32 cbSize;
        public UInt64 i64Size;
        public UInt64 i64NumItems;
    }

    enum RecycleFlags : int
    {
        SHERB_NOCONFIRMATION = 0x00000001,          //No confirmation dialog will open while emptying recycle bin.
        SHERB_NOPROGRESSUI = 0x00000002,            //No progress tracking window appears while emptying recycle bin.
        SHERB_NOSOUND = 0x00000004                  //No sound whent while emptying recycle bin.
    }


    class Program
    {

        //Call SHQueryRecycleBin() method of shell32 dll to query file size and file number in recycle bin.
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        public static extern int SHQueryRecycleBin([MarshalAs(UnmanagedType.LPTStr)] string pszRootPath, ref SHQUERYRBINFO pSHQueryRBInfo);


        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        static extern uint SHEmptyRecycleBin(IntPtr hwnd, string pszRootPath, RecycleFlags dwFlags);



        static void Main(string[] args)
        {

            ClearRecycleBin();
        }

        /// <summary>
        /// Это очень просто и работает на ХР под админом.
        /// </summary>
        static void Test1()
        {
            SHQUERYRBINFO bb_Query = new SHQUERYRBINFO();
            bb_Query.cbSize = Marshal.SizeOf(bb_Query.GetType());
            SHQueryRecycleBin(null, ref bb_Query);
            Console.WriteLine("CB Size  :  " + bb_Query.cbSize);
            Console.WriteLine("File Size   :  " + bb_Query.i64Size);  //Call i64Size member of structure which will return size of recycle bin.
            Console.WriteLine("Number of items   :  " + bb_Query.i64NumItems);  //Call i64NumItems member of structure which will return file number in recycle bin.

            emptyRecycleBin();   //call empty recycle bin which will empty ur recycle bin.
        }

        /// <summary>
        /// This method will empty recycle bin without prompting confirmation message.
        /// </summary>
        public static void emptyRecycleBin()
        {
            //Только запрос подтверждения очистки корзины запрещен, а звук и прогресс длинного процесса воспроизводятся. 
            SHEmptyRecycleBin(IntPtr.Zero, null, RecycleFlags.SHERB_NOCONFIRMATION);
        }

        /// <summary>
        /// Тут очистка диска со всеми эффектами шелла. 
        /// Показывает окно запроса подтверждения, прогрес-бар процесса очистки и играет звук шуршания бумаги. 
        /// </summary>
        public static void ClearRecycleBin()
        {
            try
            {
                uint result = SHEmptyRecycleBin(IntPtr.Zero, null, 0);
                Console.WriteLine("Empty the RecycleBin Done !");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Empty the RecycleBin Failed ! " + ex.Message);
            }
            return;
        }

    

    }//end class
}
