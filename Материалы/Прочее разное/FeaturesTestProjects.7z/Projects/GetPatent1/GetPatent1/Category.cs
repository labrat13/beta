﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GetPatent1
{
    public class Category
    {
        public String m_Name;
        public String m_Data;

        internal void Parse1(string line)
        {
            //"http://www.freepatentsonline.com/CCL-367.html"; AcousticProcessing;
            String[] sar = line.Trim().Split(new char[] { ';' });
            this.m_Name = sar[1].Trim();
            this.m_Data = sar[0].Replace("\"", "").Trim();
            
        }

        public override string ToString()
        {
            return m_Name;
        }
    }
}
