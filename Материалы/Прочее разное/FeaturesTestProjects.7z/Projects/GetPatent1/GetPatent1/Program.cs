﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace GetPatent1
{
    class Program
    {
        /// <summary>
        /// Путь к папке патентов. Еще есть аппликации-патенты и дизайн-патенты - для них другие папки нужно назначить.
        /// </summary>
        static String DataPath = "C:\\Patents\\Designs\\";
        static void Main(string[] args)
        {
            try
            {//test of function
                //Category c = new Category();
                //c.m_Name = "777";
                //ExtractPageCount(c, " <td>   Matches 1 - 50 out of 16691            </td>");
                Console.WriteLine("Patent File loader");
                //1 load catalog csv file
                Console.WriteLine("Load category csv file");
                List<Category> lcat = LoadCATEGORYcSVfILE(DataPath + "categories.csv");
                //2 create cat folder
                foreach (Category c in lcat)
                {
                    Console.WriteLine("Process category " + c.m_Name);
                    WebClient webClient = new WebClient();
                    String catfolder = DataPath + MakeDirName(c.m_Name);
                    Directory.CreateDirectory(catfolder);
                    //3 load each cat page

                    //webClient.DownloadFile(c.m_Data, "c:\myfile.txt");
                    String htmlPage = webClient.DownloadString(c.m_Data);
                    //4 extract max pages count / 50
                    int pageCount = ExtractPageCount(c, htmlPage);
                    Console.WriteLine("Pages for loading: {0}", pageCount);
                    //server limit pages to 200
                    if (pageCount > 200) pageCount = 200; 
                    //5 load each page
                    for (int i = 0; i < pageCount; i++)
                    {
                        String msg = DownloadPage(c, webClient, catfolder, i);
                        if(!String.IsNullOrEmpty(msg))
                            Console.WriteLine("Error: " + msg);
                        if ((i % 100 == 0))
                            Console.WriteLine("Page {0} from {1}", i, pageCount);
                        //6 parse each page to patent address file and patent app pdf file
                        //7 write addresses to file to wget

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} : {1}", ex.GetType(), ex.ToString());
            }
            Console.ReadKey();
            return;
        }
        /// <summary>
        /// Обертка для изоляции от неудач закачки
        /// </summary>
        /// <param name="c"></param>
        /// <param name="webClient"></param>
        /// <param name="catfolder"></param>
        /// <param name="i"></param>
        private static string DownloadPage(Category c, WebClient webClient, String catfolder, int i)
        {
            String result = "";
            try
            {
                webClient.DownloadFile(MakePageAddress(c, i), MakeHtmlFileName(catfolder, c, i));
            }
            catch (Exception ex)
            {
                result = String.Format("{0}: {1}", ex.GetType().ToString(), ex.Message); 
            }
            return result;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="catfolder"></param>
        /// <param name="c"></param>
        /// <param name="i"></param>
        /// <returns></returns>
        private static string MakeHtmlFileName(string catfolder, Category c, int i)
        {
            return Path.Combine(catfolder, String.Format("page{0}.html", i + 1));
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="c"></param>
        /// <param name="i"></param>
        /// <returns></returns>
        private static Uri MakePageAddress(Category c, int i)
        {
            //страницы нумеруются с 2, а 1 страница не имеет номера страницы
            String adder = String.Format("-p{0}.html", i+1);
            if(i == 0) adder = ".html";
            String s = c.m_Data.Replace(".html", adder);
            return new Uri(s);
        }

        private static int ExtractPageCount(Category c, string htmlPage)
        {
            //<td width="36%">
            //    Matches 1 - 50 out of 16691            </td>
            String pattern = "Matches (\\d+) - (\\d+) out of (?<cnt>\\d+)";

            Regex r = new Regex(pattern, RegexOptions.None);
            MatchCollection mc = r.Matches(htmlPage);

            if (mc.Count == 0)
            {
                Console.WriteLine("Category {0} error count detection", c.m_Name);
                return 1;
            }
            else
            {
                //extract page count
                String val = mc[0].Groups["cnt"].Value;
                Int32 items = Int32.Parse(val);
                //округлить счет до большего числа, если есть остаток
                bool d =((items % 50) > 0);
                items = items / 50;
                if(d) items++;
                return items;

            }
        }
        /// <summary>
        /// RT-make safe directory name from text
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private static string MakeDirName(string p)
        {
            StringBuilder sb = new StringBuilder(p.Length);
            char[] ic = Path.GetInvalidFileNameChars();
            foreach (Char c in p)
                if (!ic.Contains(c))
                    sb.Append(c);
                else sb.Append("-");

            return sb.ToString();
        }


        /// <summary>
        /// RT - load csv file
        /// </summary>
        /// <param name="filepath"></param>
        /// <returns></returns>
        private static List<Category> LoadCATEGORYcSVfILE(string filepath)
        {
            StreamReader sr = new StreamReader(filepath, Encoding.UTF8, true);
            List<Category> result = new List<Category>();
            while (!sr.EndOfStream)
            {
                Category cat = new Category();
                cat.Parse1(sr.ReadLine());
                result.Add(cat);
            }
            return result;
        }
    }
}
