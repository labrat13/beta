﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace GetPatentWget
{
    class Program
    {
        /// <summary>
        /// Список итемов подлежащих добыче
        /// </summary>
        static List<Item> m_items;
        static String srcDir = "C:\\Patents\\Designs";
        static String startTable = "class=\"listing_table\">";
        static String endTable = "</table>";
        static String docbaseUri = "http://www.freepatentsonline.com/";
        static void Main(string[] args)
        {
            Console.WriteLine("");
            //Исходный каталог для всех страниц таблицы

            m_items = new List<Item>(256); //создаем список для итемов на 1000000 итемов

            //получаем список файлов в каталоге
            String[] files = Directory.GetFiles(srcDir, "*.html", SearchOption.AllDirectories);
            Console.WriteLine("Найдено файлов: {0}");
            //читаем каждый файл и заполняем глобальный список итемов
            for (int i = 0; i < files.Length; i++)
            {
                Console.Write(files[i] + " ... ");
                ProcessFile(files[i]);
                Console.WriteLine("OK ({0})", m_items.Count);
            }

            //скидываем все в ксв-файл, а пути скидываем в файл для wget в UTF8.
            //патенты могут и повторяться в разных категориях, поэтому лучше всего собрать их вместе.
            //но скачивать лучше кусками для wget.
            Console.WriteLine("Записываем в выходные файлы");
            StreamWriter sw = new StreamWriter(Path.Combine(srcDir,"Items.csv"), false, Encoding.UTF8);
            StreamWriter swHtml = new StreamWriter(Path.Combine(srcDir,"WgetHtml.txt"), false, Encoding.UTF8);
            StreamWriter swPdf = new StreamWriter(Path.Combine(srcDir,"WgetPdf.txt"), false, Encoding.UTF8);
            foreach (Item item in m_items)
            {
                sw.WriteLine(item.makeCsvString());
                swHtml.WriteLine(item.HtmlUrl);
                swPdf.WriteLine(item.PdfUrl);
            }
            sw.Close();
            swHtml.Close();
            swPdf.Close();
            Console.WriteLine("Завершено успешно");
            Console.ReadKey();
            return;
        }

        private static void ProcessFile(String filename)
        {
            //get category name as folder name
            String category = Path.GetFileName(Path.GetDirectoryName(filename));
            StreamReader sr = new StreamReader(filename, Encoding.UTF8, true);
            String content = sr.ReadToEnd();
            sr.Close();
            //выделяем таблицу, выкидываем остальное
            int start = content.IndexOf(startTable) + startTable.Length;
            content = content.Substring(start);
            int end = content.IndexOf(endTable);
            content = content.Substring(0, end);
            //делим таблицу на строки, выкидываем мусор.
            //парсим каждую строку таблицы на номер патента, путь к html, путь к pdf, описание патента.
            ProcessTable(category, content);
            


            return;
        }

        private static void ProcessTable(string category, string content)
        {
            content = content.Replace("\n", "");
            content = content.Replace("class=rowalt>", "");
            content = content.Replace("class=>", "");
            content = content.Replace("valign=\"top\"", "");
            content = content.Replace("&nbsp;", "");
            content = content.Replace("<br/>", "");
            //удалить все лишние пробелы
            content = content.Replace("  ", " ").Replace("  ", " ").Replace("  ", " ").Replace("  ", " ");
            
            //делим таблицу на строки, выкидываем мусор.
            String[] rows = content.Split(new String[] { "<tr" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (String row in rows)
            {
                //парсим каждую строку таблицы на номер патента, путь к html, путь к pdf, описание патента.
                ProcessRow(category, row);
            }
            return;
        }

        private static void ProcessRow(string category, String row)
        {
            //парсим каждую строку таблицы на номер патента, путь к html, путь к pdf, описание патента.
            String[] columns = row.Split(new String[] { "<td" }, StringSplitOptions.RemoveEmptyEntries);
            if (columns.Length > 2)
            {
                Item it = new Item();
                it.Category = category;
                //prepare Id
                String id = columns[2];
                int start = id.IndexOf('>') + 1;
                int end = id.IndexOf('<');
                id = id.Substring(start, end-start);
                it.PatentId = id.Trim();
                //
                String t4 = columns[3];
                //width="60%" > <a href="/9040729.html">Processes of preparing estolide compounds that include removing sulfonate residues</a>    Provided herein are processes of preparing sulfonated estolide compounds, and the removal of sulfonate residues from those compounds to provide desulfonated estolide base oils. Exemplary... </td> </tr>
                start = t4.IndexOf("href=\"/") + 7;
                t4 = t4.Substring(start);
                start = t4.IndexOf("\">");
                String html = t4.Substring(0, start);
                t4 = t4.Substring(start + 2);
                t4 = t4.Replace("</a>", "").Replace("</td>", "").Replace("</tr>", "");
                it.Description = t4.Trim();
                it.HtmlUrl = docbaseUri + html;
                it.PdfUrl = docbaseUri + Path.ChangeExtension(html, ".pdf");
                m_items.Add(it);
            }
            return;
        }



    }
}
