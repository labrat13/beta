﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GetPatentWget
{
    public class Item
    {
        public String PdfUrl;
        public String HtmlUrl;
        public String PatentId;
        public String Description;
        public String Category;

        /// <summary>
        /// Собрать строку в ксв формате для вывода в файл
        /// </summary>
        /// <returns></returns>
        public string makeCsvString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Category);
            sb.Append(';');
            sb.Append(PatentId);
            sb.Append(';');
            sb.Append(HtmlUrl);
            sb.Append(';');
            sb.Append(PdfUrl);
            sb.Append(';');
            sb.Append(Description.Replace(';', ','));
            sb.Append(';');
            return sb.ToString();
        }

        public override string ToString()
        {
            return PatentId;
        }

        internal void parseCsvString(string line)
        {
            string[] sar = line.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            this.Category = sar[0];
            this.PatentId = sar[1];
            this.HtmlUrl = sar[2];
            this.PdfUrl = sar[3];
            this.Description = sar[4];

            return;
        }
    }

    
}
