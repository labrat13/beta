﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.OleDb;
using GetPatentWget;

namespace FillDbFromCsv
{
    class Program
    {
        public static OleDbConnection m_connection;
        public static OleDbCommand m_cmd;
        public static OleDbCommand m_cmd2; 
        /// <summary>
        /// dest table name - они все одинаковые
        /// </summary>
        public static string TableName = "Designs";
        /// <summary>
        /// src folder with csv files
        /// </summary>
        public static String srcDir = "C:\\Patents\\Designs";
        /// <summary>
        /// Путь к сайту, который надо извлечь из файлов чтобы сэкономить место 
        /// </summary>
        public static string SitePath = "http://www.freepatentsonline.com/";
        
        static void Main(string[] args)
        {
            ConnectDatabase();
            
            String[] files = Directory.GetFiles(srcDir, "*.csv", SearchOption.TopDirectoryOnly);
            foreach(string filename in files)
            {
                Console.WriteLine("File: " + filename);
                StreamReader sr = new StreamReader(filename, Encoding.UTF8, true);
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    Item it = new Item();
                    it.parseCsvString(line);
                    //write to table
                    if (!CheckExists(m_connection, TableName, it))
                        WriteToTable(m_connection, TableName, it);
                    else Console.WriteLine("Dublicate: {0}", it.PatentId);
                }
                sr.Close();

            }
            DisconnectDatabase();
            Console.WriteLine("Finished succesfully. Press any key to exit.");
            Console.ReadKey();
            return;
        }

        private static void WriteToTable(OleDbConnection m_connection, string TableName, Item it)
        {
            if (m_cmd == null)
            { 
                //INSERT INTO `Patents` (`cat`, `pid`, `html`, `pdf`, `descr`) VALUES (?, ?, ?, ?, ?)
                String query = String.Format("INSERT INTO `{0}` (`cat`, `pid`, `html`, `pdf`, `descr`) VALUES(?, ?, ?, ?, ?);", TableName);
               
                m_cmd = new OleDbCommand(query, m_connection);
                m_cmd.Parameters.Add(new OleDbParameter("@a1", OleDbType.VarWChar));
                m_cmd.Parameters.Add(new OleDbParameter("@a2", OleDbType.VarWChar));
                m_cmd.Parameters.Add(new OleDbParameter("@a3", OleDbType.VarWChar));
                m_cmd.Parameters.Add(new OleDbParameter("@a4", OleDbType.VarWChar));
                m_cmd.Parameters.Add(new OleDbParameter("@a5", OleDbType.VarWChar));
            }
            //set values
            m_cmd.Parameters[0].Value = it.Category;
            m_cmd.Parameters[1].Value = it.PatentId;
            m_cmd.Parameters[2].Value = it.HtmlUrl.Replace(SitePath, "");
            m_cmd.Parameters[3].Value = it.PdfUrl.Replace(SitePath, "");
            m_cmd.Parameters[4].Value = it.Description;
            //execute command
            m_cmd.ExecuteNonQuery();

            return;
        }

        private static bool CheckExists(OleDbConnection m_connection, string TableName, Item it)
        {
            if (m_cmd2 == null)
            {
                //SELECT     pid FROM         Patents WHERE     (pid = ?)
                String query = String.Format("SELECT `pid` FROM `{0}` WHERE (`cat` = ?);", TableName);

                m_cmd2 = new OleDbCommand(query, m_connection);
                m_cmd2.Parameters.Add(new OleDbParameter("@a1", OleDbType.VarWChar));
            }
            //set values
            m_cmd2.Parameters[0].Value = it.PatentId;
            //execute command
            OleDbDataReader rdr = m_cmd2.ExecuteReader();
            bool result = rdr.HasRows;
            rdr.Close();
            return result;
        }
        /// <summary>
        /// NT
        /// </summary>
        private static void DisconnectDatabase()
        {
            m_connection.Close();
        }
        /// <summary>
        /// NT
        /// </summary>
        private static void ConnectDatabase()
        {
            m_connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Patents\\Patents.mdb");
            m_connection.Open();
        }

    }
}
