﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InetDetectorTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Begin at {0}", DateTime.Now);
            //bool result = InternetCS.IsConnectedToInternet(); //работает быстро и хорошо
            //bool result = InternetCS.CheckByPingUrl();//4 секунды, если подключен. 0 если не подключен.
            bool result = InternetCS.CheckByUrl();//3..12 секунды, если подключен. 0 если не подключен.
            if (result) Console.WriteLine("Connected at {0}", DateTime.Now);
            else Console.WriteLine("Disconnected at {0}", DateTime.Now);
            return;
        }



    }
}
