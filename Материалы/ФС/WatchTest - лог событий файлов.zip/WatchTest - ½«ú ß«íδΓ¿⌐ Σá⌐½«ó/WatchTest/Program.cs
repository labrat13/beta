﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.Permissions;

namespace WatchTest
{
    //Код рабочий из МСДНа. Но прямо использовать его нельзя. Тут поток крутится в бесконечном цикле. см while в конце.
    //Тут это надо переделывать на собственный фоновый поток и ожидание события.
    //Эта штука перехватывает изменения файлов и каталогов. Но не открытие и закрытие файлов.
    //Если ее переделать и запустить на весь сеанс пользователя, она могла бы вести лог изменений для моих проектов.
    //Записывая в каждый проект лог моих попыток изменения содержимого проекта.
    //(Это вызывало бы рекурсию, если не фильтровать записи в файл лога в проекте)
    //Чем это мне помогло бы - пока не знаю. 
    //Но пока некуда прицепить эту фичу - нет постоянно висящего в сеансе дежурного процесса для нее.
    //и возможно, еще появились бы проблемы с бекапом проектов, так как файл лога в проекте будет дописываться при любом изменении содержимого проекта.
    //в том числе прямо в процессе упаковки при бекапе. Но можно отключать этот лог на время бекапа итд.

    
    class Program
    {
        static void Main(string[] args)
        {
            Run();
        }

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        public static void Run()
        {
            string[] args = System.Environment.GetCommandLineArgs();

            // If a directory is not specified, exit program.
            if (args.Length != 2)
            {
                // Display the proper way to call the program.
                Console.WriteLine("Usage: Watcher.exe (directory)");
                return;
            }

            // Create a new FileSystemWatcher and set its properties.
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = args[1];
            /* Watch for changes in LastAccess and LastWrite times, and 
               the renaming of files or directories. */
            watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
               | NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.Size;
            watcher.Filter = "";
            watcher.IncludeSubdirectories = true;

            // Add event handlers.
            watcher.Changed += new FileSystemEventHandler(OnChanged);
            watcher.Created += new FileSystemEventHandler(OnChanged);
            watcher.Deleted += new FileSystemEventHandler(OnChanged);
            watcher.Renamed += new RenamedEventHandler(OnRenamed);

            // Begin watching.
            watcher.EnableRaisingEvents = true;

            // Wait for the user to quit the program.
            Console.WriteLine("Press \'q\' to quit the sample.");
            while (Console.Read() != 'q') ;
        }

        // Define the event handlers.
        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            // Specify what is done when a file is changed, created, or deleted.
            Console.WriteLine("File: " + e.FullPath + " " + e.ChangeType);
        }

        private static void OnRenamed(object source, RenamedEventArgs e)
        {
            // Specify what is done when a file is renamed.
            Console.WriteLine("File: {0} renamed to {1}", e.OldFullPath, e.FullPath);
        }

    }
}

//выведено на терминал в ходе тестирования:

//Press 'q' to quit the sample.
//- создал новую папку в Temp
//File: C:\Temp\Новая папка Created
//- создал еще вложенную папку
//File: C:\Temp\Новая папка\Новая папка Created
//File: C:\Temp\Новая папка Changed
//- создал текстовый файл
//File: C:\Temp\Новая папка\Текстовый документ.txt Created
//File: C:\Temp\Новая папка Changed
//- создал еще вложенную папку
//File: C:\Temp\Новая папка\Новая папка\Новая папка Created
//File: C:\Temp\Новая папка\Новая папка Changed
//- переименовал созданную папку
//File: C:\Temp\Новая папка\Новая папка\Новая папка renamed to C:\Temp\Новая папка\Новая папка\1
//File: C:\Temp\Новая папка\Новая папка Changed
//- создал новый текстовый файл
//File: C:\Temp\Новая папка\Новая папка\1\Текстовый документ.txt Created
//File: C:\Temp\Новая папка\Новая папка\1 Changed
//- переименовал его
//File: C:\Temp\Новая папка\Новая папка\1\Текстовый документ.txt renamed to C:\Temp\Новая папка\Новая папка\1\1.txt
//File: C:\Temp\Новая папка\Новая папка\1 Changed
//- тут непонятно что делал.
//File: C:\Temp\Новая папка\Новая папка\1 Changed
//- тут изменил текст файла и сохранил CTRL+S
//File: C:\Temp\Новая папка\Новая папка\1\1.txt Changed
//- тут закрыл текстовый файл
//File: C:\Temp\Новая папка\Новая папка\1\1.txt Changed
// - тут переместил текстовый файл в самую первую созданную папку Проводником.
//File: C:\Temp\Новая папка\Новая папка\1\1.txt Deleted
//File: C:\Temp\Новая папка\1.txt Created
//File: C:\Temp\Новая папка Changed
//- тут удалил папки 2 и 3 уровня
//File: C:\Temp\Новая папка\Новая папка\1 Changed
//File: C:\Temp\Новая папка\Новая папка Deleted
//File: C:\Temp\Новая папка Changed
//- тут удалил всякие эти файлы как ненужные
//File: C:\Temp\Новая папка\Текстовый документ.txt Deleted
//File: C:\Temp\Новая папка Changed
