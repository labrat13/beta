﻿$(document).ready(function () {
    setTimeout(function () {
        SetMISTrack();
    }, 0);
});

function SetMISTrack() {

    var _wmxq = _wmxq || [];
    _wmxq.push(["_getTracker", "SupportSite", "website", "etrk.asus.com"]); _wmxq.push(["trackPageview"]);
    (function () {
        var sc = document.createElement("script"); sc.type = "text/javascript"; sc.async = true;
        sc.src = ("https:" == document.location.protocol ? "https:" : "http:") + "//etrk.asus.com/web_service/TrackingJS/wmxtracker.js";
        var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(sc, s);
    })();
}