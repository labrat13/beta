$ = jQuery.noConflict();
// VAD changed to hide
$.bigfoot({ actionOriginalFN: "hide"});
