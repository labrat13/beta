﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Reflection;
using System.IO;
using Processes;
using System.Security.Policy;

namespace ProcessesTest
{
    class Program
    {
        //TODO: Сделать для Оператора команды 
        //Закрыть приложение - это мягко закрыть, а если упрется - то не добивать.
        //Завершить приложение - воще конкретно закрыть.
        //Показать процессы - показать списком запущенные процессы как приложения
        //Показать приложения - то же
        //Показать запущенные процессы - то же
        //Показать запущенные приложения - то же
        //в виде отдельной длл и хмл-файла для БД, отдельного или из ресурсов длл.
        //или длл и проперти списка объектов для БД.
        //Для настройки-отладки удобнее внешний хмл-файл,
        //для развертывания и хранения удобнее встроенный,
        //для использования - несущественно - все в БД хранится.

        //TODO: опробовать загрузку длл в дополнительный домен, 
        //удаление дополнительного домена приложения
        //повторную загрузку длл этим же способом


        //Есть проблема: если несколько одноименных приложений открыто, как их закрывать?
        //а) закрывать все
        //  Это просто, но пользователь может потерять данные, о которых он забыл. 
        //б) запросить пользователя выбрать экземпляр приложения для закрытия
        //  Это требует диалог с пользователем и специальное отображение элементов списка
        //в) ничего не закрывать, так как пользователь не владеет ситуацией, и значит, может потерять данные.

        //приложение можно указать по названию файла без пути, без пути и расширения, с полным путем.
        //можно также искать по титлу главного окна приложения, которое часто содержит название открытого файла или проекта, но оно длинное. Его только для выбора экземпляра использовать просто.

        static void Main(string[] args)
        {
            //ProcessP("Блокнот"); //не работает - нотепад не так называется
            //ProcessP("notepad", true);

            //Processes.ProcessManager.CloseApplication("C:\\windows\\system32\\notepad.exe", false, 5000);

            //Processes.ProcessManager.CloseApplicationByMainWindowTitle("Безымянный - Блокнот", false, 5000);

            AppDomainLoadingTest();

        }

        private static void AppDomainLoadingTest()
        {
            //создать дополнительный домен для приложения
            //загрузить в него длл
            //запустить закрытие приложения
            //выгрузить длл и домен
            //снова все это повторить 

            String exePath = Path.GetFullPath("Processes.dll");


            // Construct and initialize settings for a second AppDomain.
            AppDomainSetup ads = new AppDomainSetup();
            ads.ApplicationBase = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            ads.DisallowBindingRedirects = false;
            ads.DisallowCodeDownload = false;
            ads.ConfigurationFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
            //ads.ApplicationTrust = AppDomain.CurrentDomain.DomainManager. 

            AppDomain curd = AppDomain.CurrentDomain;
            PrintAppDomain(curd);
            //create second domain
            AppDomain ad2 = curd.DomainManager.CreateDomain("Processes", null, ads);
            PrintAppDomain(ad2);//тут сборки Processes.dll еще нет - проверено


            //call method from second domain
            //ProcessManager pm = (ProcessManager) ad2.CreateInstanceAndUnwrap(exePath, typeof(ProcessManager).FullName);
            //это не работает - пишет что сборка неправильная. Я перенес копию сборки в другой каталог - все равно.

            //Тут проблема - сборка уже загружена в пространство текущего домена. 
            //Она не может быть загружена в два домена одновременно. 
            //Но чтобы использовать объект, нужно подключить его к коду
            //а это включает и загрузку библиотеки при старте приложения в основной домен.
            //Тут надо или интерфейсы использовать или яхз что.
            //В общем, этот вопрос надо отдельно изучать с примерами из интернета.

            //способ 2: через рефлекшен, вызываем методы и классы по именам. Это не грузит сборку в основной домен.

            Assembly a = ad2.Load(loadFile(exePath));
            Type tt = a.GetType("Processes.ProcessManager", false, true);
            MethodInfo mi = tt.GetMethod("CloseApplication");
            Object[] arg = new Object[3];
            arg[0] = "C:\\windows\\system32\\notepad.exe";
            arg[1] = false;
            arg[2] = 5000;
            mi.Invoke(null, arg);
            //вызывается, работает. Но пришлось поиграться с настройками и атрибутами безопасности - я теперь не знаю, что я вообще сделал там.
            //однако, вызывать методы по именам все же неудобно. Поэтому есть предложения:
            //1) подобные критические функции выполнять в основном домене приложения
            //2) сами эти функции включить в мою общую библиотеку функций и ее использовать в Оператор и других проектах.
            //они будут надежными и таким образом не будут требовать отдельного домена приложения.

            //В дополнительный домен приложения можно загрузить только сборку, которая не загружена в основной домен (Да?)
            //Тогда в сборке в этом дополнительном домене нельзя вызывать библиотеки АПИ основного приложения?
            //Это лишает смысла всю эту идею в общем случае. 
            //Надо проверить, так это или нет.

            PrintAppDomain(ad2); //тут сборка Processes.dll уже есть - проверено

            //pm.CloseApplication("C:\\windows\\system32\\notepad.exe", false, 5000);
            // Unload the second AppDomain. This deletes its object and 
            // invalidates the proxy object.
            AppDomain.Unload(ad2);


        }

        private static void PrintAppDomain(AppDomain a)
        {
            Console.WriteLine();
            Console.WriteLine("AppDomain: {0}", a.FriendlyName);
            Console.WriteLine("{0}={1}", "ActivationContext", a.ActivationContext);
            Console.WriteLine("{0}={1}", "ApplicationIdentity", a.ApplicationIdentity);
            Console.WriteLine("{0}={1}", "ApplicationTrust", a.ApplicationTrust);
            Console.WriteLine("{0}={1}", "Evidence", a.Evidence);
            Console.WriteLine("{0}={1}", "SetupInformation", a.SetupInformation);
            foreach(Assembly ass in a.GetAssemblies())
            {
                Console.WriteLine("{0}={1}", ass.FullName, ass.Evidence);
            }
            return;
        }

        // Loads the content of a file to a byte array. 
        static byte[] loadFile(string filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open);
            byte[] buffer = new byte[(int)fs.Length];
            fs.Read(buffer, 0, buffer.Length);
            fs.Close();

            return buffer;
        }

        private static void ProcessP(String apppath, bool kill)
        {
            try
            {
                //get existing processes
                Process[] par = Process.GetProcesses();
                Process p = null;
                ////find first application object by name
                //foreach (Process pr in par)
                //    //if (String.Compare(pr.MainModule.FileName, apppath, true) == 0) - для поиска по пути приложения
                //    if(String.Compare(pr.ProcessName, apppath, true) == 0)
                //    {
                //        p = pr;
                //        break;
                //    }

                //find all app objects by name
                List<Process> lip = new List<Process>();
                foreach(Process pr in par)
                    if (String.Compare(pr.ProcessName, apppath, true) == 0)
                    {
                        lip.Add(pr);
                    }
                //select app
                if (lip.Count > 1)
                {
                    Console.WriteLine("Too many active apps!");
                    return;
                }
                else if (lip.Count == 1)
                    p = lip[0];
                //clear list
                lip = null;


                //closing                
                if (p != null)
                {
                    p.CloseMainWindow();
                    //а вот тут Блокнот возвращает труе, а окно не закрывает а мессагобоксом предлагает сохранить изменения.
                    bool closed = p.WaitForExit(5000);
                    //а сколько именно надо ждать - зависит от приложения и загрузки компьютера. Может и десять минут закрываться.
                    //Можно мониторить свободные ресурсы машины и по ним назначать верхний порог таймаута
                    //но это надо опыты ставить, и опять же, это от приложения зависит.
                    if ((closed == false) && (kill == true))
                    {
                        p.Kill();
                        //wait for exit
                        closed = p.WaitForExit(5000);
                        if (closed == false)
                            //тут можно вернуть вызывающему коду результат операции как неудача.
                            Console.WriteLine("App not closed after timeout!");
                    }
                    p.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return;
        }
    }
}
