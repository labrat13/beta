$(document).ready(function() {
    var form = $('#login_form');
    var navbar = $('#menublock');
    var errmsg = $('#errmsg');
    form.submit(function(event) {
/*	var username = $("#username").val();
	var password = $("#password").val(); */
	event.preventDefault();
	var form_status = $('<div class="navbar-form"></div>');
	if( $("#username").val() == "" || $("#password").val() == "")
	    navbar.prepend(errmsg.html('<p class="text-danger" id="error-login">Все поля должны быть заполнены!</p>').fadeOut(5000));
/*	    form.prepend(form_status.html('<p class="text-info" id="error-login">Все поля должны быть заполнены!</p>').delay(7000)); */
	else /*
	/*    form.prepend(form_status.html('<p class="text-info">Good!</p>').delay(7000)); */
	    $.ajax({
		type: "POST",
		url:"login.php",
		cache:false,
/*		data: "username="+username+"&password="+password, */
		data:form.serialize(),
		success: function(html){
		    if(html=='true') {
			$("#login_form").fadeOut("normal");
			navbar.html('<li><a href="profile/" class="navbar-link"> <i class="fa fa-user"></i> Профиль</a></li><a href="logout/" title="Выход"><button type="button" class="btn btn-default navbar-btn navbar-right"><i class="fa fa-sign-out"></i> Выход</button></a>').delay("9000");
		    }
		    else
		    {
			navbar.prepend(errmsg.html('<p class="text-info" id="error-login">Такой пользователь не найден!</p>').fadeOut(7000));
			/*$("#menublock").html("Wrong"); */
		    }
/*		$("#login_form").fadeOut("normal"); */
/*		    navbar.html('<li><a href="profile/" class="navbar-link"> <i class="fa fa-user"></i> Профиль</a></li><a href="logout/" title="Выход"><button type="button" class="btn btn-default navbar-btn navbar-right"><i class="fa fa-sign-out"></i> Выход</button></a>'); */
		}
/*		beforeSend: function(){
		    form.prepend(form_status.html('<p class="text-info">Идет проверка пользователя...</p>'));
		} */

	    });
	});
    });