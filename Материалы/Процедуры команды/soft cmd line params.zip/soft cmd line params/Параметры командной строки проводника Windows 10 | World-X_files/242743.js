
        if ("undefined" === typeof(__da_info_loaded)) {
            var newScript = document.createElement("script");
            newScript.type = "text/javascript";
            newScript.src =  "http://st.directadvert.ru/news/js/info.min.js?t=1470332646";
            document.getElementsByTagName("head")[0].appendChild(newScript);
            __da_info_loaded = 1;
        }
    if(document.getElementById('DIV_DA_242743_508')) { 
            if (typeof __da_widget_count == 'undefined') {
                __da_widget_count = 0;
            }
            __da_widget_count++;
        
                (function () {
                    var newScript = document.createElement('script');
                    newScript.type = 'text/javascript';
                    newScript.charset = 'windows-1251';
                    newScript.src = 'http://adv.wd-x.ru/data/242743.js?nnn=242743&div=DIV_DA_242743_508&async=1&dc_test=1&t='+Math.random()+'';
                    newScript.async = true;
                    var s = document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0];
                    s.appendChild(newScript);
                })();
            eval("try {new Image().src = '//counter.yadro.ru/hit;All_da_nnn_dn_realty?r'+escape(document.referrer)+((typeof(screen)=='undefined')?'':';s'+screen.width+'*'+screen.height+'*'+(screen.colorDepth?screen.colorDepth:screen.pixelDepth))+';u'+escape(document.URL)+';'+Math.random();} catch (e) {}");} 