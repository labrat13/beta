/*$().ready(function() {

	        tinymce.init({selector:'textarea.tinymce', language:'ru',
		plugins : '',
		image_advtab: true});

	});
*/
jQuery(document).ready(function($){                  
	$(document).on("click", ".delComment", function(e) {
		if (!confirm('Вы подтверждаете удаление?')) return false;
		var getvalue = $(this).prop('rel');
//alert(JSON.stringify(getvalue));
		var passport = $(this).prop('passport');
		var dataString = 'id=' + getvalue + '&passport=' + passport + '&eventComments=del';
		$.ajax({
			type: "POST",
			url: "",
			data: dataString,
			cache: false,
			success: function(html){
				if(html=='OK')
					{
					$("#itemComment-" + getvalue).remove();
					}
			$("#ajaxComment").html(html);
			}
                 });
	e.preventDefault();
	});

	$(document).on("click",".replyComment", function(e) {
		var getvalue = $(this).prop('rel');
//alert(getvalue);
		var post_url = $("#posturlComment").val();
		var dataString = 'replyid=' + getvalue + '&eventComments=reply' + '&posturlComment=' + post_url;
//alert(dataString);
		$.ajax({
			type: "POST",
			url: "",
			data: dataString,
			cache: false,
			success: function(html){
				$("#RformComment").fadeOut(2000).remove();
				$("#itemComment-" + getvalue).append(html);

/*			        tinymce.init({selector:'#RformComment textarea.tinymce', language:'ru',
				plugins : '',
				image_advtab: true});
*/
			}
                 });
	e.preventDefault();
	});

	$(document).on("click", ".submitComment", function(e) {

	var name = $("#nameComment").val();
	var email = $("#emailComment").val();
	var addComment = $("#addComment").val();

	var RreplyComment = $("#RreplyComment").val();
	if(typeof name === 'undefined') name='';
	if(typeof email === 'undefined') email='';
	if(typeof RreplyComment === 'undefined') RreplyComment='';

	if(RreplyComment !== "" && RreplyComment !== 0 && RreplyComment !== "0" && RreplyComment !== null &&
		 RreplyComment !== false && typeof RreplyComment !== 'undefined') {
		var loginComment = $("#RloginComment").val();
		var comment = $("#RtextComment").val();
		var post_url = $("#RposturlComment").val();
		var postO_url = $("#RposturlOpenComment").val();
		var persona= $("#RpersonaComment").val();
		var checked = $("#RcheckedComment").val();
		}
		else {		
		var loginComment = $("#loginComment").val();
		var comment = $("#textComment").val();
		var post_url = $("#posturlComment").val();
		var postO_url = $("#posturlOpenComment").val();
		var persona= $("#personaComment").val();
		var checked = $("#checkedComment").val();
		}

	var dataString = 'loginComment=' + loginComment + '&addComment=' + addComment + '&personaComment=' 
			+ persona + '&checkedComment=' + checked + '&eventComments=save&nameComment='+ name 
			+ '&emailComment=' + email + '&textComment=' + encodeURIComponent(comment) + '&posturlComment=' 
			+ post_url +'&posturlOpenComment=' + postO_url +'&replyComment=' + RreplyComment;
	if(post_url=='') {alert('Error')};


	if((loginComment==0 && (name=='' || email=='')) ) //|| comment===''
		{
		alert('Пожалуйста заполните все поля');
		}
	else
	{
	$("#ajaxComment").show();
	$("#ajaxComment").fadeIn(400).html('<img src="/theme/doctor/images/comment/ajax-bar.gif" align="absmiddle">&nbsp;<span class="loading"></span>');
	$.ajax({
		type: "POST",
		url: "",
		data: dataString,
		cache: false,
		success: function(html){
			if(html!=='ERR1' && html!=='ERR2' && html!=='ERR3' && html!=='ERR4') {
        		   if(RreplyComment !== "" && RreplyComment !== 0 && RreplyComment !== "0" && RreplyComment !== null &&
				 RreplyComment !== false && typeof RreplyComment !== 'undefined') {
					$("#RformComment").fadeOut(2000).remove();
					$("#itemComment-" + RreplyComment).append(html);
					$("#ajaxComment").hide();
				}
				else {
					$("#allComment").append(html);
					//$("ol#update li:last").fadeIn("slow");
					$("#nameComment").val("");
					$("#emailComment").val("");
					$('#textComment').val("");
					$("#nameComment").focus();
					$("#ajaxComment").hide();
					}
				}
				else
				{
				$("#messComment").html('');
				$("#messComment").show();
				$('#textComment').val("");
				$("#ajaxComment").hide();
				if(html=='ERR1')$("#messComment").append("Ошибка: Имя должно состоять более чем из 3 символов<br/>");
				if(html=='ERR2')$("#messComment").append("Ошибка: E-Mail указан неверно<br/>");
				if(html=='ERR3')$("#messComment").append("Ошибка: Отсутствует текст комментария<br/>");
				if(html=='ERR4')$("#messComment").append("Ошибка: Не удается установить тип комментария. Попробуйте позже");
				$("#messComment").fadeOut(3000);
				}
			}
		});
	}
	e.preventDefault();
	});

});