(function(){
var isIE = window.navigator.userAgent.indexOf("MSIE ") > 0;
var ifr = document.createElement('iframe');
ifr.setAttribute('id', 'cto_iframe_9bb84b7630');
ifr.setAttribute('frameBorder', 0);
ifr.setAttribute('allowtransparency', true);
ifr.setAttribute('hspace', 0);
ifr.setAttribute('marginwidth', 0);
ifr.setAttribute('marginheight', 0);
ifr.setAttribute('scrolling', 'no');
ifr.setAttribute('vspace', 0);
ifr.setAttribute('width', '970px');
ifr.setAttribute('height', '90px');

var container = document.getElementById('SRTB_67769');
if (container) { container.appendChild(ifr); }
var ifc = "\n";
ifc += "<"+"!DOCTYPE html>\n";
ifc += "<"+"html>\n";
ifc += "  <"+"head>\n";
ifc += "    <"+"meta name=\"format-detection\" content=\"telephone=no\"><"+"meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n";
ifc += "  <"+"/head>\n";
ifc += "  <"+"body>            <"+"script>\n";
ifc += "                var msg = {provider: \'sRTBMsg\', act: \'showNext\', sectionId: \'67769\'};\n";
ifc += "                var w = window;\n";
ifc += "                w.postMessage(JSON.stringify(msg), \'*\');\n";
ifc += "                while(w != w.parent){\n";
ifc += "                    w = w.parent;\n";
ifc += "                    w.postMessage(JSON.stringify(msg), \'*\');\n";
ifc += "                }\n";
ifc += "            <"+"/script>\n";
ifc += "\n";
ifc += "<"+"div id=\'beacon_9bb84b7630\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
ifc += "<"+"img width=\"0\" height=\"0\" src=\"http://cat.fr.eu.criteo.com/delivery/lg.php?cppv=1&cpp=wUJFw3xBVEJGNlhlbDFLQ0RHR3dpYUg0MG9oaXEzWFpwc1dMRWFMeTJGVHA0M0o0elFNb0dLeHpUUnVjNVVLOEkwTER0R2NUbWFOM0dyNm9ET3U5MDRDaHRUdDFrMERBU3JPbXAxdzA2bmtJL0Jlcm95UkFOdklzR2NrYlVEZ0tKYUJoamRkajBMS2d0SGxGZjBqdFl6UmpIcEthMnVPV092Z2xERFBUWVpwMUh4V29PRVRlc2RQbGtlVmhDcWluK1hIcFJnR1VNdkkwSnIvUURTZldTTG4rZlJEWUFUMy9ONFhIc0pEby9heC9xWC9VPXw%3D\"/>\n";
ifc += "<"+"img width=\"0\" height=\"0\" src=\"http://sync.mathtag.com/sync/img?type=sync&mt_exid=20&redir=http%3a%2f%2fdis.criteo.com%2frex%2fmatch.aspx%3fc%3d2%26uid%3d%5bMM_UUID%5d\"/>\n";
ifc += "<"+"/div>\n";
ifc += "<"+"/body>\n";
ifc += "<"+"/html>\n";

var fillIframe = function(ifrd) {
    var getDocument = function(iframe) {
        var result_document = iframe.contentWindow || iframe.contentDocument;
        if (result_document && result_document.document)
            result_document = result_document.document;
        return result_document;
    };
    var c = getDocument(ifrd);
    if (c) {
        c.open();
        c.write(ifc);
        c.close();
    }
};


var maxRetryAttempts = 100;
var loaded = false;
var pollIframe = function() {
    var ifrd = document.getElementById('cto_iframe_9bb84b7630');
    if (ifrd && isIE) {
         ifrd.onload = function() {
            if(!loaded) {
                loaded = true;
                fillIframe(ifrd);
            }
        };
    } else if (ifrd) {
        loaded = true;
        fillIframe(ifrd);
    } else if (maxRetryAttempts-- > 0) {
        setTimeout(pollIframe, 10);
    }
};pollIframe();
})();
