jQuery(function($) { 
try{
	var fixblock_height = $('#fixblock').height(); 
	var fixblock_pos = $('#fixblock').position().top; ; 
	var h = $('#content-main').height(); 

	function show_hide_adv() {

	  var w = $(document).width(); 
	  if ($(window).scrollTop() > fixblock_pos+50 && h>1000 && w>1000){ 
		$('#fixblock').css({'position': 'fixed', 'top':'0px', 'z-index':'10'}); 
		//$('#headblock').css('padding-bottom', fixblock_height+'px'); 
	  }else{ 
		$('#fixblock').css({'position': 'static'}); 
		//$('#headblock').css('padding-bottom', '0px'); 
	  } 

	}
	

	$(window).scroll(function(){
                  show_hide_adv();
	}) ;

	$(window).resize(function () {
                  show_hide_adv();
	})
}catch(e){}

try{document.getElementsByName('googleSearchFrame')[0].height=1300;}catch(e){}
}); 




jQuery(document).ready(function($){

    $("#catava").change(function(){
            var cat = $("#catava option:selected").val();

	    $("#avat").html('');

            $.post("/com/setup/ajax/", {cat: cat},
               function (json) {
		  var arr = jQuery.parseJSON(json);
		  $.each(arr, function(i, str) {
			  if(str!='.'&&str!='..') $("#avat").append("<option value='" + str + "'>" + str + "</option>");
                  });
            });

	});

    $("#avat").change(function(){
	    var cat = $("#catava option:selected").val();
            var avat = $("#avat option:selected").val();

	    $("#preview").html('<img src="/img/avatar/'+cat+'/'+avat+'" alt="" />');
	                                                
	});


	$('.gosoderj').click(function() {
		var id = $(this).parent().data('id');
		console.log(id);
		// сперва получаем позицию элемента относительно документа
		var scrollTop = $('h1,h2:not(.ssd),h3,h4,h5,h6').eq(id).offset().top;

		// скроллим страницу на значение равное позиции элемента
		$(document).scrollTop(scrollTop);

	});

});


jQuery(document).ready(function($){
	$('input[name="bonus"]').change(function(){
		var id = $(this).val();

		if(id==0)$('.bonussumm').hide();
		if(id==1)$('.bonussumm').show();
	});

     $("a[rel*=lightbox]").lightBox({
	txtImage: 'Изображение',
	txtOf: 'из'
	});


      function screen_check(){
            if ($(window).width() <= 970) { 
               $('#meganavigator2, .top-bg-menu2').hide();
            } else {
               $('#meganavigator2, .top-bg-menu2').show();
	    }
        }
	screen_check();

	$(window).on('resize', function(){
	    screen_check();
	});

	var source_link = '<p>Источник: <a href="' + location.href + '">' + location.href + '</a></p>';

        if (window.getSelection) $('#yt-col1').bind( //тут необходимо выбрать правильный селектор, то есть тот див (к примеру) где у вас контент
            'copy',
            function()
            {
                var selection = window.getSelection();
                var range = selection.getRangeAt(0);

                var magic_div = $('<div>').css({ overflow : 'hidden', width: '1px', height : '1px', position : 'absolute', top: '-10000px', left : '-10000px' });
                magic_div.append(range.cloneContents(), source_link);
                $('body').append(magic_div);

                var cloned_range = range.cloneRange();
                selection.removeAllRanges();

                var new_range = document.createRange();
                new_range.selectNode(magic_div.get(0));
                selection.addRange(new_range);

                window.setTimeout(
                    function()
                    {
                        selection.removeAllRanges();
                        selection.addRange(cloned_range);
                        magic_div.remove();
                    }, 0
                );
            }
        );

});


jQuery(document).ready(function($) {
	$('.editcomm').click(function() {
		var id = $(this).data('id');

		var html = $('#comm-message-'+id).html();
		$('#comm-message-'+id).html('<textarea class="textdata'+id+'">'+html+'</textarea><br/><a class="button savedata" data-id="'+id+'">Сохранить</a>');

	        tinyMCE.init({selector:'.textdata'+id, language:'ru',
		plugins : 'advlist autolink link image jbimages lists charmap print preview code spellchecker',
		image_advtab: true,
		relative_urls: false, 
		remove_script_host: false,
		convert_urls: false,
		paste_postprocess: function (plugin, args) {
	          var
	              valid_elements = {
	                  /* Конфигурация правил форматирования */
	               };
	              htmlFormatting(args.node, valid_elements);
	          },
	    	// Spellchecker
		spellchecker_languages: "Russian=ru,Ukrainian=uk,English=en",
		spellchecker_language: "ru",  // default language
		spellchecker_rpc_url: "/tinyspell.php"//"http://speller.yandex.net/services/tinyspell"
		});
	});


	$(document).on('click','.savedata',function() {
		tinyMCE.triggerSave();
		var id = $(this).data('id');
		var html = $('.textdata'+id).val();
		//var html = $('#comm-message-'+id+' #tinymce').html();
		$('#comm-message-'+id).html(html);

		$.ajax({
		  type: "POST",
		  url: '',
		  data: {ajax:'1', event:'saveComm', id: id, mess: html},
//		  success: success,
//		  dataType: dataType
		});


	});



	$('.login-switch').click(function(){
		$.ajax({
		  type: "GET",
		  url: '/com/login/form/',
		  success: function(res) {$('#myLogin').html(res);},
//		  dataType: dataType
		});

		
	});

});
