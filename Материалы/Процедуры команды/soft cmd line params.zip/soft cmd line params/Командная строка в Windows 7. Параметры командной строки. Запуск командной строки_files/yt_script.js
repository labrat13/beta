//Page keeps reloading when I change iPad orientation
jQuery(window).bind('orientationchange', function (e) {
    switch (window.orientation) {
        case 0:
            //portrait mode
	     location.reload();
            break;
        case 90:
            //turned to the right
            location.reload();
            break;
        case -90:
            //turned to the left
            location.reload();
            break;
    }
});

/*window.onorientationchange = function() { 
	var orientation = window.orientation; 
	switch(orientation) { 
	case 0: window.location.reload(); 
	break; 
	case 90: window.location.reload(); 
	break; 
	case -90: window.location.reload(); 
	break; } 
};
*/
jQuery(document).ready(function($){
	//JS script Tet Holiday 
	scrollHoliday('.banner-text-holiday');
})

function scrollHoliday(wrap) {
	var $this = jQuery(wrap);
	var $viewportHeight  = jQuery(window).height(); 
	$this.css('height',$viewportHeight);
	$this.children('.yt-scroll-up').click(function(){
			$this.slideUp(800,function(){
				$this.next().removeClass('hidden');
			});
			
	});
	
	$this.next('.yt-scroll-down').click(function(){
			$this.fadeIn();
			$this.next().addClass('hidden');
			
	});
}

//JS script for Joomla template
window.addEvent ('load', function() {
     //Show Back To Top
     jQuery(".backtotop").addClass("hidden-top");
          jQuery(window).scroll(function () {
          if (jQuery(this).scrollTop() === 0) {
               jQuery(".backtotop").addClass("hidden-top")
          } else {
               jQuery(".backtotop").removeClass("hidden-top")
          }
     });

     jQuery('.backtotop').click(function () {
          jQuery('body,html').animate({
                    scrollTop:0
               }, 1200);
          return false;
     });
	 

});


function switchFontSize (ckname,val){
	var bd = document.getElementsByTagName('body');
	if (!bd || !bd.length) return;
	bd = bd[0];
	var oldclass = 'fs'+CurrentFontSize;
	switch (val) {
		case 'inc':
			if (CurrentFontSize+1 < 7) {
				CurrentFontSize++;
			}		
		break;
		case 'dec':
			if (CurrentFontSize-1 > 0) {
				CurrentFontSize--;
			}		
		break;
		case 'reset':
		default:
			CurrentFontSize = DefaultFontSize;			
	}
	var newclass = 'fs'+CurrentFontSize;
	bd.className = bd.className.replace(new RegExp('fs.?', 'g'), '');
	bd.className = trim(bd.className);
	bd.className += (bd.className?' ':'') + newclass;
	createCookie(ckname, CurrentFontSize, 365);
}
function trim(str, chars) {
	chars = chars || "\\s";
	str =   str.replace(new RegExp("^[" + chars + "]+", "g"), "");
	str =  str.replace(new RegExp("^[" + chars + "]+", "g"), "");
	return str;
}

function switchTool (ckname, val) {
	createCookie(ckname, val, 365);
	window.location.reload();
}
function createCookie(name,value,days) {
  if (days) {
    var date = new Date();
    date.setTime(date.getTime()+(days*24*60*60*1000));
    var expires = "; expires="+date.toGMTString();
  }
  else expires = "";
  document.cookie = name+"="+value+expires+"; path=/";
}


var boxes = [];
var ytoverlaywrap=null;
showBox = function (box,focusobj, caller, e) {
	if(!ytoverlaywrap){
		ytoverlaywrap=new Element('div',{id:"yt_overlaywrap"}).injectBefore($(box));
		ytoverlaywrap.setStyle('opacity',0.3);
		ytoverlaywrap.addEvent('click',function(e){boxes.each(function(box){
			if(box.status=='show'){
				box.status = 'hide';
				var fx = new Fx.Style (box,'opacity');
				fx.stop();
				fx.start (box.getStyle('opacity'), 0); //box.toggle();
				if (box._caller) box._caller.removeClass ('show');
			}
		},this);
		ytoverlaywrap.setStyle('display','none');
		});
	}
	caller.blur();
	
	box=$(box);
	if (!box) return;
	if ($(caller)) box._caller = $(caller);
	if(!boxes.contains(box)){
		boxes.include(box);
	}
	if(box.getStyle('display')=='none'){
		box.setStyles({display:'block',opacity:0}); //box.toggle();
	}
	if (box.status == 'show') {
		//hide
		box.status = 'hide';
		var fx = new Fx.Style (box,'opacity');
		fx.stop();
		fx.start (box.getStyle('opacity'), 0);
		if (box._caller) box._caller.removeClass ('show');
		ytoverlaywrap.setStyle('display','none');
	} else {
		boxes.each(function(box1){
			if (box1!=box && box1.status=='show') {
				box1.status = 'hide';
				var fx = new Fx.Style (box1,'opacity');
				fx.stop();
				fx.start (box1.getStyle('opacity'), 0);
				if (box1._caller) box1._caller.removeClass ('show');
			}
		},this);
		box.status = 'show';
		var fx = new Fx.Style (box,'opacity',{onComplete:function(){if($(focusobj))$(focusobj).focus();}});
		fx.stop();
		fx.start (box.getStyle('opacity'), 1);
		
		if (box._caller) box._caller.addClass ('show');
		ytoverlaywrap.setStyle('display','block');
	}
}



