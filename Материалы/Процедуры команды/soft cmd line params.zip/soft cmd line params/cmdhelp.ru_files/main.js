$(document).ready(function(){
    // правим ссылки
    /*** / // уже не нужно, но если хочется иметь в URL'е не /index.php?cmd=**?, а /?cmd=**, то раскомменть.
    $('a[href^="index.php?cmd="]').each(function (index, domEle) {
        $(domEle).attr('href', '/?cmd=' + $(domEle).attr('href').split('=')[1]);
    });
    /***/
    
    // убираем nobr
    $('nobr').each(function (index, domEle) {
        $(domEle).after($(domEle).html());
        $(domEle).remove();
    });
    
    // подкрашиваем таблицы
    $('table').addClass('table').addClass('table-striped').addClass('table-bordered');
    
    // убираем ХОХ
    $('span#cmdnotavail.reuse:contains(XOX)').parent().remove();
    $('li:empty').remove();
    
    // так как h1 один на страницу делаем его, как заголовок страницы
    $('h1:first').each(function (index, domEle) {
        var parent = $(domEle);
        parent.before('<div class="page-header" id="header"></div>');
        var element = $('div#header.page-header');
        element.html(parent);
        element.removeAttr('id');
    });
});