
; /* Start:"a:4:{s:4:"full";s:93:"/local/templates/zyxel/components/bitrix/system.auth.authorize/popup/script.js?14576176451714";s:6:"source";s:78:"/local/templates/zyxel/components/bitrix/system.auth.authorize/popup/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
$(document).ready(function () {
    $('form#login-form').submit(function (event) {
        event.preventDefault();
        var path = '/ajax/auth.php';
        var form = $(this);
        var formData = form.serialize();
        var button = form.find('button');
        button.attr("disabled", true);

        var success = function (response) {
            if (response == 'Y') {
                var backUrl = encodeURI($('#auth-back-url').val());
                window.location.href = backUrl ? backUrl : window.location.href;
            }
            else {
                $('#auth-error').html(response).show();
            }
            button.removeAttr("disabled");
        };

        $.ajax({
            type: 'POST',
            url: path,
            data: formData,
            crossDomain: true,
            success: success,
            dataType: 'html'
        });

        return false;
    });

    $('form#forgot-password-form').submit(function () {

        var path = '/ajax/forgot-password.php';
        var form = $(this);
        var formData = form.serialize();
        var button = form.find('button');
        button.attr("disabled", true);

        var success = function (response) {
            if (response == 'Y') {
                $('form#forgot-password-form').hide();
                $('#forgot-password-success').show();
            }
            else {
                $('#forgot-password-error').html(response).show();
            }

            button.removeAttr("disabled");
        };

        var responseType = 'html';

        $.post(path, formData, success, responseType);

        return false;
    });
});
/* End */
;; /* /local/templates/zyxel/components/bitrix/system.auth.authorize/popup/script.js?14576176451714*/
