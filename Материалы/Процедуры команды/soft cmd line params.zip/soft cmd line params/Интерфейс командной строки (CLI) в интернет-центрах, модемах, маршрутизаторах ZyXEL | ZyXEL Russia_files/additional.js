$(document).on('change', '.add-model-to-compare-checkbox', function(e) {
    e.preventDefault();
    var that = this;
    var el = $(this);

    var data = {
        set: el.attr('data-set'),
        model: el.attr('data-model')
    };

    if (!el.is(':checked')) {
        data.remove = 1;
    }

    $.ajax({
        dataType: "json",
        url: "/ajax/add-model-to-compare.php",
        data: data,
        success: function(json) {
            $('.add-model-to-compare-counter[data-set='+ data.set +']').each(function() {
                $(this).html(json.new_count ? '('+ json.new_count + ')' : '');
            });

            //toggle other checkbox for this model
            $('.add-model-to-compare-checkbox[data-model='+ data.model +']').not(that).each(function() {
                $(this).parent().toggleClass('active');
                $(this).prop("checked", !$(this).prop("checked"));
            })
        }
    });
});
//Получить GET параметр из строки
function $_get(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);

    return results === null ? null : decodeURIComponent(results[1].replace(/\+/g, " "));
}
//Cookie
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) {
            return decodeURIComponent(c.substring(nameEQ.length,c.length));
        }
    }
    return null;
}
