Vue.directive('select', {

    // Since we expect to sync value back to the vm,
    // we need to signal this is a two-way directive
    // so that we can use `this.set()` inside directive
    // functions.
    twoWay: true,

    bind: function () {
        var optionsData;
        // retrieve the value of the options attribute
        var optionsExpression = this.el.getAttribute('options')
        if (optionsExpression) {
            // if the value is present, evaluate the dynamic data
            // using vm.$eval here so that it supports filters too
            optionsData = this.vm.$eval(optionsExpression)
        }
        // initialize select2
        var self = this;
        $(this.el)
            .select2({
                data: optionsData,
                selectOnBlur: true,
                language: {
                    "noResults": function(){
                        return "Не найдено";
                    }
                },
                minimumResultsForSearch: $(this.el).data('search') ? 1 : -1
            })
            .on('change', function () {
                // sync the data to the vm on change.
                // `self` is the directive instance
                // `this` points to the <select> element
                self.set(this.value)
            })
    },

    update: function (value) {
        // sync vm data change to select2
        $(this.el).val(value).trigger('change')
    },

    unbind: function () {
        // don't forget to teardown listeners and stuff.
        $(this.el).off().select2('destroy')
    }
});

Vue.directive('customcheckbox', {
    bind: function () {
        var el = $(this.el);
        if (el.attr('checked') || $(this.el).prop('checked')) {
            el.prop('checked', true);
            el.parent('label').addClass('active');
        }else {
            el.prop('checked', false);
            el.parent('label').removeClass('active');
        }

        el.off('click');
        el.on('click', onCheckClick);
        function onCheckClick() {
            $(this).parent().toggleClass('active');
        }
    },
    unbind: function () {
        var that = this.el;
        var el = $(this.el);
        if (el.prop('checked')) {
            el.prop('checked', false);
            el.parent('label').removeClass('active');
            var data = {
                set: el.attr('data-set'),
                model: el.attr('data-model')
            };

            data.remove = 1;

            $.ajax({
                dataType: "json",
                url: "/ajax/add-model-to-compare.php",
                data: data,
                success: function (json) {
                    el.prop('checked', false);
                    el.parent('label').removeClass('active');
                    $('.add-model-to-compare-counter[data-set=' + data.set + ']').each(function () {
                        $(this).html(json.new_count ? '(' + json.new_count + ')' : '');
                    });
                }
            });
        }
    }
});

Vue.transition('fade', {
    css: false,
    enter: function (el, done) {
        $(el)
            .css('opacity', 0)
            .animate({ opacity: 1 }, 500, done)
    },
    leave: function (el, done) {
        $(el).fadeOut(500, done)
    }
});
