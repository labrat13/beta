﻿var _nextMenuIndex = 0;

function makeMenu(containerId)
{
  var container = document.getElementById(containerId);
  var borderRadius = "border-bottom-right-radius:10px;border-top-right-radius:10px;";
 container.innerHTML = "<table valign='top' id='menu' border='0' cellpadding='1' cellspacing='1' style='background-color:white;background-image:url(/MasterPage/MenuBack.Png);background-repeat:repeat-x;float:left;" + borderRadius + "'> </table>";
  var table = container.childNodes[0];
 
  row = table.insertRow(0);
  
  var cell = row.insertCell(-1);
  cell.innerHTML = "<span>&nbsp;&nbsp;</span>";
  
  var subList = addTopMenu(row, "Home", "/Topics/NavWin/NavWin.aspx");
  // Add a dummy button to the home menu to ensure correct vertical alignment,
  // relative to the other menu itemsin the top level
  /*
  var dummyButton = insertExpandButton(subList);
  dummyButton.style.visibility = "hidden";
  dummyButton.style.value = "";
  dummyButton.style.margin = "0";
  dummyButton.style.padding = "0";
  dummyButton.style.width = "2px"; // firefox seems to only understand 2px and not 1px
  dummyButton.style.borderLeftWidth = "0px";
  dummyButton.style.borderRightWidth = "0px";
*/

  subList = addTopMenu(row, "Go To Web Apps", "https://www.navwin.com/webapps.aspx");
  var item=appendItem(subList, 'Foreign Vocab. and Spelling Test','https://www.navwin.com/WebApps.Aspx#SpellingTestSelect&SelectLanguage@ModelSpellingTestSelect');
  item=appendItem(subList, 'Cash Flow','https://www.navwin.com/WebApps.Aspx#CashFlow&CashFlow@ModelCashFlow');
  item=appendItem(subList, 'Fun Maths Quiz','https://www.navwin.com/WebApps.Aspx#MathsQuiz&MathsQuiz@ModelMathsQuiz');
  item=appendItem(subList, 'Midi File Creator','https://www.navwin.com/webapps.aspx#Midi&Folders@ModelMidi');
  item=appendItem(subList, 'Pocket Money Tracker','https://www.navwin.com/WebApps.Aspx#PocketMoneyTracker&PocketMoneyTracker@ModelPocketMoneyTracker');
  item=appendItem(subList, 'Portfolio Profit And Loss Calculator','https://www.navwin.com/WebApps.Aspx#Portfolio&Portfolio@ModelPortfolio');
  item=appendItem(subList, 'Statistical Process Control (SPC)','https://www.navwin.com/WebApps.Aspx#SPC&PresenterSPC@ModelSPC');
  item=appendItem(subList, 'SSL Portal','https://www.navwin.com/WebApps.Aspx#SSLPortal&SSLPortal@ModelSSLPortal');
  item=appendItem(subList, 'Task Scheduler','https://www.navwin.com/WebApps.Aspx#TaskScheduler&TaskSchedule@ModelTaskScheduler');
  item=appendItem(subList, 'Time Zone Friends','https://www.navwin.com/WebApps.Aspx#TimeZoneFriends&TimeZoneFriends@ModelTimeZoneFriends');

  buildMainMenu(row);
  // add the end curve
  cell = row.insertCell(-1);
  cell.innerHTML = "<span>&nbsp;&nbsp;</span>";

}
function getNextMenuIndex()
{
  _nextMenuIndex++;
  return "NWMenu" + _nextMenuIndex;
}
function addTopMenu(row, caption, href)
{

  var cell = row.insertCell(-1);
  cell.valign="top";
  cell.style.whiteSpace ="nowrap";
  var list =  document.createElement("ul");
  cell.appendChild(list);
  list.className = "topMenu";
  list.style.padding="0";
  list.style.margin="0";
  list.id = getNextMenuIndex();

  var item = document.createElement("li");
  item.className = "topMenuItem";
  item.innerHTML = "<a href='" + href + "'>" + caption + "&nbsp;</a>";
  item.style.padding="0";
  item.style.margin="0";
  list.appendChild(item);
  var subList = appendSubList(item);
  subList.style.position = 'absolute';
  subList.style.padding="0";
  subList.style.margin="0";

  // Prototype for quick lookup
  subList.protoIsTopLevel = true;
  subList.protoIsSecondLevel = false;

  return subList ;
}

function appendSubList(item)
{
  var subList =  document.createElement("ul");
  subList.id = getNextMenuIndex();
  subList.className = "menu";
  subList.style.display = "none";

  if (item.parentNode.className == "topMenu")
  {
    subList.style.boxShadow = "5px 5px 2px #888";
    subList.style.padding = "0";
    subList.style.paddingBottom = "3px";
    subList.style.paddingTop = "3px";
    subList.protoIsSecondLevel = true;
  }
  else
  {
    subList.protoIsSecondLevel = false;
  }
  
  item.appendChild(subList);
  // Prototype for quick lookup
  subList.protoIsTopLevel = false;
  
  return subList;
}

function insertExpandButton(subList)
{
    var button = document.createElement("input");
    button.type = "button";
    button.value = "+";
    button.id = getNextMenuIndex();
    button.style.fontFamily = "courier";
    button.onmouseover = new Function('showPath(this);');
    button.onclick = new Function('clickHide(this);');
    button.ontouchstart = new Function('disableNextShowPath(this);');
    // Prototype for quick lookup
    subList.protoButtonId = button.id;
    button.protoSubListId = subList.id;
    subList.parentNode.insertBefore(button, subList.parentNode.childNodes[0]);
    return button;
}
function appendItem(subList, caption, href)
{
  
  if (subList.childNodes.length == 0)
  {
    insertExpandButton(subList);
  }

  var item = document.createElement("li");
  item.className = "menuItem";
  item.innerHTML = "<a href='" + href +"'>" + caption + "</a>";
  item.style.paddingLeft = "15px";
  item.style.paddingRight = "5px";
  
  subList.appendChild(item);

  return item;
}

function getTopMenuId(elem)
{
  var parent = elem.parentNode;
  if (parent == null)
    return ""; // outside of browser window
    
  while (parent.nodeName != "TD")
  {
    parent = parent.parentNode;
    if (parent == null)
      return ""; // outside of browser window
  }
  return parent.childNodes[0].id;
}

var _activeMenuId = null;

function getListElements(parent)
{
  return parent.getElementsByTagName("UL");
}
function expandAll(topLevelId)
{
  var parent = document.getElementById(topLevelId);
  var nodes = getListElements(parent);
  for (i = 0; i < nodes.length; i++)
  {
    show(nodes[i]);
  }
}
function collapseAll(topLevelId)
{
  var parent = document.getElementById(topLevelId);
  var nodes = getListElements(parent);

  for (i = 0; i < nodes.length; i++)
  {
    hide(nodes[i]);
  }
}
function getButtonList(button)
{
  var item = button.parentNode; // this is an LI element
  for (i = 0; i < item.childNodes.length; i++)
  {
    if (item.childNodes[i].nodeName == "UL")
    {

      return item.childNodes[i];
    }
  }
  alert('button list not found from button');
  return null;
}
function getButtonFromList(list)
{

  var item = list.parentNode; // this is an LI element
  for (i = 0; i < item.childNodes.length; i++)
  {
    if (item.childNodes[i].nodeName == "INPUT")
    {
      return item.childNodes[i];
    }
  }
  alert('button not found from list');
  return null;
}
var _disableNextShowPath = false;

function disableNextShowPath(button)
{
  _disableNextShowPath = true;
}
// Used when hovering over a button
function showPath(button)
{
  if (_disableNextShowPath)
  {
    return;
  }
  var topLevelId = getTopMenuId(button);
  if (_activeMenuId != null)
  {
    if (_activeMenuId != topLevelId)
      collapseAll(_activeMenuId);
  }
  _activeMenuId = topLevelId;

  var subList = getButtonList(button);

  var topElem = document.getElementById(topLevelId);
  var nodes = getListElements(topElem);
  // store the expanded nodes
  var expanded = new Array();

  for (i = 0; i < nodes.length; i++)
  {
     if (subList == nodes[i])
      break;
      
    if (isExpanded(nodes[i]))
      expanded.push(nodes[i]);
  }
  expandPath(topLevelId, subList);

  for (i = 0; i < expanded.length; i++)
  {
    show(expanded[i]);
  }
}
function isExpanded(elem)
{
  if (elem.style.display == null)
    return false;
  else
    return elem.style.display != "none";
}
// Shows all the nodes in the current site path
function expandPath(topLevelId, elem)
{
  var topElem = document.getElementById(topLevelId);
  var nodes = new Array();
  nodes.push(elem);


  while (elem.parentNode != null && elem.parentNode != topElem)
  {
    elem = elem.parentNode;
    if (elem.nodeName == "UL")
    {
      nodes.push(elem);
    }
  }

  collapseAll(topLevelId);

  for (i = nodes.length - 1; i >= 0; i--)
  {
    show(nodes[i]);
  }  
}
function clickHide(button)
{

  var topLevelId = getTopMenuId(button);
  if (_activeMenuId != null)
  {
    if (_activeMenuId != topLevelId)
    {
      collapseAll(_activeMenuId);
    }
  }
 _activeMenuId = topLevelId;


  var subList = getButtonList(button);
  if (subList.protoIsTopLevel)
  {
    if (isExpanded(subList))
      collapseAll(_activeMenuId);
    else
      expandAll(_activeMenuId);
  }
  else
  {
    if (isExpanded(subList))
      hide(subList);
    else
      show(subList);
  }
}
function show(subList)
{
  subList.style.display="block";
  button = document.getElementById(subList.protoButtonId);
  button.value = "-";
}
function hide(subList)
{
  subList.style.display="none";
  button = document.getElementById(subList.protoButtonId);
  button.value = "+";
}
// Called in the body 'onmouseout' event, to collapse the menu if the mouse moves away from it
function checkClose(e)
{
  if (_activeMenuId == null)
    return;

//http://www.quirksmode.org/js/events_properties.html#position
  var posx = 0;
  var posy = 0;
  
  if (!e)
    e = window.event;
    
  if (e.pageX || e.pageY)
  {
    posx = e.pageX;
    posy = e.pageY;
  }
  else if (e.clientX || e.clientY)
  {
    posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
    posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
  }
 
  var elem = document.elementFromPoint(posx, posy);

//  var topElem = document.getElementById("menu");
  var topElemId = getTopMenuId(elem);
  var topElem = document.getElementById(topElemId);
  var parent = elem;
  while (parent != null)
  {
    if (parent == topElem)
      return;

    parent = parent.parentNode;
  }

  collapseAll(_activeMenuId);
  _activeMenuId = null;
 
}