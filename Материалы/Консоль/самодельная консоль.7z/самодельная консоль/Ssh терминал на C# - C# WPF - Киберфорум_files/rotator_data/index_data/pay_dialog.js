function PayDialog() {

    var self = this;

    /**
     * Кнопки видов оплаты
     * @param data {{n,t}[]}
     * @return {HTMLElement[]}
     */
    function payTabs (data) {
        var temp = data.map(function (item, i) {
            return createDom({
                tag: 'button', type:'button', 'data-type': item.n,
                className: "tvz-btn tvz-payments-tab tab " + item.n,
                innerHTML: item.t
            })
        });

        temp.unshift(createDom({className: "tvz-payments-tabs-title", innerHTML:'Выберите вариант оплаты:'}));

        return temp;

    }

    /**
     * Форма оплаты
     * @param data {{elem:[], cls}}
     * @return {HTMLElement[]}
     */
    function payForms (data) {
        return createDom({className: "tvz-payments-form " + data.cls}).appEndChild(
            data.elem.map(function (item) {
                var isBtn = item.type === 'button';
                return createDom({className: 'tvz-payments-block tvz-payments-block-' + item.cls, 'data-type': item.type})
                    .appEndChild(item.before && item.before.map(createDom))
                    .appEndChild([
                        !isBtn && createDom({className: 'tvz-payments-block-title', innerHTML: item.text}),
                        createDom({
                            tag: 'input', name: item.name, type: item.type, "data-inputmask": item.mask,
                            className: isBtn ? 'tvz-btn tvz-payments-submit disabled '+item.name : 'tvz-input tvz-payments-field',
                            placeHolder: item.ph, value: isBtn && item.text
                        })
                    ])
                    .appEndChild(item.after && item.after.map(createDom))
            })
        )
    }

    this.wrapper = createDom({className:'tvz-widget'}).appEndChild([
        this.start = createDom({
            className: 'tvz-payments-start tvz-btn tvz-btn-t1', "data-ready": 'Купить', "data-error": 'Ошибка'
        }).appEndChild((new Array(5)).join('.').split('.').map(function(){return createDom({})})),
        this.payments = createDom({className: 'tvz-payments', id: 'tvz_payments'}).appEndChild([
            createDom({className: "tvz-payments-info"}).appEndChild([
                createDom({className: "tvz-payments-info-left"}).appEndChild([
                    createDom({className: "tvz-payments-info-title txt-ellpss", id:"clip_name"}),
                    this.tabs = createDom({className: "tvz-payments-tabs"}).appEndChild(
                        payTabs([{n:'card',t:'Карта банка'},{n:'phone',t:'СМС'}])
                    )
                ]),
                createDom({className: "tvz-payments-info-right"}).appEndChild([
                    createDom({className: "tvz-payments-info-cost", innerHTML:'цена', id: "clip_price"}),
                    createDom({className: "tvz-payments-info-tariff", id: 'clip_description',
                        innerHTML:'Фильм будет доступен всегда.<br/>Без ограничений по времени<br/>и количеству просмотров'
                    })
                ])
            ]),
            this.forms = createDom({className: "tvz-payments-forms"}).appEndChild(payForms({
                cls: "card",
                elem: [
                    {cls: 'number', text: 'Номер карты', name: 'card:number', type: 'cardNumber',
                        mask: "'mask': '9999 9999 9999 9999', 'placeholder': 'xxxx xxxx xxxx xxxx'"
                    },
                    {cls: 'date', text: 'Срок действия', name: 'card:month', ph: 'Месяц', type: 'expDateMonth',
                        mask: "'mask': '99'",
                        after: [
                            {tag: 'span', className: "tvz-payments-block-devider", innerHTML: '/'},
                            {tag: 'input',className: "tvz-input tvz-payments-field", name:"card:year",
                                placeholder:"Год", "data-inputmask":"'mask': '99'", type: 'expDateYear'
                            }
                        ]
                    },
                    {cls: 'cvc', text: 'CVC/CVV код', name: 'card:cvv', ph: '123',
                        mask: "'mask': '999'"
                    },
                    {cls: 'name', text: 'Имя держателя, как на карте', name: 'card:holder', ph: 'CARD HOLDER',
                        mask: "'alias': 'cardholder'", type: 'name',
                        after: [{
                            className: "tvz-payments-block-help",
                            innerHTML: "Принимаются только Visa/Mastercard"
                        }]
                    },
                    {cls: 'send', text: 'Оплатить', name: 'card', type: 'button'}
                ]
            })).appEndChild(payForms({
                cls: 'phone',
                elem: [
                    {cls: 'phone', text: 'Номер телефона', name: 'phone:number', ph: 'PHONE NUMBER', type: 'tel',
                        mask: "'mask': '+7 (999) 999-99-99', 'placeholder': '+7 (900) 000 00 00', 'autoUnmask' : 'true'"
                    },
                    {cls: 'phone-send', text: 'Оплатить', name: 'phone', type: 'button',
                        before: [{
                            className: "tvz-payments-block-send-description",
                            innerHTML: "Если Ваш номер телефона зарегистрирован на юридическое <br/>" +
                            "лицо, то оплата с лицевого счета для <br/>" +
                            "Вас недоступна. Оплачивайте услуги банковской картой."
                        }]
                    }
                ]
            }))
        ]).appEndChild([
            this.state = createDom({className:'txt-ellpss tvz-payments-state'}),
            this.close = createDom({className:'tvz-payments-close'})
        ])
    ]);

    document.body.appendChild(this.wrapper);

    this.wrapper = $(this.wrapper);
    this.inputs = this.wrapper.find(':input:not(:button)');
    this.submits = this.wrapper.find('.tvz-payments-submit');
    this.start = $(this.start); this.payments = $(this.payments);
    this.tabs = $(this.tabs); this.forms = $(this.forms);
    this.state = $(this.state); this.close = $(this.close);


    this.render = function(data){
        Object.keys(data).forEach(function (key) {
            key === 'description' && (
                data[key] = 'Фильм будет доступен после оплаты. Начать просмотр необходимо в течение 30 дней после оплаты.'
            );
            var el; if (el = $('#clip_' + key)) el.text(data[key]);
        });
    };

    this.disable = function(message){
        $('body').addClass('disable').text(message || 'К сожалению, просмотр фильма невозможен.');
    };

    this.validate = function (type, clear) {
        var elem = $("[data-type="+type+"]").find('input');
        clear ? elem.removeClass('error') : elem.addClass('error');
    };

    this.modifyBtnText = function (text) {
        var span = this.start.find('span');
        span[0] ? span.html(text) : this.start.append(createDom({tag:'span', innerHTML: text}));
        return this.start;
    };

    this.setHandlers = function (tvz) {

        Inputmask.extendAliases({
            'cardholder': {
                autoUnmask: true,
                mask: 'A{1,20}[ ]A{1,20}',
                validator: /^[A-Z\s]+$/,
                casing: 'upper'
            }
        });

        var fields = {
            disabled: 'disabled',
            card: {limit: 5, values:[], submit:  self.submits.eq(0)},
            phone: {limit: 1, values:[], submit: self.submits.eq(1)},
            current: null,
            check: function(input, index, state){
                var namespace = input.name.split(':');
                var form = this[namespace[0]];
                this.current = index;
                var value = !!(~form.values.indexOf(index));
                if(state){
                    // Clear Error
                    self.validate(input.parentNode.dataset.type, true);
                    if (!$(input).parents('.tvz-payments-form').find(".error").length){
                        self.state.removeClass("error").empty();
                    }
                    if(!value){
                        form.values.push(index);
                    }
                } else {
                    if(value){
                        form.values.splice(form.values.indexOf(index),1);
                    }
                }
                form.submit.toggleClass(this.disabled, !(form.values.length === form.limit));
            }
        };

        self.inputs.each(function (index, el) {
            $(el).inputmask(undefined, {
                autoUnmask: false,
                'oncomplete': function () {
                    fields.check(el, index, true);
                    var next = self.inputs[index + 1];
                    if (next) {
                        next.focus();
                    }
                },
                'onincomplete': function () {
                    fields.check(el, index, false);
                },
                'onKeyDown': function (event, buffer, caretPos, opts) {
                    if (!opts.isComplete) {
                        fields.check(event.target, index, false);
                    }
                },
                'oncleared': function () {
                    var prev = self.inputs[index - 1];
                    if (prev) {
                        prev.focus();
                    }
                }
            });
        });

        // init context (payments) and trigger widget start event
        tvz.ui.start.on('click', function(){
            tvz.context.init(tvz.data.content, function(result){
                if(result){
                    tvz.state = 'started';
                    tvz.ui.render(tvz.data.content);
                    $(tvz).trigger('start', [result]);
                }
            });
        });
        // submit values from payment forms
        tvz.ui.submits.on('click', function(e){
            var type = e.target.name;
            $(tvz).trigger('submit', [{target: this, type: type, action:'start'}]);
        });
        // close widget
        tvz.ui.close.on('click', function(e){
            var type = e.target.name;
            $(tvz).trigger('close', [{target: this, type: type, action:'close'}]);
        });

        $(tvz).on('ready error wait', function (e, data) {
            _log(e.type || 'info', '@widget:event: ' + e.type, data);
            self.wrapper.addClass(e.type || tvz.state);
            // show widget start button or do something else...
            var msg = self.start.data();
            self.modifyBtnText(msg[e.type]||'').show();
        });

        // widget pay button clicked -> returns available payment types
        $(tvz).on('start', function (e, data) {
            _log('info', '@widget:event: start', data);
            var tabs = self.tabs.find('.tab');
            for (var name in data) {
                var type = data[name].type;
                self.payments.addClass(type);
                var tab = $(tabs).filter('.' + type).show();
                tab.click(function () {
                    var current = '.' + $(this).data('type');
                    $(tabs).removeClass('current');
                    $(this).addClass('current');
                    self.forms.children().hide().end().find(current).show().find(':input')[0].focus();
                });
            }
            self.wrapper.addClass(tvz.state);
            tabs[0].click();
        });

        // some payment form submitted
        $(tvz).on('submit', function (e, data) {
            _log('info', '@widget:event: submit', data);
            // Exit if disabled
            if (tvz.ui.submits.filter('.'+data.type + '.disabled').length) return null;
            var target = $(data.target).parents('.tvz-payments-form.' + data.type);
            var values = target.find('input:not(:button)').map(function () { // get values of fields for submited type
                return this.value.replace(/\s/g, '');
            }).toArray();
            if (values) { // if all valid -> call context[action] with [data.type, [values]
                _log('values', values);
                tvz.context[data.action](data.type, values);
            } else {
                //do something about validation
                _log('warn', 'no values submited');
            }
        });

        // close widget
        $(tvz).on('close', function () {
            self.wrapper.removeClass('started');
        });

        // payment process events
        $(tvz).on('stateChange', function (e, data) {
            _log('warn', '@widget:event:stateChange: ' + data.state, data);
            var setMSG = function (msg) {
                if (msg) {
                    self.state.css('width','');
                    return msg;
                }
                self.state.css('width','265px');
                return 'Платежная система недоступна. Попробуйте позже.';
            };
            self.state.removeClass(data.prev).addClass(data.state).text(
                data.show ? setMSG(data.message) : data.message ? setMSG() : ''
            );

            self.wrapper.removeClass(data.prev).addClass(data.state);

            if (data.state === 'complete') {
                if (data.message === 'PAYMENT_CONFIRMED') {
                    _log('...payment confirmed. starting playback');
                    self.wrapper.removeClass(tvz.states.join(' ')).show();
                    tvz.deactivate();
                    $(tvz).trigger('wait');
                }
            }

            if (data.state === 'pending') self.state.text('Ожидайте смс с подтверждением оплаты.');

        });
    }

}
