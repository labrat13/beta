﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CompactWindowTest
{
    //все задачи выполнены:
    //сейчас форма сворачивается и разворачивается правильно:
    //при закрытии форма должна сворачиваться и не показываться на панели задач
    //а при клике по значку в трее - должна открываться обратно в том же виде как была закрыта
    //сворачивание и разворачивание формы - должно быть как обычно.
    //и она принимает сообщения о вставке и извлечении флешки

    //а еще нотифу икон может показывать извещения о произошедших событиях (пока основное окно не развернуто)
    //(то есть, надо еще отмечать как-то, что основное окно скрыто и вывод идет через уведомления.)
    //и меню, в котором можно закрыть приложение не разворачивая или сделать еще что-то.

    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            this.notifyIcon1.Visible = false;
            // Show the form when the user double clicks on the notify icon.
            this.Visible = true;
            // Set the WindowState to normal if the form is minimized.
            if (this.WindowState == FormWindowState.Minimized)
                this.WindowState = FormWindowState.Normal;
            
            // Activate the form.
            this.Activate();

        }



        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //окно закрывается, но это можно отменить

            //если это пользователь закрывает окно, то делать его невидимым
            //а остальные случаи - системные, тут нет смысла прятать окно, тут надо сохранять данные и состояние перед завершением процесса.
            if (e.CloseReason == CloseReason.UserClosing)
            {
                this.notifyIcon1.Visible = true;
                //minimize window
                this.WindowState = FormWindowState.Minimized;
                //hide window
                this.Visible = false;
                //cancel closing
                e.Cancel = true;
            }
            //else TODO: тут надо сохранять данные и готовиться к завершению работы приложения
            return;
        }


        /// <summary>
        /// A device or piece of media has been inserted and is now available.
        /// </summary>
        private const int DBT_DEVICEARRIVAL = 0x8000;
        /// <summary>
        /// A device or piece of media has been removed.
        /// </summary>
        private const int DBT_DEVICEREMOVECOMPLETE = 0x8004;
        ///// <summary>
        ///// A device has been added to or removed from the system.
        ///// </summary>
        //private const int DBT_DEVNODES_CHANGED = 0x0007;
        /// <summary>
        /// код сообщения окну
        /// </summary>
        private const int WM_DEVICECHANGE = 0x0219;

        protected override void DefWndProc(ref Message m)
        {
            base.DefWndProc(ref m);

            //тут обработать сообщение
            if (m.Msg == WM_DEVICECHANGE)
            {
                int w = m.WParam.ToInt32();
                if ((w == DBT_DEVICEARRIVAL) || (w == DBT_DEVICEREMOVECOMPLETE))
                {
                    MessageBox.Show( "message");
                }
            }
            return;
        }

    }
}
