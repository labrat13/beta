﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Threading;

namespace ChatLibrary2
{
    /// <summary>
    /// Коллекция участников чата
    /// </summary>
    public class ChatMemberDictionary
    {
        /// <summary>
        /// Словарь участников чата
        /// </summary>
        private Dictionary<String, ChatMember> m_dict;
        /// <summary>
        /// Объект синхронизации доступа к списку участников для рассылки сообщений
        /// </summary>
        private static Mutex m_mutex = new Mutex();

        public ChatMemberDictionary()
        {
            m_dict = new Dictionary<string, ChatMember>(8);
        }





        /// <summary>
        /// NT-Добавить объект участника в словарь
        /// </summary>
        /// <param name="memberName"></param>
        /// <param name="member"></param>
        public void Add(string memberName, ChatMember member)
        {
            m_dict.Add(memberName, member);
        }
        /// <summary>
        /// NT-Отправить сообщение каждому участнику в словаре
        /// </summary>
        /// <param name="msg">Рассылаемое сообщение</param>
        public void broadcast(ChatMessage msg)
        {
            //TODO: тут надо бы предусмотреть критическую секцию
            //так как несколько потоков одновременно могут использовать  этот код
            //и их сообщения могут отсылаться для одного и того же сокета
            // Wait until it is safe to enter.
            m_mutex.WaitOne();

            //каждому участнику отправить сообщение
            foreach (KeyValuePair<String, ChatMember> kvp in m_dict)
            {
                kvp.Value.SendMessage(msg);
            }
            //release thread synchronization object
            m_mutex.ReleaseMutex();

            return;
        }
    }
}
