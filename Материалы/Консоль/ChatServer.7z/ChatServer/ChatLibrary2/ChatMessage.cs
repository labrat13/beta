﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace ChatLibrary2
{
    /// <summary>
    /// Сообщение чата
    /// </summary>
    [Serializable]
    public class ChatMessage
    {


        /// <summary>
        /// Идентификатор автора сообщения
        /// </summary>
        private String m_Autor;

        /// <summary>
        /// Идентификатор адресата сообщения, или пустая строка, если сообщение для всех.
        /// </summary>
        private string m_Addressat;

        /// <summary>
        /// Таймштамп отправки сообщения
        /// </summary>
        private DateTime m_Timestamp;

        /// <summary>
        /// Содержание сообщения
        /// </summary>
        private String m_Content;


        public ChatMessage()
        {
            m_Addressat = String.Empty;
            m_Autor = String.Empty;
            m_Content = String.Empty;
            m_Timestamp = DateTime.Now;
        }
        /// <summary>
        /// NT-Parametrized constructor
        /// </summary>
        /// <param name="autor">Автор сообщения</param>
        /// <param name="addressat">Получатель сообщения</param>
        /// <param name="text">Текст сообщения</param>
        public ChatMessage(String autor, String addressat, String text)
        {
            m_Addressat = addressat;
            m_Autor = autor;
            m_Content = text;
            m_Timestamp = DateTime.Now;
        }

       /// <summary>
        /// Идентификатор автора сообщения
        /// </summary>
        public String Autor
        {
            get { return m_Autor; }
            set { m_Autor = value; }
        }

        /// <summary>
        /// Идентификатор адресата сообщения, или пустая строка, если сообщение для всех.
        /// </summary>
        public string Addressat
        {
            get { return m_Addressat; }
            set { m_Addressat = value; }
        }

        /// <summary>
        /// Таймштамп отправки сообщения
        /// </summary>
        public DateTime Timestamp
        {
            get { return m_Timestamp; }
            set { m_Timestamp = value; }
        }

        /// <summary>
        /// Содержание сообщения
        /// </summary>
        public String Content
        {
            get { return m_Content; }
            set { m_Content = value; }
        }
        /// <summary>
        /// NT-Сериализовать объект в XML-строку
        /// </summary>
        /// <returns></returns>
        public string Serialize()
        {
            StringBuilder sb = new StringBuilder();
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StringWriter file = new System.IO.StringWriter(sb, CultureInfo.InvariantCulture);
            writer.Serialize(file, this);
            file.Close();

            return sb.ToString();
        }
        /// <summary>
        /// NT-десериализовать объект из XML-строки
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static ChatMessage Deserialize(string p)
        {
            ChatMessage tmp = new ChatMessage();
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(tmp.GetType());
            System.IO.StringReader file = new System.IO.StringReader(p);
            tmp = (ChatMessage)reader.Deserialize(file);
            file.Close();
            return tmp;
        }
        /// <summary>
        /// Создать сообщение о подключении нового участника
        /// </summary>
        /// <param name="memberName">Имя участника</param>
        /// <returns></returns>
        public static ChatMessage AddMemberMessage(String memberName)
        {
            return new ChatMessage(ChatMember.ServerName, ChatMember.AllName, String.Format("{0} подключился", memberName));
        }
        /// <summary>
        /// Создать сообщение об отключении участника
        /// </summary>
        /// <param name="memberName">Имя участника</param>
        /// <returns></returns>
        public static ChatMessage DeleteMemberMessage(String memberName)
        {
            return new ChatMessage(ChatMember.ServerName, ChatMember.AllName, String.Format("{0} отключился", memberName));
        }
    }
}
