﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatLibrary2
{
    /// <summary>
    /// Коллекция сообщений чата
    /// </summary>
    public class ChatMessageCollection
    {
        /// <summary>
        /// Список сообщений чата
        /// </summary>
        private List<ChatMessage> m_MessageList;




        public ChatMessageCollection()
        {
            m_MessageList = new List<ChatMessage>(64);
        }
        /// <summary>
        /// Список сообщений чата
        /// </summary>
        public List<ChatMessage> MessageList
        {
            get { return m_MessageList; }
            set { m_MessageList = value; }
        }



    }
}
