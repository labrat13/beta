﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace ChatLibrary2
{
    /// <summary>
    /// Аргумент для события входящего сообщения для класса ChatMember
    /// </summary>
    public class ChatMessageEventArgs : EventArgs
    {
        /// <summary>
        /// Объект сообщения
        /// </summary>        
        private ChatMessage m_message;
        /// <summary>
        /// Объект сообщения
        /// </summary>
        public ChatMessage Message
        {
            get { return m_message; }
            set { m_message = value; }
        }
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="msg">Объект сообщения</param>
        public ChatMessageEventArgs(ChatMessage msg)
        {
            this.m_message = msg; //or copy of this object?
        }
    }
    /// <summary>
    /// Делегат для события входящего сообщения для класса ChatMember
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void ChatMessageReceivedEventHandler(object sender, ChatMessageEventArgs e);
    
    /// <summary>
    /// Объект участника чата. Используется и на стороне сервера и на стороне клиента.
    /// </summary>
    public class ChatMember
    {
        /// <summary>
        /// Имя участника Сервер
        /// </summary>
        public static string ServerName = "Server";
        /// <summary>
        /// Имя участника Всем
        /// </summary>
        public static string AllName = "All";
        
        /// <summary>
        /// Идентификатор участника чата
        /// </summary>
        private string m_MemberName;

        /// <summary>
        /// Клиентский сокет участника чата
        /// </summary>
        private TcpClient m_Client;
        /// <summary>
        /// Флаг управляющий остановкой потока приема сообщений
        /// </summary>
        private bool m_workFlag;

        /// <summary>
        /// Принято новое сообщение
        /// </summary>
        public event ChatMessageReceivedEventHandler ChatMessageReceived;

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        public ChatMember()
        {
            m_MemberName = "Member";
            m_Client = new TcpClient();
        }
        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="c"></param>
        public ChatMember(TcpClient c)
        {
            m_Client = c;
            m_MemberName = "Member";
        }

        /// <summary>
        /// Идентификатор участника чата
        /// </summary>
        public string MemberName
        {
            get { return m_MemberName; }
            set { m_MemberName = value; }
        }
        /// <summary>
        /// Клиентский сокет участника чата
        /// </summary>
        public TcpClient Client
        {
            get { return m_Client; }
            set { m_Client = value; }
        }

        /// <summary>
        /// NT-Установить соединение клиента с сервером
        /// </summary>
        /// <param name="ip">IP адрес сервера</param>
        /// <param name="port">Номер порта сервера</param>
        /// <returns>Возвращает строку сообщения об ошибке или пустую строку при успехе операции</returns>
        public string ConnectToServer(string ip, int port)
        {
            String res = "";
            try
            {
                m_Client.Connect(ip, port);
                //send first auth message
                ChatMessage msg = new ChatMessage(this.m_MemberName, ChatMember.ServerName, "Connect new member");
                SendMessage(msg);
                //создаем новый поток для ожидания и приема сообщений от сервера. 
                StartSession();
            }
            catch (Exception ex)
            {
                res = ex.ToString();
            }
            return res;
        }

        /// <summary>
        /// NT- принять сообщение. Возвращает объект сообщения или нуль
        /// </summary>
        /// <returns></returns>
        public ChatMessage ReceiveMessage()
        {
            ChatMessage result = null;

            NetworkStream myNetworkStream = this.Client.GetStream();
            // Check to see if this NetworkStream is readable.
            if (myNetworkStream.CanRead)
            {
                byte[] myReadBuffer = new byte[1024];
                StringBuilder myCompleteMessage = new StringBuilder();
                int numberOfBytesRead = 0;

                // Incoming message may be larger than the buffer size.
                do
                {
                    numberOfBytesRead = myNetworkStream.Read(myReadBuffer, 0, myReadBuffer.Length);

                    myCompleteMessage.AppendFormat("{0}", Encoding.UTF8.GetString(myReadBuffer, 0, numberOfBytesRead));
                }
                while (myNetworkStream.DataAvailable);
                //тут должен быть текст, из него мы состроим объект сообщения
                result = ChatMessage.Deserialize(myCompleteMessage.ToString());

            }
            return result;
        }


        //NT-Начать прием сообщений от участника чата
        public void StartSession()
        {
            Thread t = new Thread(DoChatFunction);
            //запустить цикл ожидания сообщений 
            m_workFlag = true;
            //запустить поток  ожидания сообщений 
            t.Start();
        }
        //NT-Функция потока приема сообщений от участника чата
        public void DoChatFunction()
        {
            //Этот код работает в потоке выделенном для клиента
            while (m_workFlag)
            {
                //ожидаем сообщение
                ChatMessage msg = ReceiveMessage();
                //send as event
                OnChatMessageReceived(msg);
            }
            //тут поток чтения сообщений должен завершиться
            //но надо бы еще закрыть сокет и прочие ресурсы
            return;
        }
        /// <summary>
        /// NT-Генератор события поступления входящего сообщения
        /// </summary>
        /// <param name="msg">Входящее сообщение</param>
        protected void OnChatMessageReceived(ChatMessage msg)
        {
            ChatMessageReceivedEventHandler handler = ChatMessageReceived;
            if (handler != null)
            {
                // Invokes the delegates. 
                handler(this, new ChatMessageEventArgs(msg));
            }
            return;
        }

        /// <summary>
        /// NT-отослать сообщение
        /// </summary>
        /// <param name="msg"></param>
        public void SendMessage(ChatMessage msg)
        {
            String xmlString = msg.Serialize();
            Byte[] bytes = Encoding.UTF8.GetBytes(xmlString);//TODO: перенести это в класс сообщения 
            NetworkStream s = this.m_Client.GetStream();
            s.Write(bytes, 0, bytes.Length);
            s.Flush();
        }
        #region *** Binary form messages ***
        //Это должно дать более компактное по объему и по скорости сообщение
        //и снизить нагрузку на чат

        /// <summary>
        /// NT-Принять сообщение в двоичной форме
        /// </summary>
        /// <returns></returns>
        public ChatMessage ReceiveMessageBinary()
        {
            ChatMessage result = null;

            NetworkStream ns = this.Client.GetStream();
            if (ns.CanRead)
            {
                IFormatter bf = new BinaryFormatter();
                result = (ChatMessage)bf.Deserialize(ns);

            }
            ns.Close(); //или не надо его закрывать?
            return result;
        }

        /// <summary>
        /// NT-отослать сообщение
        /// </summary>
        /// <param name="msg"></param>
        public void SendMessageBinary(ChatMessage msg)
        {
            NetworkStream ns = this.m_Client.GetStream();
            IFormatter bf = new BinaryFormatter();
            bf.Serialize(ns, msg);
            ns.Flush();
        }

        #endregion


        /// <summary>
        /// NT-Проверить, что строка соответствует имени участника Сервер
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool IsServerName(string p)
        {
            if (String.Equals(p, ChatMember.ServerName, StringComparison.OrdinalIgnoreCase))
                return true;
            else if (String.Equals(p, "Сервер", StringComparison.OrdinalIgnoreCase))
                return true;
            else return false;
        }

    }
}
