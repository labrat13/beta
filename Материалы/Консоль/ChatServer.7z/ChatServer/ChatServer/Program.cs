﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Net.Sockets;
using System.Threading;
using System.Net;

namespace ChatServer
{
    class Program
    {
        public static Hashtable clientsList = new Hashtable();
        
        static void Main(string[] args)
        {

            TcpListener serverSocket = new TcpListener(IPAddress.Parse("127.0.0.1"), 8888);
            //что это такое происходит? 
            TcpClient clientSocket = default(TcpClient);

            int counter = 0;

            serverSocket.Start();
            Console.WriteLine("Chat Server Started ....");

            while ((true))
            {
                counter += 1;
                clientSocket = serverSocket.AcceptTcpClient();
                byte[] bytesFrom = new byte[10025];
                string dataFromClient = null;

                NetworkStream networkStream = clientSocket.GetStream();
                //тут можно ли узнать размер до чтения? нет
                networkStream.Read(bytesFrom, 0, (int)clientSocket.ReceiveBufferSize);
                //кодировку надо уникод
                dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom);
                //тут выделение строки до $, а что в ней после?
                //это имя пользователя приходит с клиента
                dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));
                //пополнить список клиентов
                clientsList.Add(dataFromClient, clientSocket);
                //разослать всем сообщение от сервера о присоединении нового клиента
                //а оно не всем нужно...
                broadcast(dataFromClient + " Joined ", dataFromClient, false);
                //вывести событие в лог на консоль
                Console.WriteLine(dataFromClient + " Joined chat room ");
                //создать менеджер клиента
                ClientManager client = new ClientManager();
                //начать сеанс клиента
                client.startClient(clientSocket, dataFromClient, clientsList);
            }
            clientSocket.Close();
            serverSocket.Stop();
            Console.WriteLine("exit");
            Console.ReadLine();
        }


        /// <summary>
        /// Разослать сообщение всем участникам чата
        /// </summary>
        /// <param name="msg">Текст сообщения</param>
        /// <param name="uName">Имя автора сообщения</param>
        /// <param name="flag">
        /// True - рассылка сообщений от клиентов
        /// False - рассылка сообщений от сервера
        /// </param>
        public static void broadcast(string msg, string uName, bool flag)
        {
            //для каждого клиента в списке клиентов отправить сообщение msg
            foreach (DictionaryEntry Item in clientsList)
            {
                TcpClient broadcastSocket;
                broadcastSocket = (TcpClient)Item.Value;
                NetworkStream broadcastStream = broadcastSocket.GetStream();
                Byte[] broadcastBytes = null;
                //тип сообщения
                if (flag == true)
                {
                    //рассылка сообщений от клиентов
                    broadcastBytes = Encoding.ASCII.GetBytes(uName + " says : " + msg);
                }
                else
                {
                    //рассылка сообщений от сервера
                    broadcastBytes = Encoding.ASCII.GetBytes(msg);
                }
                //отправка сообщения
                broadcastStream.Write(broadcastBytes, 0, broadcastBytes.Length);
                broadcastStream.Flush();
            }
        }  //end broadcast function


    }//end Main class





    public class ClientManager
    {
        TcpClient clientSocket;
        string clNo;
        Hashtable clientsList;

        public void startClient(TcpClient inClientSocket, string clineNo, Hashtable cList)
        {
            this.clientSocket = inClientSocket;
            this.clNo = clineNo;
            this.clientsList = cList;
            Thread ctThread = new Thread(doChat);
            ctThread.Start();
        }



        private void doChat()
        {
            int requestCount = 0;
            byte[] bytesFrom = new byte[10025];
            string dataFromClient = null;
            Byte[] sendBytes = null;
            string serverResponse = null;
            string rCount = null;
            requestCount = 0;

            while ((true))
            {
                try
                {
                    requestCount = requestCount + 1;
                    NetworkStream networkStream = clientSocket.GetStream();
                    networkStream.Read(bytesFrom, 0, (int)clientSocket.ReceiveBufferSize);
                    dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom);
                    dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));
                    Console.WriteLine("From client - " + clNo + " : " + dataFromClient);
                    rCount = Convert.ToString(requestCount);
                    Program.broadcast(dataFromClient, clNo, true);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }//end while
        }//end doChat
    } //end class handleClinet
}
