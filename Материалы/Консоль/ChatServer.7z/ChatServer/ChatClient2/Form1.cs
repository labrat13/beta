﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ChatLibrary2;

namespace ChatClient2
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Флаг что текст должен отправляться по нажатию клавиши ввода
        /// </summary>
        private bool isSendByEnter;
        /// <summary>
        /// Объект консоли участника чата
        /// </summary>
        private ChatMember m_member;
        
        public Form1()
        {
            isSendByEnter = true;
            InitializeComponent();
            //тут надо загрузить и применить последние размеры окна и столбцов грида
            //а то их каждый раз надо настраивать.
            //и хорошо бы они сами на размер окна настраивались
            
            //оценить вид окна по этим примерам сообщений
            AddMessageToListView(new ChatMessage("Autor", "Server", "Запустить Оператора"));
            AddMessageToListView(new ChatMessage("Autor", "Operator", "Show me current time"));
            AddMessageToListView(new ChatMessage("Autor", "Operator", "Show me current directory"));
            AddMessageToListView(new ChatMessage("Autor", "Server", "Выключить Оператора"));

            //проверка что статусбар автоматически обрезается по размеру окна
            //SetStatusBarText("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");

            m_member = new ChatMember();
        }

        //приложение должно использовать общий класс консоли чата,
        //который должен лежать в библиотеке и обеспечивать общий функционал для всех типов консоли проекта
        //но пока мы тут прикидываем как оно все должно быть устроено
        //и тестируем сервер

        //и еще надо как-то останавливать соединение и закрывать консольный процесс
        //а вот об этом ничего нет
        //ясно, что останавливать соединение должен сервер, отсылая сообщение-команду по команде пользователя или оператора
        //тогда клиент закрывает соединение и завершает работу
        //и это же можно сделать для консоли пользователя при ее закрытии
        //то есть, закрываться она как все будет, по команде с сервера
        //а на сервер команду дает она же
        //или нет? Надо подумать, как сделать, чтобы сервер узнавал, что консоль завершилась.

        private void SetStatusBarText(String text)
        {
            this.toolStripStatusLabel1.Text = text;
            Application.DoEvents();
            return;
        }

        private void AddMessageToListView(ChatMessage msg)
        {
            ListViewItem lvi = new ListViewItem(msg.Timestamp.ToString());
            lvi.SubItems.Add(msg.Autor);
            lvi.SubItems.Add(msg.Addressat);
            lvi.SubItems.Add(msg.Content);
            //insert to listview 
            this.listView_Output.Items.Add(lvi);
        }

        private void textBox_InputText_KeyUp(object sender, KeyEventArgs e)
        {
            if (isSendByEnter && (e.KeyCode == Keys.Enter))
            {
                SendText(textBox_InputText.Text);
                textBox_InputText.Clear();
            }
        }

        private void button_Send_Click(object sender, EventArgs e)
        {
            SendText(textBox_InputText.Text.Trim());
            textBox_InputText.Clear();
        }

        private void SendText(string p)
        {
            ChatMessage msg = new ChatMessage(this.m_member.MemberName, ChatMember.AllName, p);
            this.m_member.SendMessage(msg);
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.m_member.ChatMessageReceived += new ChatMessageReceivedEventHandler(m_console_ChatMessageReceived);
            String text = this.m_member.ConnectToServer("127.0.0.1", 8888);
            //тут возвращается пустая строка если все хорошо или текст исключения при ошибке
            if (!String.IsNullOrEmpty(text))
            {
                AddMessageToListView(new ChatMessage("Ошибка", "", text));
                SetStatusBarText("Connection problem: " + text); 
            }
            return;
        }

        void m_console_ChatMessageReceived(object sender, ChatMessageEventArgs e)
        {
            AddMessageToListView(e.Message);
        }

    }
}
