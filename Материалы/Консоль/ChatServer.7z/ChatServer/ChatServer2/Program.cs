﻿using System;
using System.Collections.Generic;
using System.Text;
using ChatLibrary2;
using System.Net.Sockets;
using System.Net;

namespace ChatServer2
{
    class Program
    {
        /// <summary>
        /// Список сообщений участников
        /// </summary>
        public static ChatMessageCollection m_messageCollection;
        /// <summary>
        /// Словарь объектов участников
        /// </summary>
        public static ChatMemberDictionary m_memberDictionary;
        
        static void Main(string[] args)
        {
            
            TcpListener serverSocket = null;

            m_messageCollection = new ChatMessageCollection();
            m_memberDictionary = new ChatMemberDictionary();

            try
            {
                //test's here





                //end test area
                //Настройки сервера следует загружать из файла настроек
                serverSocket = new TcpListener(IPAddress.Parse("127.0.0.1"), 8888);
                serverSocket.Start();
                Console.WriteLine("Chat Server Started ....");

                //тут примеры из мсдна скопипащены для разбора и переделки
                //Console.Write("Waiting for a connection... ");
                while (true)
                {
                    
                    // Perform a blocking call to accept requests.
                    // You could also user server.AcceptSocket() here.
                    TcpClient client = serverSocket.AcceptTcpClient();

                    //получить сообщение от клиента о том, что он есть
                    ChatMember member = new ChatMember(client);
                    ChatMessage msg = member.ReceiveMessage();
                    //сохранить идентификатор участника в объекте участника
                    member.MemberName = msg.Autor;
                    //добавить участника в список участников сервера
                    m_memberDictionary.Add(msg.Autor, member);
                    //прицепить обработчик приема сообщений от клиента
                    member.ChatMessageReceived += new ChatMessageReceivedEventHandler(member_ChatMessageReceived);
                    //разослать участникам сообщение о присоединении участника
                    ChatMessage msgNew = ChatMessage.AddMemberMessage(member.MemberName);
                    m_memberDictionary.broadcast(msgNew);
                    //начать сеанс слушания клиента
                    member.StartSession();

                    //data = null;

                    //// Get a stream object for reading and writing
                    //NetworkStream stream = client.GetStream();

                    //int i;

                    //// Loop to receive all the data sent by the client.
                    //while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                    //{
                    //    // Translate data bytes to a ASCII string.
                    //    data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                    //    Console.WriteLine("Received: {0}", data);

                    //    // Process the data sent by the client.
                    //    data = data.ToUpper();

                    //    byte[] msg = System.Text.Encoding.ASCII.GetBytes(data);

                    //    // Send back a response.
                    //    stream.Write(msg, 0, msg.Length);
                    //    Console.WriteLine("Sent: {0}", data);
                    //}

                    //// Shutdown and end connection
                    //client.Close();


                }

            }
            catch (Exception e)
            {
                Console.WriteLine("SocketException: {0}", e);
            }
            finally
            {
                // Stop listening for new clients.
                serverSocket.Stop();
            }


            Console.WriteLine("\nHit enter to continue...");
            Console.Read();

        }

        static void member_ChatMessageReceived(object sender, ChatMessageEventArgs e)
        {
            //тут разослать всем полученное сообщение
            m_memberDictionary.broadcast(e.Message);
            //тут выполнить сообщение если оно содержит команду для сервера
            executeMessage(e.Message);

            return;
        }
        /// <summary>
        /// Выполнить сообщение, если оно содержит команду серверу
        /// </summary>
        /// <param name="chatMessage"></param>
        private static void executeMessage(ChatMessage message)
        {
            //если сообщение адресовано серверу
            if (!ChatMember.IsServerName(message.Addressat)) return;
            //то проверить, что сообщение содержит команду и выполнить ее.

            return;
        }









    }
}
