﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace GenLib
{
    /// <summary>
    /// Played clip object class for sending to player over network
    /// </summary>
    public class PlayFile
    {
        /// <summary>
        /// int 32 - ID file from Database, 0 - error
        /// </summary>
        private int m_id;
        /// <summary>
        /// in-file playing start position time in seconds
        /// </summary>
        private double m_startPos;
        /// <summary>
        /// file playing start date and time
        /// </summary>
        private DateTime m_startDate;
        /// <summary>
        /// file playing end date and time
        /// </summary>
        private DateTime m_endDate;
        /// <summary>
        /// string - UNC path and name for file
        /// </summary>
        private string m_UNCfilePath;
        /// <summary>
        /// sound volume in percent (0 - 100)
        /// </summary>
        private Int32 m_volume;
        /// <summary>
        /// Clip file name
        /// </summary>
        private string m_clipName;

        /// <summary>
        /// Default constructor
        /// </summary>
        public PlayFile()
        {

        }

        /// <summary>
        /// constructor from XFile object
        /// </summary>
        /// <param name="xf">XFile object</param>
        public PlayFile(XFile xf)
        {
            m_id = xf.FileID;
            m_clipName = xf.ItemTitle;
            m_startDate = xf.ClipBeginAbsTime;
            m_endDate = m_startDate.AddMilliseconds(xf.ItemLength);
            m_startPos = xf.startPos / 1000; //in seconds
            m_UNCfilePath = xf.UNCFilePath;
            m_volume = xf.volume;
        }
        /// <summary>
        /// clip ID in database
        /// </summary>
        public int clipId
        {
            get { return m_id; }
            set { m_id = value; }
        }
        /// <summary>
        /// clip start playing position in seconds
        /// </summary>
        public double startPos
        {
            get { return m_startPos; }
            set { m_startPos = value; }
        }

        /// <summary>
        /// Clip playing start datetime
        /// </summary>
        public DateTime startDate
        {
            get { return m_startDate; }
            set { m_startDate = value; }
        }

        /// <summary>
        /// Clip playing end datetime
        /// </summary>
        public DateTime endDate
        {
            get { return m_endDate; }
            set { m_endDate = value; }
        }

        /// <summary>
        /// clip volume in percent'[s
        /// </summary>
        public int volume
        {
            get { return m_volume; }
            set { m_volume = value; }
        }
        /// <summary>
        /// Clip file name - clip title
        /// </summary>
        public string clipName
        {
            get { return m_clipName; }
            set { m_clipName = value; }
        }
        /// <summary>
        /// Clip file network path
        /// </summary>
        public string UNCfilePath
        {
            get { return m_UNCfilePath; }
            set { m_UNCfilePath = value; }
        }


        /// <summary>
        /// save to XML string
        /// </summary>
        public string ToXML()
        {
            StringBuilder sb = new StringBuilder();
            System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(this.GetType());
            System.IO.StringWriter file = new System.IO.StringWriter(sb, CultureInfo.InvariantCulture);
            writer.Serialize(file, this);
            file.Close();

            return sb.ToString();
        }

        /// <summary>
        /// load from XML string
        /// </summary>
        public static PlayFile FromXML(string XMLstring)
        {
            PlayFile tmp = new PlayFile();
            System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(tmp.GetType());
            System.IO.StringReader file = new System.IO.StringReader(XMLstring);
            tmp = (PlayFile)reader.Deserialize(file);
            file.Close();
            return tmp;
        }




    }
}
