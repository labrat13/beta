﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using GenLib;
using Microsoft.DirectX.AudioVideoPlayback;
using System.Globalization;

namespace Pleer
{
    /// <summary>
    /// Pleer main form class
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Form constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            plist = new List<PlayFile>();
            sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //create checking outpost message
            checkmsg = Encoding.UTF8.GetBytes("Client check");

            //sockTimerEnabled = false; - default initial
            buff = new byte[4096];
        }
        /// <summary>
        /// List of playing clip's - typically one section 
        /// </summary>
        private List<PlayFile> plist;
        /// <summary>
        /// Sound player object
        /// </summary>
        private Audio plr;

        private Socket sock;

        private bool sockTimerEnabled;
        
        private byte[] buff;
        /// <summary>
        /// current clip play start time
        /// </summary>
        private DateTime StartPlay; 
        /// <summary>
        /// current clip play end time
        /// </summary>
        private DateTime EndPlay;   
        
        private int startPlay;
        
        private int endPlay;
        /// <summary>
        /// counter for access to the some code
        /// </summary>
        private int timerCountStop;
        
        private int timerCountPlay;
        /// <summary>
        /// clip stepping divider for progress bar
        /// </summary>
        private double Step;    
        /// <summary>
        /// XProject setting object
        /// </summary>
        private XPsetting set;
        /// <summary>
        /// checking msg for socket confirmation
        /// </summary>
        private byte[] checkmsg;



        private void timer1_Tick(object sender, EventArgs e)
        {
            PlayFile xf;
            string XmlString;
            //check the time for play/end moment
            int now = (int)DateTime.Now.TimeOfDay.TotalSeconds;
            if (timerCountStop == 0)
            {
                if ((now == endPlay) || (now == (endPlay + 1)))
                {
                    //stop playing, delete clip item from lists and set new playing time
                    timerCountStop = 10;  // blocking for 10 second
                    ClipStop();
                }
            }
            else timerCountStop--;

            if (timerCountPlay == 0)
            {
                if ((now == startPlay) || (now == (startPlay + 1)))
                {
                    //start playing, set progress bar and more
                    timerCountPlay = 10;  // blocking for 10 second
                    ClipPlay();
                }
            }
            else timerCountPlay--;
            //****************************************************************
            //update progressbar
            if (plr.Playing)
            {
                progress.Value = (int)(plr.CurrentPosition / Step);
            }
            //****************************************************************
            if (sockTimerEnabled == true)
            {
                if (sock.Available > 0)
                {
                    //disable timer flag for prevent reentering
                    sockTimerEnabled = false;
                    //clear bufr for avoid errors with old data
                    for (int i = 0; i < buff.Length; i++) buff[i] = 0;
                    //get data
                    sock.Receive(buff);
                    XmlString = Encoding.UTF8.GetString(buff);
                    xf = PlayFile.FromXML(XmlString);
                    //startup time info for first playing
                    //optimized <if>
                    //если клип успевает начаться, то помещаем его в очередь
                    //а если опаздывает, то не помещаем, чтобы не обламывал всю работу
                    //а вообще лучше бы переделать весь плеер - топорный он, однако
                    if (xf.startDate > DateTime.Now.AddSeconds(5.00))//через 5 секунд после сейчас
                    {
                        plist.Add(xf);
                        if (plist.Count == 1)
                        {
                            // only first time
                            StartPlay = plist[0].startDate;
                            EndPlay = plist[0].endDate;
                            startPlay = (int)StartPlay.TimeOfDay.TotalSeconds;
                            endPlay = (int)EndPlay.TimeOfDay.TotalSeconds;
                        }
                        //add clip title to playlist listbox
                        AddRowToGrid(xf);
                    }
                    //send message - 
                    sock.Send(this.checkmsg);//optimise - make static byte[] buffer
                    //restore timer flag
                    sockTimerEnabled = true;
                }
            }
        }

        /// <summary>
        /// form loading - initialize
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            //load setting file
            set = XPsetting.LoadSettings("");
            //init pleer with startup clip file
            plr = Audio.FromFile(set.StartedSoundPath, false);
        }

        /// <summary>
        /// form closing - free resources
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //stop player
            plr.Stop();
            //close socket
            sock.Shutdown(SocketShutdown.Both);
            sock.Close();
        }

        /// <summary>
        /// ClipStopping routine
        /// 
        /// </summary>
        private void ClipStop()
        {
            if (plr.Playing) plr.Stop();
            plist.RemoveAt(0);
            this.listView1.Items.RemoveAt(0);
            //set start and stop datetime for playing clip
            StartPlay = plist[0].startDate;
            EndPlay = plist[0].endDate;

            startPlay = (int)StartPlay.TimeOfDay.TotalSeconds;
            endPlay = (int)EndPlay.TimeOfDay.TotalSeconds;
            //set progressbar
            this.progress.Value = 0;
        }
        /// <summary>
        /// Clip playing routine
        /// </summary>
        private void ClipPlay()
        {
            if (plr.Playing == false)
            {
                plr.Open(plist[0].UNCfilePath, false);
                plr.Volume = VolumeControl.VolumePercentToDb(plist[0].volume); //согласовывать уровни в плеере и в БД
                //set specified posititon for clip - in second's
                plr.CurrentPosition = plist[0].startPos;
                plr.Play();
                this.Step = plr.Duration / 100;
            }
        }

        /// <summary>
        ///Вызывается, когда форма уже отображена на экране.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Shown(object sender, EventArgs e)
        {
            //add message to playlist listbox
            labelInfo.Text = "Try connect to planner at " + set.PlannerAddress + " : " + set.PlannerPort.ToString();
            Application.DoEvents();
            sock.Connect(IPAddress.Parse(set.PlannerAddress), set.PlannerPort);

            sock.SendTimeout = Properties.Settings.Default.PleerConnTimeoutMsec;    // 30000;   // 30 seconds timeout
            sock.ReceiveTimeout = Properties.Settings.Default.PleerConnTimeoutMsec;
            // message exchange
            byte[] msg = Encoding.UTF8.GetBytes("This is a client test msg");
            byte[] bytes = new byte[256];

            sock.Receive(bytes);//get msg
            sock.Send(msg);//send msg
            //add message to playlist listbox
            labelInfo.Text = Application.ProductName + " ver " + Application.ProductVersion;
            //enable GUI timer
            timer1.Enabled = true;
            //enable flag for clip adding message processing
            sockTimerEnabled = true;
        }

        private void AddRowToGrid(PlayFile pf)
        {
            ListViewItem lvi = new ListViewItem(pf.clipId.ToString(CultureInfo.CurrentCulture));   //listView1.Items.Add("item1");
            lvi.SubItems.Add(pf.startDate.ToString(CultureInfo.CurrentCulture));
            lvi.SubItems.Add(pf.endDate.ToString(CultureInfo.CurrentCulture));
            lvi.SubItems.Add(pf.volume.ToString(CultureInfo.CurrentCulture));
            lvi.SubItems.Add(pf.clipName);
            lvi.SubItems.Add(pf.UNCfilePath);
            listView1.Items.Add(lvi);
        }

    }
}
