﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace ConsoleProto
{
    class Program
    {

        static Process m_process;


        static void Main(string[] args)
        {
            m_process = new Process();
            m_process.StartInfo.FileName = "cmd.exe";
            m_process.StartInfo.Arguments = ""; //set argument string here

            ////если нужен запуск от имени пользователя
            //process.StartInfo.UserName = ""; //set user name here
            //process.StartInfo.Password = "";//set user password here
            //process.StartInfo.WorkingDirectory = ""; //set initial directory
            
            //настройки переназначения
            m_process.StartInfo.UseShellExecute = false;
            m_process.StartInfo.RedirectStandardOutput = true;
            m_process.StartInfo.RedirectStandardError = true;
            m_process.StartInfo.RedirectStandardInput = true;

            m_process.OutputDataReceived += new DataReceivedEventHandler(m_process_OutputDataReceived);

            m_process.ErrorDataReceived += new DataReceivedEventHandler(m_process_ErrorDataReceived);

            //exit event handler
            m_process.Exited += new EventHandler(process_Exited);


            m_process.Start();

            // Asynchronously read the standard output of the spawned process.  
            // This raises OutputDataReceived events for each line of output.
            m_process.BeginOutputReadLine();
            m_process.BeginErrorReadLine();

            //настроить входной поток процесса
            StreamWriter processInput = m_process.StandardInput;
            StreamReader currInput = new StreamReader(Console.OpenStandardInput(), Console.InputEncoding);
            ////надо закрутить ожидание приема сообщений в цикл
            while (!m_process.HasExited)
            {

                //читаем все из входного потока текущего приложения
                String line = currInput.ReadLine();
                //и пишем в входной поток подконтрольного приложения
                processInput.WriteLine(line);
            }
            currInput.Close();
            //process.ExitCode;
            

            m_process.WaitForExit(); //ждем когда процесс завершится
            m_process.CancelOutputRead(); //отключаем передачу выходного текста
            m_process.CancelErrorRead();

            m_process.Close(); //закрываем процесс

            Console.WriteLine("\n\nPress any key to exit.");
            Console.ReadLine();

            //неправильныйпример учета кода завершения процесса 
            //bool processExited = process.WaitForExit(PROCESS_TIMEOUT);
            //if (processExited == false) // we timed out...
            //{
            //    process.Kill();
            //    throw new Exception("ERROR: Process took too long to finish");
            //}
            //else if (process.ExitCode != 0)
            //{
            //    var output = outputStringBuilder.ToString();
            //    var prefixMessage = "";

            //    throw new Exception("Process exited with non-zero exit code of: " + process.ExitCode + Environment.NewLine + 
            //    "Output from process: " + outputStringBuilder.ToString());
            //}
            //}
            //finally
            //{                
            //process.Close();
            //}




        }

        static void m_process_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e.Data != null)
            {
                //StreamWriter sw = new StreamWriter(Console.OpenStandardOutput(), m_process.StandardOutput.CurrentEncoding);
                //sw.WriteLine(e.Data);
                //sw.Close();
                
                //Console.WriteLine(Encoding.Convert(m_process.StandardOutput.CurrentEncoding, Console.OutputEncoding, );
                //а как конвертить строку в другую кодировку тут?
                //cmd.exe сам показывает строки как надо, 
                //а мне надо их тут приводить в нормальную кодировку
                //ipconfig.exe как образец несоответствия кодировок


                Console.WriteLine(e.Data);
            }
        }

        static void m_process_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            //тут тоже надо конвертить строки сообщений в нормальную кодировку.
            if (!String.IsNullOrEmpty(e.Data))
            {
                Console.WriteLine("Error: " + e.Data);
            }
        }

        static void process_Exited(object sender, EventArgs e)
        {
            //приложение завершается по exit - с кодом 9009 а не 0 как полагается
            // так что код завершения не соблюдается обычно
            Console.WriteLine(String.Format("Application exited {0} with {1} error code", m_process.ExitTime.ToString(), m_process.ExitCode));
        }

    }
}
