﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;
using System.Text;

namespace SystemEventsTest
{
    static class Program
    {
        public static  StreamWriter LogFile;
        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {


            


            //create log file
            LogFile = new StreamWriter("C:\\SysEventsTestLog.txt", true, Encoding.Default);
            LogFile.AutoFlush = true;
            //set event handlers
            SystemEvents.PowerModeChanged += new PowerModeChangedEventHandler(SystemEvents_PowerModeChanged);
            SystemEvents.SessionEnded += new SessionEndedEventHandler(SystemEvents_SessionEnded);
            SystemEvents.SessionEnding += new SessionEndingEventHandler(SystemEvents_SessionEnding);
            SystemEvents.SessionSwitch += new SessionSwitchEventHandler(SystemEvents_SessionSwitch);
            SystemEvents.TimeChanged += new EventHandler(SystemEvents_TimeChanged);

            print("boot mode", SystemInformation.BootMode);//режим загрузки ОС: нормальный, безопасный, безопасный и сеть.
            print("ComputerName", SystemInformation.ComputerName);//нетбиос имя данного компьютера
            print("DebugOS", SystemInformation.DebugOS);//true if the debugging version of USER.EXE is installed; otherwise, false.
            print("HighContrast", SystemInformation.HighContrast);//true if the user has enabled high-contrast mode; otherwise, false.
            print("IsKeyboardPreferred", SystemInformation.IsKeyboardPreferred);//юзер предпочитает клавиатуру а не мышь
            print("MidEastEnabled", SystemInformation.MidEastEnabled);//true if the operating system is enabled for Hebrew or Arabic; otherwise, false.
            print("MonitorCount", SystemInformation.MonitorCount);//The MonitorCount property indicates the number of monitors currently recognized by the operating system. This property returns a value greater than one only if multiple monitors are currently recognized by the operating system.
            print("MouseButtons", SystemInformation.MouseButtons);//Gets the number of buttons on the mouse.
            print("MouseButtonsSwapped", SystemInformation.MouseButtonsSwapped);//мышь для левшей
            print("MouseWheelPresent", SystemInformation.MouseWheelPresent);//мышь имеет колесо
            print("Network", SystemInformation.Network);//The Network property indicates whether the system has a currently established network connection. //всегда Да.
            print("PowerStatus", SystemInformation.PowerStatus);
            print("PowerStatus.PowerLineStatus", SystemInformation.PowerStatus.PowerLineStatus);
            print("PowerStatus.BatteryChargeStatus", SystemInformation.PowerStatus.BatteryChargeStatus);
            print("PowerStatus.BatteryFullLifetime", SystemInformation.PowerStatus.BatteryFullLifetime);
            print("PowerStatus.BatteryLifePercent", SystemInformation.PowerStatus.BatteryLifePercent);
            print("PowerStatus.BatteryLifeRemaining", SystemInformation.PowerStatus.BatteryLifeRemaining);
            print("Secure", SystemInformation.Secure);//The Secure property indicates whether a Security Manager is available from the operating system. Windows NT and Windows 2000 provide a Security Manager to determine access to the operating system registry and to the file system. Windows 98 does not provide a Security Manager.
            print("TerminalServerSession", SystemInformation.TerminalServerSession);//true if the calling process is associated with a Terminal Services client session; otherwise, false.
            print("UserDomainName", SystemInformation.UserDomainName);//Gets the name of the domain the user belongs to.
            print("UserInteractive", SystemInformation.UserInteractive);//true if the current process is running in user-interactive mode; otherwise, false.
            print("UserName", SystemInformation.UserName);//The user name of the user associated with the current thread.
            print("VirtualScreen", SystemInformation.VirtualScreen);//A Rectangle that specifies the bounding rectangle of the entire virtual screen.
 


            Application.ApplicationExit += new EventHandler(Application_ApplicationExit);
            Application.EnterThreadModal += new EventHandler(Application_EnterThreadModal);
            Application.Idle += new EventHandler(Application_Idle);
            Application.LeaveThreadModal += new EventHandler(Application_LeaveThreadModal);
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            Application.ThreadExit += new EventHandler(Application_ThreadExit);
            

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            LogFile.Close();
            return;
        }

        public static void print(String text)
        {
            LogFile.WriteLine(String.Format("{0}-{1}", DateTime.Now.ToString("o"), text));
        }

        public static void print(String title,Object ob)
        {
            print(title +"="+ob.ToString());
        }

        static void Application_ThreadExit(object sender, EventArgs e)
        {

            print("Application_ThreadExit ");
        }

        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            print("Application_ThreadException: " + e.Exception.ToString());
        }

        static void Application_LeaveThreadModal(object sender, EventArgs e)
        {

            print("Application_LeaveThreadModal" );
        }

        static void Application_Idle(object sender, EventArgs e)
        {
            print("Application_Idle ");
        }

        static void Application_EnterThreadModal(object sender, EventArgs e)
        {
            print("Application_EnterThreadModal");
        }

        static void Application_ApplicationExit(object sender, EventArgs e)
        {
            print("Application_ApplicationExit ");
        }

        static void SystemEvents_TimeChanged(object sender, EventArgs e)
        {
            print("TimeChangedEvent, " + DateTime.Now.ToShortTimeString());
            
        }

        static void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            print("SessionSwitchEvent: " + e.Reason.ToString());
        }

        static void SystemEvents_SessionEnding(object sender, SessionEndingEventArgs e)
        {
            //can cancel by e.Cancel
            print("SessionEndingEvent: " + e.Reason.ToString());
        }

        static void SystemEvents_SessionEnded(object sender, SessionEndedEventArgs e)
        {
            print("SessionEndedEvent: " + e.Reason.ToString());
        }

        static void SystemEvents_PowerModeChanged(object sender, PowerModeChangedEventArgs e)
        {
            print("PowerModeChangedEvent: " + e.Mode.ToString());
            print("PowerStatus", SystemInformation.PowerStatus);
            print("PowerStatus.PowerLineStatus", SystemInformation.PowerStatus.PowerLineStatus);
            print("PowerStatus.BatteryChargeStatus", SystemInformation.PowerStatus.BatteryChargeStatus);
            print("PowerStatus.BatteryFullLifetime", SystemInformation.PowerStatus.BatteryFullLifetime);
            print("PowerStatus.BatteryLifePercent", SystemInformation.PowerStatus.BatteryLifePercent);
            print("PowerStatus.BatteryLifeRemaining", SystemInformation.PowerStatus.BatteryLifeRemaining);
        }





    }
}
