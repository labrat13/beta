﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.Win32;

namespace SystemEventsTest
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            Program.print("FormLoad");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Program.print("FormClosing");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Program.print("FormClosed");
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Program.print("FormShown");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text.Length > 0)
                Program.print(textBox1.Text);
            textBox1.Clear();
        }

        const int WM_POWERBROADCAST = 0x218;
        /// <summary>
        /// Power status has changed.
        /// </summary>
        const int PBT_APMPOWERSTATUSCHANGE = 0xA;
        /// <summary>
        /// Operation is resuming automatically from a low-power state. 
        /// This message is sent every time the system resumes.
        /// </summary>
        const int PBT_APMRESUMEAUTOMATIC = 0x12;
        /// <summary>
        /// Operation is resuming from a low-power state. 
        /// This message is sent after PBT_APMRESUMEAUTOMATIC if the resume is triggered by user input, such as pressing a key.
        /// </summary>
        const int PBT_APMRESUMESUSPEND = 0x7;
        /// <summary>
        /// System is suspending operation.
        /// </summary>
        const int PBT_APMSUSPEND = 0x4;
        /// <summary>
        /// A power setting change event has been received. 
        /// </summary>
        const int PBT_POWERSETTINGCHANGE = 0x8013;
        
        //Для Винды ХР и 2000:
        
        /// <summary>
        /// Battery power is low. In Windows Server 2008 and Windows Vista, use PBT_APMPOWERSTATUSCHANGE instead.
        /// </summary>
        const int PBT_APMBATTERYLOW = 0x9;
        /// <summary>
        /// OEM-defined event occurred. 
        /// In Windows Server 2008 and Windows Vista, this event is not available because these operating systems support only ACPI; APM BIOS events are not supported.
        /// </summary>
        const int PBT_APMOEMEVENT = 0xB;
        /// <summary>
        /// Request for permission to suspend. In Windows Server 2008 and Windows Vista, use the SetThreadExecutionState() function instead.
        /// </summary>
        const int PBT_APMQUERYSUSPEND = 0;
        /// <summary>
        /// Suspension request denied. In Windows Server 2008 and Windows Vista, use SetThreadExecutionState instead.
        /// </summary>
        const int PBT_APMQUERYSUSPENDFAILED = 0x2;
        /// <summary>
        /// Operation resuming after critical suspension. In Windows Server 2008 and Windows Vista, use PBT_APMRESUMEAUTOMATIC instead. 
        /// </summary>
        const int PBT_APMRESUMECRITICAL = 6;

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);

            String t = String.Empty;
            if (m.Msg == WM_POWERBROADCAST)
            {
                int param = (int)m.WParam;
                switch (param)
                {   case PBT_APMPOWERSTATUSCHANGE:
                        t = "PBT_APMPOWERSTATUSCHANGE";
                        break;
                    case PBT_APMRESUMEAUTOMATIC:
                        t = "PBT_APMRESUMEAUTOMATIC";
                        break;
                    case PBT_APMRESUMESUSPEND:
                        t = "PBT_APMRESUMESUSPEND";
                        break;
                    case PBT_APMSUSPEND:
                        t = "PBT_APMSUSPEND";
                        break;
                    case PBT_POWERSETTINGCHANGE:
                        t = "PBT_POWERSETTINGCHANGE";
                        break;
                    case PBT_APMBATTERYLOW:
                        t = "PBT_APMBATTERYLOW";
                        break;
                    case PBT_APMOEMEVENT:
                        t = "PBT_APMOEMEVENT";
                        break;
                    case PBT_APMQUERYSUSPEND:
                        t = "PBT_APMQUERYSUSPEND";
                        break;
                    case PBT_APMQUERYSUSPENDFAILED:
                        t = "PBT_APMQUERYSUSPENDFAILED";
                        break;
                    case PBT_APMRESUMECRITICAL:
                        t = "PBT_APMRESUMECRITICAL";
                        break;
                    default:
                        t = param.ToString();
                        break;
                }
                Program.print("WM_POWERBROADCAST ", t);
            }

        }

    }
}
