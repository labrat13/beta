﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Budilnik
{
    /// <summary>
    /// Форма уведомления будильника
    /// </summary>
    public partial class NotifyForm : Form
    {
        private String m_NotifyTitle;
        private String m_NotifyDescription;
        private String m_NotifyStatus;
        private bool m_NotifyShowBudilnik;
        
        public NotifyForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// NR-Показать форму уведомления и вернуть флаг, что нужно показать будильник
        /// </summary>
        /// <param name="bud">Будильник сработавший</param>
        /// <param name="f">Форма родительская</param>
        /// <returns></returns>
        public static bool ShowNotifyForm(BudilnikOne bud, Form f)
        {
            NotifyForm nf = new NotifyForm();
            nf.m_NotifyDescription = bud.Note;
            nf.m_NotifyShowBudilnik = false;
            nf.m_NotifyStatus = "";//TODO: Add notify status here...
            nf.m_NotifyTitle = "";//TODO: Add notify title here...
            //show form 
            //TODO: play sound here or inside form
            //TODO: закрыть форму по окончании длительности будильника.
            nf.ShowDialog(f);
            //show budilnik form if need
            return nf.m_NotifyShowBudilnik;
        }

        private void NotifyForm_Load(object sender, EventArgs e)
        {
            this.label_Title.Text = this.m_NotifyTitle;
            this.label_Status.Text = this.m_NotifyStatus;
            this.textBox_Description.Text = this.m_NotifyDescription;
            this.m_NotifyShowBudilnik = false;
        }

        private void button_Close_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void button_ShowBudilnik_Click(object sender, EventArgs e)
        {
            this.m_NotifyShowBudilnik = true;
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }


    }
}
