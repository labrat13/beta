﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Collections;
using System.Globalization;

namespace Budilnik
{
    public class BudilnikCollection
    {
        /// <summary>
        /// список будильников
        /// </summary>
        private List<BudilnikOne> m_BudList;
        /// <summary>
        /// Флаг, что коллекция или параметры будильника были изменены
        /// </summary>
        private bool m_Changed;


        public BudilnikCollection()
        {
            this.m_BudList = new List<BudilnikOne>();
            this.m_Changed = false;
        }

        /// <summary>
        /// Получить список будильников
        /// </summary>
        public List<BudilnikOne> Будильники
        {
            get
            {
                return m_BudList;
            }
        }

        /// <summary>
        /// Флаг, что коллекция или параметры будильника были изменены
        /// </summary>
        public bool Changed
        {
            get { return m_Changed; }
            set { m_Changed = value; }
        }

        /// <summary>
        /// RT-Добавить будильник в список 
        /// </summary>
        /// <param name="b1"></param>
        internal void Add(BudilnikOne b1)
        {
            this.m_BudList.Add(b1);
            this.m_Changed = true;
        }

        /// <summary>
        /// NT-Удалить будильник из списка
        /// </summary>
        /// <param name="b1">Экземпляр будильника, который точно присутствует в этом списке</param>
        public void Remove(BudilnikOne b1)
        {
            this.m_BudList.Remove(b1);
            this.m_Changed = true;
        }
        /// <summary>
        /// RT-Сохранить будильники в указанный файл.
        /// Если файл уже существует, он будет перезаписан.
        /// </summary>
        /// <param name="filename"></param>
        public void Store(String filename)
        {
            //тут вручную записать данные в ХМЛ-файл
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.CloseOutput = true;
            settings.ConformanceLevel = ConformanceLevel.Document;
            settings.NewLineHandling = NewLineHandling.Entitize;
            settings.OmitXmlDeclaration = false;
            settings.NewLineOnAttributes = false;
            //lock dictionary
            lock (((ICollection)this.m_BudList).SyncRoot)
            {
                XmlWriter wr = XmlWriter.Create(filename, settings);
                wr.WriteStartDocument(true);
                //write comment Created (date time)
                wr.WriteComment(String.Format("Created {0}", DateTime.Now.ToString(CultureInfo.GetCultureInfo("ru-RU"))));
                wr.WriteStartElement("budilniks");
                //write values
                foreach (BudilnikOne bud in this.m_BudList)
                {
                    String va = bud.StoreToString();
                    if (va == null) va = "[null]";
                    wr.WriteStartElement("bud");
                    wr.WriteValue(va);
                    wr.WriteEndElement();
                }
                //close file
                wr.WriteEndElement();
                wr.WriteEndDocument();
                wr.Close();
            }

            return;
        }

        /// <summary>
        /// RT-Загрузить будильники из указанного файла
        /// </summary>
        /// <param name="filename"></param>
        public void Load(String filename)
        {
            //тут вручную распарсить хмл-файл и заполнить данными словарь
            this.m_BudList.Clear();

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ConformanceLevel = ConformanceLevel.Document;
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;

            //lock dictionary
            lock (((ICollection)this.m_BudList).SyncRoot)
            {
                XmlReader reader = XmlReader.Create(filename, settings);
                //read
                reader.Read();
                reader.Read();//budilniks
                while (reader.Read())
                {
                    //read tag start
                    if (reader.IsStartElement())
                    {
                        //if this tag has empty value, add to dictionary
                        if (!reader.IsEmptyElement)
                        {
                            //else read tag value string, add to dictionary
                            reader.Read();
                            String val = reader.ReadString();
                            this.m_BudList.Add(new BudilnikOne(val));
                        }
                    }
                    //end of tags - not used, skipped 
                }
                reader.Close();
            }
            //сбросить флаг что будильники были изменены
            this.m_Changed = false;
            return;

        }

        /// <summary>
        /// NT-Получить будильник ближайший к указанной дате
        /// </summary>
        /// <param name="date">Время и дата текущая</param>
        /// <returns>Return budilnik or null if nothing founded.</returns>
        public BudilnikOne getNextBudilnik(DateTime date)
        {
            BudilnikOne result = null;
            DateTime dtMin = DateTime.MaxValue;
            DateTime now = DateTime.Now;
            //перебираем все будильники, так как они по времени не сортируются из-за нескольких дней недели.
            foreach (BudilnikOne b in m_BudList)
            {
                if (b.Enabled == true)
                {
                    //get bud by minimum of time for all bud's
                    DateTime dt = b.getTimeOfNextBudilnik(DateTime.Now);
                    if (dtMin > dt)
                    {
                        result = b;
                        dtMin = dt;
                    }
                }
            }
            //return null if no bud's selected
            return result;
        }







    }
}
