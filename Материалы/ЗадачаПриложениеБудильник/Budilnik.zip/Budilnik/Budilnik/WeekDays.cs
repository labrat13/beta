﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Budilnik
{
    /// <summary>
    /// Обозначает один или более дней недели
    /// </summary>
    [Flags()]
    public enum WeekDays
    {
        None = 0,
        Понедельник = 1,
        Вторник = 2,
        Среда = 4,
        Четверг = 8,
        Пятница = 16,
        Суббота = 32,
        Воскресенье = 64,
        РабочиеДни = Понедельник | Вторник | Среда | Четверг | Пятница,
        ВыходныеДни = Суббота | Воскресенье,
        ВсеДни = РабочиеДни | ВыходныеДни,
    }
}
