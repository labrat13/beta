﻿using System;
using System.Windows.Forms;
using System.IO;

namespace Budilnik
{
    public partial class Form1 : Form
    {
        //код тут такой кривой, что нуждается в переработке.
        //особенно это касается сохранения будильников, создания будильников.
        
        /// <summary>
        /// Созданные будильники
        /// </summary>
        private BudilnikCollection m_budCollection;
        /// <summary>
        /// Путь к каталогу данных приложения.
        /// </summary>
        private String m_appDataFolder;
        /// <summary>
        /// Флаг что события чекинга будильников должны игнорироваться в обработчике событий листвиева
        /// </summary>
        private bool m_checkEventEnabled;

        public Form1()
        {
            InitializeComponent();
            this.m_appDataFolder = Application.CommonAppDataPath;
            this.m_budCollection = new BudilnikCollection();
            this.m_checkEventEnabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //1 загрузить будильники из файла
            LoadBudilniks();
            //2 отобразить будильники на форме
            ShowBudilniks();
        }

        private void ShowBudilniks()
        {
            this.m_checkEventEnabled = false;
            this.listView1.BeginUpdate();
            this.listView1.Items.Clear();
            foreach (BudilnikOne bud in this.m_budCollection.Будильники)
            {
                ListViewItem lvi = new ListViewItem(bud.getTimeString());
                lvi.Checked = bud.Enabled;
                lvi.SubItems.Add(bud.getDaysString());
                lvi.SubItems.Add(bud.getNoteString());
                lvi.Tag = bud;//add reference to bud object

                this.listView1.Items.Add(lvi);
            }
            this.listView1.EndUpdate();
            this.m_checkEventEnabled = true;
            return;
        }

        private void LoadBudilniks()
        {
            try
            {
                //если каталога нет, создать его здесь - так как Load вызывается раньше, чем Save.
                if (!Directory.Exists(this.m_appDataFolder))
                    Directory.CreateDirectory(this.m_appDataFolder);
                //пробуем загрузить файл данных, если он есть
                String filepath = Path.Combine(this.m_appDataFolder, "budilniks.xml");
                if(File.Exists(filepath))
                    this.m_budCollection.Load(filepath);
            }
            catch (Exception e)
            {
                MessageBox.Show(this, String.Format("Ошибка загрузки будильников: {0}", e.ToString()), "Будильники - ошибка", MessageBoxButtons.OK);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //сохранить будильники в файл, если были изменения
            SaveBudilniks();
        }

        private void SaveBudilniks()
        {
            try
            {
                if (m_budCollection.Changed == true)
                {
                    this.m_budCollection.Store(Path.Combine(this.m_appDataFolder, "budilniks.xml"));
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(this, String.Format("Ошибка сохранения будильников: {0}", e.ToString()), "Будильники - ошибка", MessageBoxButtons.OK);
            }
        }



        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 box = new AboutBox1();
            box.ShowDialog(this);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Завершить работу приложения
            this.Close();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //создать новый будильник и добавить в список будильников
            BudilnikOne bud = new BudilnikOne();
            this.ПоказатьБудильник(bud, true);

            //TODO: хорошо бы тут и сохранить будильники в файл, не дожидаясь завершения программы.
            //а то вдруг она будет работать много дней, и завершится аварийно и будильники не запишутся в файл
            return;
        }

        /// <summary>
        /// Тест успешен 10112018
        /// </summary>
        private void TestBudilnikCollection()
        {
            //тест хранения будильников
            BudilnikCollection coll = new BudilnikCollection();
            BudilnikOne b1 = new BudilnikOne();
            b1.Command = "cmd.exe -r -s";
            b1.Enabled = true;
            b1.Melody = "C:\\melody.wav";
            b1.Mode = BudilnikMode.Ежедневно;
            b1.Note = "Notes for budilnik one; notes for budilnik two; \r\n notes for budilnik tree; \r\nnotes four";
            b1.Repeats = 17;
            b1.Time = DateTime.Now;
            b1.Volume = 100;
            b1.WeekDay = WeekDays.Понедельник | WeekDays.Пятница;
            coll.Add(b1);

            b1 = new BudilnikOne();
            b1.Command = "cmd.exe -r -s -t >> disabled";
            b1.Enabled = true;
            b1.Melody = "C:\\melody.wav";
            b1.Mode = BudilnikMode.Вдату;
            b1.Note = "Notes for budilnik one; notes for budilnik two; \r\n notes for budilnik tree; \r\nnotes four";
            b1.Repeats = 7;
            b1.Time = DateTime.Now;
            b1.Volume = 17;
            b1.WeekDay = WeekDays.Понедельник | WeekDays.Пятница | WeekDays.ВыходныеДни;
            coll.Add(b1);

            b1 = new BudilnikOne();
            b1.Command = "";
            b1.Enabled = true;
            b1.Melody = "C:\\melody.wav";
            b1.Mode = BudilnikMode.Ежедневно;
            b1.Note = "";
            b1.Repeats = 17;
            b1.Time = DateTime.Now;
            b1.Volume = 100;
            b1.WeekDay = WeekDays.ВсеДни;
            coll.Add(b1);

            //store to file
            coll.Store("C:\\Temp\\budilniks.xml");
            //load from file
            coll.Load("C:\\Temp\\budilniks.xml");
            //manually check values here

            //test show budilnik form
            foreach(BudilnikOne bu in coll.Будильники)
                BudilnikForm.ShowBudilnik(bu, this, "Показать будильник");

            //manually check values here
        }

        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            if (this.listView1.SelectedItems.Count == 0)
                return;

            ListViewItem lvi = this.listView1.SelectedItems[0];
            BudilnikOne bud = (BudilnikOne)lvi.Tag;//извлекаем ссылку на будильник из итема
            ПоказатьБудильник(bud, false);

            return;
        }

        private void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            //если флаг установлен, обрабатываем события чеканья галочек. Иначе - выходим.
            if (m_checkEventEnabled == false)
                return;

            ListViewItem lvi = e.Item;
            BudilnikOne bud = (BudilnikOne)e.Item.Tag;
            bud.Enabled = e.Item.Checked;

            this.m_budCollection.Changed = true;
            //тут и записать будильники в файл можно бы.
            SaveBudilniks();

            return;
        }

        private void УдалитьБудильник()
        {
            if (this.listView1.SelectedItems.Count == 0)
                return;

            ListViewItem lvi = this.listView1.SelectedItems[0];
            BudilnikOne bud = (BudilnikOne)lvi.Tag;//извлекаем ссылку на будильник из итема
            DialogResult dr = MessageBox.Show(this, "Удалить будильник?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr != DialogResult.Yes)
                return;
            //delete bud
            this.m_budCollection.Remove(bud);
            //тут и записать будильники в файл можно бы.
            SaveBudilniks();
            //обновить список будильников на форме
            this.ShowBudilniks();

            return;
        }

        /// <summary>
        /// NT-Показать форму свойств будильника при создании или просмотре будильника.
        /// Если были изменения, то сразу и сохранить будильники в файл
        /// </summary>
        /// <param name="bud">Объект будильника</param>
        /// <param name="formTitle">Название формы как описание операции для пользователя</param>
        private void ПоказатьБудильник(BudilnikOne bud, bool create)
        {
            String formTitle;
            if (create == true)
            {
                formTitle = "Создание будильника";
            }
            else
            {
                formTitle = "Редактирование будильника";
            }
            BudilnikForm bf = BudilnikForm.ShowBudilnik(bud, this, formTitle);
            
            //если диалог был закрыт не c ОК, то ничего не делаем
            if (bf.DialogResult != DialogResult.OK)
                return;
            //иначе
            //если будильник создавался новый, то добавим его в коллекцию.
            //Это также установит флаг сохранения изменений. 
            //Хотя может оказаться, что пользователь ничего не менял в параметрах будильника, его все устраивает.
            //Тогда флаг изменений в форме не будет установлен, а будильник все же надо сохранить.
            if(create == true)
                this.m_budCollection.Add(bud);
            //если будильник был изменен, то выставить флаг изменения и в коллекции будильников
            if (bf.Changed == true) 
                this.m_budCollection.Changed = true;
            //тут и записать будильники в файл можно бы.
            SaveBudilniks();
            //обновить список будильников на форме
            this.ShowBudilniks();
            
        }




        #region Контекстное меню листвиева
        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1_ItemActivate(sender, e);
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            УдалитьБудильник();
        }

        #endregion


    }
}
