﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Budilnik
{
    public enum BudilnikMode
    {
        /// <summary>
        /// Значение ошибки
        /// </summary>
        Default = 0,
        /// <summary>
        /// Будильник срабатывает ежедневно в выбранный день
        /// </summary>
        Ежедневно = 1,
        /// <summary>
        /// Будильник срабатывает однократно в указанную дату
        /// </summary>
        Вдату = 2,
    }
}
