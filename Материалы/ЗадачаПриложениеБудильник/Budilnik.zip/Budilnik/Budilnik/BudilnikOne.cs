﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Budilnik
{
    /// <summary>
    /// Представляет собственно один будильник
    /// </summary>
    public class BudilnikOne
    {
        #region Fields
        /// <summary>
        /// Включен ли будильник
        /// </summary>
        private bool m_Enabled;
        /// <summary>
        /// Режим будильника: однократный, ежедневный
        /// </summary>
        private BudilnikMode m_Mode;
        /// <summary>
        /// Время срабатывания будильника в течение суток или дата и время однократного срабатывания.
        /// </summary>
        private DateTime m_Time;
        /// <summary>
        /// Дни недели в которые будильник активен
        /// </summary>
        private WeekDays m_WeekDay;
        /// <summary>
        /// Время звучания сигнала будильника
        /// </summary>
        private Int32 m_Repeats;
        /// <summary>
        /// Путь к файлу мелодии будильника.
        /// </summary>
        private string m_Melody;
        /// <summary>
        /// Громкость сигнала будильника в %, 0..100
        /// </summary>
        private int m_Volume;
        /// <summary>
        /// Команда, которая запускается после срабатывания будильника.
        /// </summary>
        private string m_Command;
        /// <summary>
        /// Текст заметки будильника, показываемый при срабатывании будильника
        /// </summary>
        private String m_Note;

        #endregion

        /// <summary>
        /// RT-Constructor
        /// </summary>
        public BudilnikOne()
        {
            this.m_Command = String.Empty;//no command by default
            this.m_Enabled = true;//enabled by default
            this.m_Melody = String.Empty;//no melody by default
            this.m_Note = String.Empty;//no note by default
            this.m_Repeats = 5;//5 minutes by default
            this.m_Time = new DateTime(1, 1, 1, 8, 0, 0);//08:00 by default
            this.m_Volume = 70;//70% volume by default
            this.m_WeekDay = getWeekday(DateTime.Now.DayOfWeek);//current day by default
            this.m_Mode = BudilnikMode.Ежедневно;

            return;
        }

        /// <summary>
        /// RT-Constructor
        /// </summary>
        /// <param name="budText">Строка сериализованных параметров будильника</param>
        public BudilnikOne(String budText)
        {
            LoadFromString(budText);

            return;
        }

        #region Properties
        /// <summary>
        /// Включен ли будильник
        /// </summary>
        public bool Enabled
        {
            get { return m_Enabled; }
            set { m_Enabled = value; }
        }

        /// <summary>
        /// Режим будильника: однократный, ежедневный
        /// </summary>
        public BudilnikMode Mode
        {
            get { return m_Mode; }
            set { m_Mode = value; }
        }
        /// <summary>
        /// Время срабатывания будильника в течение суток
        /// </summary>
        public DateTime Time
        {
            get { return m_Time; }
            set { m_Time = value; }
        }
        /// <summary>
        /// Дни недели в которые будильник активен
        /// </summary>
        public WeekDays WeekDay
        {
            get { return m_WeekDay; }
            set { m_WeekDay = value; }
        }
        /// <summary>
        /// Время звучания сигнала будильника, минут
        /// </summary>
        public Int32 Repeats
        {
            get { return m_Repeats; }
            set 
            {
                //ограничить значение до 1..30 минут
                m_Repeats = value;
                if (m_Repeats < 1) m_Repeats = 1;
                else if(m_Repeats > 30) m_Repeats = 30;
            }
        }
        /// <summary>
        /// Путь к файлу мелодии будильника.
        /// </summary>
        public string Melody
        {
            get { return m_Melody; }
            set { m_Melody = value; }
        }
        /// <summary>
        /// Громкость сигнала будильника в %, 0..100
        /// </summary>
        public int Volume
        {
            get { return m_Volume; }
            set 
            {
                //ограничить значение до 0..100 %
                m_Volume = value;
                if (m_Volume < 0) m_Volume = 0;
                else if (m_Volume > 100) m_Volume = 100;
            }
        }
        /// <summary>
        /// Команда, которая запускается после срабатывния будильника.
        /// </summary>
        public string Command
        {
            get { return m_Command; }
            set { m_Command = value; }
        }
        /// <summary>
        /// Текст заметки будильника, показываемый при срабатывании будильника
        /// </summary>
        public String Note
        {
            get { return m_Note; }
            set { m_Note = value; }
        }
        #endregion

        /// <summary>
        /// NT-Получить день недели из указанного DayOfWeek
        /// </summary>
        /// <param name="dayOfWeek">День недели типа DayOfWeek</param>
        /// <returns>День недели типа WeekDays</returns>
        public WeekDays getWeekday(DayOfWeek dayOfWeek)
        {
            switch (dayOfWeek)
            {
                case DayOfWeek.Friday:
                    return WeekDays.Пятница;
                case DayOfWeek.Monday:
                    return WeekDays.Понедельник;
                case DayOfWeek.Saturday:
                    return WeekDays.Суббота;
                case DayOfWeek.Sunday:
                    return WeekDays.Воскресенье;
                case DayOfWeek.Thursday:
                    return WeekDays.Четверг;
                case DayOfWeek.Tuesday:
                    return WeekDays.Вторник;
                case DayOfWeek.Wednesday:
                    return WeekDays.Среда;
                default:
                    throw new ArgumentException("Неправильный день недели", "dayOfWeek");
                    break;
            }
        }
        /// <summary>
        /// Получить дни недели как строку вида Пн Вт Ср Чт Пт Сб Вс
        /// </summary>
        /// <param name="days"></param>
        /// <returns></returns>
        public static String WeekDaysAsString(WeekDays days)
        {
            StringBuilder sb = new StringBuilder();
            if ((days & WeekDays.Понедельник) != 0) sb.Append("Пн");
            if ((days & WeekDays.Вторник) != 0) sb.Append(" Вт");
            if ((days & WeekDays.Среда) != 0) sb.Append(" Ср");
            if ((days & WeekDays.Четверг) != 0) sb.Append(" Чт");
            if ((days & WeekDays.Пятница) != 0) sb.Append(" Пт");
            if ((days & WeekDays.Суббота) != 0) sb.Append(" Сб");
            if ((days & WeekDays.Воскресенье) != 0) sb.Append(" Вс");

            return sb.ToString().Trim();
        }

        /// <summary>
        /// NT-Проверить, что Будильник активен в  указанный день недели
        /// </summary>
        /// <param name="wd"></param>
        /// <returns></returns>
        public bool containsWeekDay(WeekDays wd)
        {
            return ((this.m_WeekDay & wd) != 0);
        }


        public override string ToString()
        {
            return String.Format("Time={0}; Enabled={1}; Note={2}", this.Time.ToShortTimeString(), this.Enabled, this.m_Note);
        }
        /// <summary>
        /// RT-Сохранить параметры будильника в строку текста
        /// </summary>
        /// <returns></returns>
        public String StoreToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Enabled={0};Mode={1};Time={2};", this.m_Enabled, this.m_Mode, this.m_Time);
            sb.AppendFormat("WeekDay={0};Repeats={1};Melody={2};", this.m_WeekDay, this.m_Repeats, this.m_Melody);
            sb.AppendFormat("Volume={0};Command={1};Note={2}", this.m_Volume, this.m_Command, this.m_Note);
            return sb.ToString();
        }

        /// <summary>
        /// RT-Загрузить будильник из текста
        /// </summary>
        /// <param name="text"></param>
        public void LoadFromString(String text)
        {
            //1 разделить строку на параметры по ;
            String[] sar = text.Split(new char[] { ';' }, 9, StringSplitOptions.None);//9 строк, 
            //TODO: проверить, что поле Note отдается полностью, даже если содержит ;;
            //2 каждый параметр вписать в будильник, отделив его от имени по =
            //сейчас просто идем по порядку полей, не учитываем имена параметров.
            this.m_Enabled = Boolean.Parse(getStringFromPair(sar[0]));
            this.m_Mode = (BudilnikMode)Enum.Parse(typeof(BudilnikMode), getStringFromPair(sar[1]));
            this.m_Time = DateTime.Parse(getStringFromPair(sar[2]));
            this.m_WeekDay = (WeekDays)Enum.Parse(typeof(WeekDays), getStringFromPair(sar[3]));
            this.m_Repeats = Int32.Parse(getStringFromPair(sar[4]));
            this.m_Melody = getStringFromPair(sar[5]);
            this.m_Volume = Int32.Parse(getStringFromPair(sar[6]));
            this.m_Command = getStringFromPair(sar[7]);
            this.m_Note = getStringFromPair(sar[8]);

            return;
        }

        /// <summary>
        /// RT-Извлечь значение после знака =
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private string getStringFromPair(string p)
        {
            int pos = p.IndexOf('=');
            if (pos < 0)
                throw new ApplicationException("Invalid Budilnik value: " + p);
            string val = p.Substring(pos+1);
            return val;
        }

        /// <summary>
        /// NT-Получить время следующего будильника
        /// </summary>
        /// <param name="now">Текущее время</param>
        /// <returns>Возвращает время следующего будильника или DateTime.MaxValue, если будильник не активен.</returns>
        public DateTime getTimeOfNextBudilnik(DateTime now)
        {
            if (this.Enabled == false)
                return DateTime.MaxValue;
            //else
            DateTime next = new DateTime(now.Year, now.Month, now.Day, this.m_Time.Hour, this.m_Time.Minute, this.m_Time.Second);
            //если это сегодня, то убедиться, что время еще не прошло.
            WeekDays wd = this.getWeekday(now.DayOfWeek);
            if (this.containsWeekDay(wd) == true)
            {
                //сегодня можно, если время не прошло
                if (next > now) return next;
            }
            //а если прошло или не сегодня, то считать будущее время.
            //get next date
            for(int i = 0; i < 8; i++)
            {
                next = next.AddDays(1.0d);
                wd = this.getWeekday(next.DayOfWeek);
                if (this.containsWeekDay(wd))
                    return next;
            }
            //тут мы никогда не должны оказаться, но все же
            throw new Exception("Error in next date calculation");
        }

        /// <summary>
        /// Получить дни недели будильника как строку вида Пн Вт Ср Чт Пт Сб Вс
        /// </summary>
        /// <returns></returns>
        internal string getDaysString()
        {
            return WeekDaysAsString(this.m_WeekDay);
        }
        /// <summary>
        /// Получить 20 символов как первую строку заметок будильника
        /// </summary>
        /// <returns></returns>
        internal string getNoteString()
        {
            //удалить переносы строк и табы
            String s = this.Note.Trim().Replace("\r", "").Replace("\n", "").Replace("\t", "");
            //ограничить длину 20 символами
            if (s.Length > 20)
            {
                s  = s.Remove(20);
            }
            return s;
        }

        internal String getTimeString()
        {
            if (this.m_Mode == BudilnikMode.Ежедневно)
                return String.Format("{0:D2}:{1:D2}", this.Time.Hour, this.Time.Minute);
            if (this.m_Mode == BudilnikMode.Вдату)
                return this.m_Time.ToString();
            //тут мы будем если this.m_Mode имеет неправильное значение
            throw new ApplicationException("Неправильный режим будильника");
        }
    }
}
