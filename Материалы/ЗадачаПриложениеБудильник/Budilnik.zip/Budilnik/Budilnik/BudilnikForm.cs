﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Budilnik
{
    public partial class BudilnikForm : Form
    {

        /// <summary>
        /// Отображаемый на форме будильник
        /// </summary>
        private BudilnikOne m_currentBudilnik;
        /// <summary>
        /// Any values changed - flag
        /// </summary>
        private bool m_Changed;


        public BudilnikForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Отображаемый на форме будильник
        /// </summary>
        public BudilnikOne CurrentBudilnik
        {
            get { return m_currentBudilnik; }
            set { m_currentBudilnik = value; }
        }

        /// <summary>
        /// Any values changed - flag
        /// </summary>
        public bool Changed
        {
            get { return m_Changed; }
            set { m_Changed = value; }
        }

        /// <summary>
        /// Показать форму свойств будильника
        /// Изменения будут записаны в объект будильника в памяти при закрытии формы
        /// </summary>
        /// <param name="bud">Объект будильника</param>
        /// <param name="f">Родительская форма</param>
        /// <param name="title">Название формы</param>
        public static BudilnikForm ShowBudilnik(BudilnikOne bud, Form f, String title)
        {
            BudilnikForm form = new BudilnikForm();
            form.CurrentBudilnik = bud;
            form.Text = title;
            form.ShowDialog(f);

            return form;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BudilnikForm_Load(object sender, EventArgs e)
        {
            //загрузить данные на форму
            this.textBox_Description.Text = this.CurrentBudilnik.Note;
            this.checkBox_Active.Checked = this.CurrentBudilnik.Enabled;
            //days checkboxes
            this.checkBox1.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Понедельник);
            this.checkBox2.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Вторник);
            this.checkBox3.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Среда);
            this.checkBox4.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Четверг);
            this.checkBox5.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Пятница);
            this.checkBox6.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Суббота);
            this.checkBox7.Checked = this.CurrentBudilnik.containsWeekDay(WeekDays.Воскресенье);
            //
            this.numericUpDown_Duration.Value = (Decimal)this.CurrentBudilnik.Repeats;
            this.numericUpDown_Hours.Value = (Decimal)this.CurrentBudilnik.Time.Hour;
            this.numericUpDown_Minutes.Value = (Decimal)this.CurrentBudilnik.Time.Minute;
            this.numericUpDown_Volume.Value = (Decimal)this.CurrentBudilnik.Volume;
            this.textBox_Execute.Text = this.CurrentBudilnik.Command;
            this.textBox_Melody.Text = this.CurrentBudilnik.Melody;


            //clear changed flag
            this.m_Changed = false;
            return;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_OK_Click(object sender, EventArgs e)
        {
            if (this.m_Changed == true)
            {
                //Выгрузить данные из формы
                this.CurrentBudilnik.Command = this.textBox_Execute.Text;
                this.CurrentBudilnik.Enabled = this.checkBox_Active.Checked;
                this.CurrentBudilnik.Melody = this.textBox_Melody.Text;
                this.CurrentBudilnik.Mode = BudilnikMode.Ежедневно;
                this.CurrentBudilnik.Note = this.textBox_Description.Text;
                this.CurrentBudilnik.Repeats = (Int32)this.numericUpDown_Duration.Value;
                this.CurrentBudilnik.Time = new DateTime(1, 1, 1, (Int32)this.numericUpDown_Hours.Value, (Int32)this.numericUpDown_Minutes.Value, 0);
                this.CurrentBudilnik.Volume = (Int32)this.numericUpDown_Volume.Value;
                this.CurrentBudilnik.WeekDay = makeWeekDaysValue();
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <returns></returns>
        private WeekDays makeWeekDaysValue()
        {
            WeekDays w = WeekDays.None;
            if (checkBox1.Checked) w = w | WeekDays.Понедельник;
            if (checkBox2.Checked) w = w | WeekDays.Вторник;
            if (checkBox3.Checked) w = w | WeekDays.Среда;
            if (checkBox4.Checked) w = w | WeekDays.Четверг;
            if (checkBox5.Checked) w = w | WeekDays.Пятница;
            if (checkBox6.Checked) w = w | WeekDays.Суббота;
            if (checkBox7.Checked) w = w | WeekDays.Воскресенье;

            return w;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Cancel_Click(object sender, EventArgs e)
        {
// не выгружать данные закрыть окно
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Melody_Click(object sender, EventArgs e)
        {
            //открыть диалог поиска музыкального файла
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            ofd.Filter = "Аудиофайлы (*.wav)|*.wav|Все файлы (*.*)|*.*";
            ofd.FilterIndex = 1;
            //если путь аудиофайла уже есть, открыть его каталог
            //а если нет, то открыть рабочий каталог приложения.
            String t = this.textBox_Melody.Text.Trim();
            if ((t.Length < 3) || (!File.Exists(t)))
                t = Application.ExecutablePath;//app folder path
            ofd.InitialDirectory = Path.GetDirectoryName(t);
            //next
            ofd.Multiselect = false;
            ofd.RestoreDirectory = true;
            ofd.Title = "Открыть файл мелодии будильника";
            if (ofd.ShowDialog() != DialogResult.OK)
                return;
            //set value
            this.textBox_Melody.Text = ofd.FileName;

            return;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Execute_Click(object sender, EventArgs e)
        {
// открыть диалог поиска исполняемого файла или скрипта кмд
            //тут нельзя открыть каталог старого файла, так как там еще аргументы есть, они все портят.
            //Хотя можно разобрать командную строку и убрать аргументы, но нафик сейчас лишнюю работу делать.
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            ofd.Filter = "Все файлы (*.*)|*.*";
            ofd.FilterIndex = 1;
            ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer);
            ofd.Multiselect = false;
            ofd.RestoreDirectory = true;
            ofd.Title = "Открыть исполняемый файл";
            if (ofd.ShowDialog() != DialogResult.OK)
                return;
            //set value
            this.textBox_Execute.Text = ofd.FileName;

            return;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AnyControls_ValueChanged(object sender, EventArgs e)
        {
            this.m_Changed = true;
        }


    }
}
