﻿namespace Budilnik
{
    partial class NotifyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Close = new System.Windows.Forms.Button();
            this.button_ShowBudilnik = new System.Windows.Forms.Button();
            this.textBox_Description = new System.Windows.Forms.TextBox();
            this.label_Status = new System.Windows.Forms.Label();
            this.label_Title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_Close
            // 
            this.button_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Close.Location = new System.Drawing.Point(375, 99);
            this.button_Close.Name = "button_Close";
            this.button_Close.Size = new System.Drawing.Size(75, 23);
            this.button_Close.TabIndex = 0;
            this.button_Close.Text = "Закрыть";
            this.button_Close.UseVisualStyleBackColor = true;
            this.button_Close.Click += new System.EventHandler(this.button_Close_Click);
            // 
            // button_ShowBudilnik
            // 
            this.button_ShowBudilnik.Location = new System.Drawing.Point(288, 99);
            this.button_ShowBudilnik.Name = "button_ShowBudilnik";
            this.button_ShowBudilnik.Size = new System.Drawing.Size(81, 23);
            this.button_ShowBudilnik.TabIndex = 1;
            this.button_ShowBudilnik.Text = "Будильник...";
            this.button_ShowBudilnik.UseVisualStyleBackColor = true;
            this.button_ShowBudilnik.Click += new System.EventHandler(this.button_ShowBudilnik_Click);
            // 
            // textBox_Description
            // 
            this.textBox_Description.Location = new System.Drawing.Point(13, 34);
            this.textBox_Description.Multiline = true;
            this.textBox_Description.Name = "textBox_Description";
            this.textBox_Description.ReadOnly = true;
            this.textBox_Description.Size = new System.Drawing.Size(437, 59);
            this.textBox_Description.TabIndex = 2;
            // 
            // label_Status
            // 
            this.label_Status.AutoSize = true;
            this.label_Status.Location = new System.Drawing.Point(12, 104);
            this.label_Status.Name = "label_Status";
            this.label_Status.Size = new System.Drawing.Size(44, 13);
            this.label_Status.TabIndex = 3;
            this.label_Status.Text = "Статус:";
            // 
            // label_Title
            // 
            this.label_Title.AutoSize = true;
            this.label_Title.Location = new System.Drawing.Point(12, 9);
            this.label_Title.Name = "label_Title";
            this.label_Title.Size = new System.Drawing.Size(60, 13);
            this.label_Title.TabIndex = 4;
            this.label_Title.Text = "Название:";
            // 
            // NotifyForm
            // 
            this.AcceptButton = this.button_Close;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button_Close;
            this.ClientSize = new System.Drawing.Size(462, 134);
            this.Controls.Add(this.label_Title);
            this.Controls.Add(this.label_Status);
            this.Controls.Add(this.textBox_Description);
            this.Controls.Add(this.button_ShowBudilnik);
            this.Controls.Add(this.button_Close);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NotifyForm";
            this.Text = "Уведомление будильника";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.NotifyForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Close;
        private System.Windows.Forms.Button button_ShowBudilnik;
        private System.Windows.Forms.TextBox textBox_Description;
        private System.Windows.Forms.Label label_Status;
        private System.Windows.Forms.Label label_Title;
    }
}