﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        GlobalHotkey hotkeyCTRL_K;
        GlobalHotkey hotkeyCTRL_L;
        
        public Form1()
        {
            InitializeComponent();
            // Assigns the hotkey CTRL+K and CTRL+L
            // 42 is a random identifier(and can be any thing you wish) of the hot key. 
            // No other hot key in the calling thread should have the same identifier.
            // An application must specify a value in the range 0x0000 through 0xBFFF

            hotkeyCTRL_K = new GlobalHotkey(this, 42, GlobalHotkey.MOD_CONTROL, Keys.K);
            hotkeyCTRL_L = new GlobalHotkey();
            hotkeyCTRL_L.Register(this, 43, GlobalHotkey.MOD_CONTROL, Keys.L);
            return;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SendInput1.Test();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //unregister hotkeys    
            this.hotkeyCTRL_K.Unregister();
            this.hotkeyCTRL_L.Unregister();
            return;
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            //разные сообщения окну приходят раньше, чем создаются объекты хоткеев.
            //Поэтому тут надо отфильтровывать сообщения хоткеев, которые приходят уже после создания окна.
            //если хоткеев или классов сообщений много, то лучше использовать свитч, чтобы сократить цепочку проверок:
            //if (m.Msg == GlobalHotkey.WM_HOTKEY)
            //{
            //}
            //а если нет, то так нагляднее:
            if (GlobalHotkey.ThisHotkey(m, this.hotkeyCTRL_K) == true)
            {
                //тут выполняем работу хоткея
                //обычно надо развернуть и показать окно приложения.
                //окно может быть свернуто в таскбар или в трей, так что надо его еще и развернуть

                //если окно было свернуто на таскбар, развернуть его в запомненное состояние
                //но надо сначала запомнить его было, так что это не та функция.
                if (this.WindowState == FormWindowState.Minimized)
                    this.WindowState = FormWindowState.Normal;
                if (!this.Visible)
                    this.Visible = true;
                this.Activate();
            }
            else if (GlobalHotkey.ThisHotkey(m, this.hotkeyCTRL_L) == true)
            {
                //для CTRL+L развернуть окно на весь экран или наоборот свернуть в таскбар, если оно уже развернуто.
                if (this.WindowState == FormWindowState.Minimized)
                {
                    this.WindowState = FormWindowState.Maximized;
                    this.Visible = true;
                    this.Activate();
                }
                else
                    this.WindowState = FormWindowState.Minimized;

            }
            return;
         }

    }
}
