﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{
    //Это сложный и несовершенный вариант, здесь хоткей реализован с генерацией идентификатора.
    //в этом нет смысла - проще назначать идентификаторы вручную вместе с комбинациями клавиш.
    //Тут можно зарегистрировать только один глобальный хоткей на приложение,
    //так как его идентификатор хранится в статической переменной класса.
    //Идентификаторы хоткеев все же лучше назначать вручную - здесь это не по правилам МСДН сделано. 
    //Тут есть ламбда-функция.
    //И хоткеев, как тут полагается, можно назначить для формы несколько.

    //Этот класс можно добавить в мою библиотеку классов после переработки, если он будет удачно тестирован.
    //Еще, этот класс можно переделать для попутного выявления запущенных копий приложения.
    
    
    public class WindowsShell
    {
        #region fields
        public static int MOD_ALT = 0x1;
        public static int MOD_CONTROL = 0x2;
        public static int MOD_SHIFT = 0x4;
        public static int MOD_WIN = 0x8;
        public static int WM_HOTKEY = 0x312;
        #endregion

        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vlc);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private static int keyId;
        public static void RegisterHotKey(Form f, Keys key)
        {
            int modifiers = 0;

            if ((key & Keys.Alt) == Keys.Alt)
                modifiers = modifiers | WindowsShell.MOD_ALT;

            if ((key & Keys.Control) == Keys.Control)
                modifiers = modifiers | WindowsShell.MOD_CONTROL;

            if ((key & Keys.Shift) == Keys.Shift)
                modifiers = modifiers | WindowsShell.MOD_SHIFT;

            Keys k = key & ~Keys.Control & ~Keys.Shift & ~Keys.Alt;
            keyId = f.GetHashCode(); // this should be a key unique ID, modify this if you want more than one hotkey
            RegisterHotKey((IntPtr)f.Handle, keyId, modifiers, (int)k);
        }

        private delegate void Func();

        public static void UnregisterHotKey(Form f)
        {
            try
            {
                UnregisterHotKey(f.Handle, keyId); // modify this if you want more than one hotkey
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }

    //public partial class Form1 : Form, IDisposable
    //{
    //    protected override void OnLoad(EventArgs e)
    //    {
    //        base.OnLoad(e);
    //        Keys k = Keys.A | Keys.Control;
    //        WindowsShell.RegisterHotKey(this, k);
    //    }

    //    // CF Note: The WndProc is not present in the Compact Framework (as of vers. 3.5)! please derive from the MessageWindow class in order to handle WM_HOTKEY
    //    protected override void WndProc(ref Message m)
    //    {
    //        base.WndProc(ref m);

    //        if (m.Msg == WindowsShell.WM_HOTKEY)
    //            this.Visible = !this.Visible;
    //    }

    //    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    //    {
    //        WindowsShell.UnregisterHotKey(this);
    //    }
    //}

}

//мой пример класса формы:

//namespace WindowsFormsApplication1
//{
//    public partial class Form1 : Form
//    {
//        public Form1()
//        {
//            InitializeComponent();
//        }

//        private void Form1_Load(object sender, EventArgs e)
//        {
//            Keys k = Keys.K | Keys.Control;//CTRL+K
//            WindowsShell.RegisterHotKey(this, k);
//        }

//        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
//        {
//            WindowsShell.UnregisterHotKey(this);
//        }

//        protected override void WndProc(ref Message m)
//        {
//            base.WndProc(ref m);

//            if (m.Msg == WindowsShell.WM_HOTKEY)
//            {
//                //тут выполняем работу хоткея
//                //обычно надо развернуть и показать окно приложения.
//                //окно может быть свернуто в таскбар или в трей, так что надо его еще и развернуть

//                //если окно было свернуто на таскбар, развернуть его в запомненное состояние
//                //но надо сначала запомнить его было, так что это не та функция.
//                if (this.WindowState == FormWindowState.Minimized)
//                    this.WindowState = FormWindowState.Normal;
//                //показать окно, свернутые окна не показываются так.
//                if (!this.Visible)
//                    this.Visible = true;
//                //Activating a form brings it to the front if this is the active application, 
//                //or it flashes the window caption if this is not the active application.
//                //this.Activate(); - это не обязательно, хватает и предыдущих операций
//                //а это чтобы уж точно окно показывалось над всеми, хотя оно и так показыается сейчас.
//                //this.TopMost = true; - это лучше тогда сразу в свойствах формы прописать, тогда форму нельзя будет на задний план переместить совсем никак.
//            }
//        }
//    }
//}
