﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace XmlWriterTest
{
    //Разработка многопоточного писателя в файл лога.
    //Сейчас работает как надо
    //но еще надо проверять размер файла перед записью и создавать новый файл с новым именем.
    //А если файл слишком большой, то закрывать его и открывать новый, тут же в потоке исполнения.
    //Пока не знаю как сделать новое имя файла - его должен сделать менеджер лога.
    
    
    class Program
    {
        /// <summary>
        /// Поле, которое в каждом потоке его собственное значение хранит.
        /// </summary>
        [ThreadStaticAttribute]
        public static String m_Name;
        /// <summary>
        /// Один объект файла лога на все потоки
        /// </summary>
        public static ThreadSafeXmlWriter writer1;

        static void Main(string[] args)
        {
            
            
            //create threads with single procedure
            ParameterizedThreadStart p1 = new ParameterizedThreadStart(ThreadProcedure);
            Thread t1 = new Thread(p1);
            Thread t2 = new Thread(new ParameterizedThreadStart(ThreadProcedure));
            Thread t3 = new Thread(new ParameterizedThreadStart(ThreadProcedure));

            writer1 = new ThreadSafeXmlWriter("C:\\Temp\\logtest.xml");
            writer1.Open();
            //run threads
            t1.Start("Ваня");
            t2.Start("Вася");
            t3.Start("Валя");
            

            //do work here

            //finish all
            t3.Join();
            t2.Join();
            t1.Join();

            writer1.Close();

            return;
        }

        static void ThreadProcedure(Object arg1)
        {
            //сохраним имя потока в этой уникальной переменной потока.
            m_Name = (String)arg1;
            //10 раз прокрутим цикл записи в файл лога. После каждой третьей записи закрываем лог.
            for(int i = 0; i < 10; i++)
            {
                writer1.Write(DateTime.Now.ToString("g"), m_Name, i.ToString());
                if ((i % 3) == 0)
                    writer1.Close();
                Thread.Sleep(50);//спать 1с
            }
            return;
        }
    }
}
