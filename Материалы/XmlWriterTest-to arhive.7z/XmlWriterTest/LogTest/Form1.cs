﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Operator.LogSubsystem;
using Operator;
using System.IO;

namespace LogTest
{
    //Это тест для сборки подсистемы лога Оператора.
    //Тут нужно объединить разрозненные решения в один продукт и тестировать его работу.
    //Непосредственно в Оператор это делать не хочется - мусора потом много будет в нем.
    //Лучше принести туда уже готовый код подсистемы.
    
    
    public partial class Form1 : Form
    {
        /// <summary>
        /// Менеджер лога
        /// </summary>
        private LogManager m_logman;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //это таймер для испытания таймаута файлов лога.
            //его надо подключить к функции менеджера лога 
            //включить после инициализации менеджера лога
            //выключить до завершения менеджера лога
            if (m_logman != null)
                m_logman.timer1Second();
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string setpath = "C:\\Temp\\Operator\\settings.xml";
            
            //1 загрузить файл настроек
            OperatorSettings set;
            //create file if not exists
            if (!File.Exists(setpath))
            {
                set = new OperatorSettings();
                set.Save(setpath);
            }
            //load settings from file
            set = OperatorSettings.Load(setpath);


            //2 создать менеджер лога
            this.m_logman = new LogManager();

            //3 открыть менеджер лога
            this.m_logman.Open(set);
            this.m_logman.MessageAdded += new EventHandler<LogMessageAddedEventArgs>(m_logman_m_MessageAdded);
            //4 запустить таймер таймаута
            this.timer1.Enabled = true;
            //5 сообщить пользователю о готовности
            this.toolStripStatusLabel1.Text = "Log started";
        }



        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //1 остановить таймер таймаута
            this.timer1.Enabled = false;

            //2 завершить менеджер лога
            this.m_logman.Close();
            //3 обнулить менеджер лога
            this.m_logman = null;
            //4 сообщить пользователю об остановке
            this.toolStripStatusLabel1.Text = "Log finished";
        }

        #region Async adding listbox item functions
        /// <summary>
        /// Добавить сообщение из лога в листбокс для обратного контроля
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        internal void m_logman_m_MessageAdded(object sender, LogMessageAddedEventArgs e)
        {
            //Это выполняется в потоке-исполнителе лога
            //Тут надо добавить сообщение в листбокс из другого потока.
            //Для этого я нагородил отдельный предикат и функцию, все по МСДН и пимеру из интернета.
            //Хотя там пишут, что можно через EventHandler и проще.
            
            AddListBoxItem(e.Msg.GetAsString());
            return;
        }
        /// <summary>
        /// делегат для передачи данных между потоками
        /// </summary>
        /// <param name="message"></param>
        private delegate void AddListBoxItemDelegate(string message);

        private void AddListBoxItem(string message)
        {
            if (this.listBox1.InvokeRequired)
            {
                //если это не правильный поток-владелец листбокса, то создать делегат и отправить листбоксу в правильный поток
                this.listBox1.BeginInvoke(new AddListBoxItemDelegate(AddListBoxItem), message);//вызывает асинхронно и сразу возвращается.
                //не асинхронно - нельзя, так как тогда поток-исполнитель будет ждать исполнения этого коллбека
                //а коллбек не исполняется, пока поток формы ждет в Thread.Join() завершения потока-исполнителя.
                //получается взаимоблокировка потоков, разрываемая таймаутом в Join().
                //и результат коллбека мне не нужен, поэтому все хорошо.
            }
            else
            {
                //а сейчас это правильный поток, и тут мы выполняем нужный код
                this.listBox1.Items.Add(message);
            }
        }

        #endregion


        private void sendToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LogMessage msg = new LogMessage(LogMessageCode.ВводКонсолиНеизвестнаяКоманда, LogMessage.Agent_User, "Команда пользователя");
            this.m_logman.AddMessage(msg);
            return;
        }


        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //тестировать тут отдельные функции до отладки
            //проверяем через большой объем сообщений лога - стресс-тест такой
            LogMessage msg = new LogMessage(LogMessageCode.ВводКонсолиНеизвестнаяКоманда, LogMessage.Agent_User, "Команда пользователя ");
            for (int i = 0; i < 120000; i++)
            {
                msg = new LogMessage(LogMessageCode.ВводКонсолиНеизвестнаяКоманда, LogMessage.Agent_User, "Команда пользователя " + i.ToString());
                this.m_logman.AddMessage(msg);
                Application.DoEvents();
                if((i % 1024)== 0)
                    GC.Collect();
            }

            return;
        }
    }
}
