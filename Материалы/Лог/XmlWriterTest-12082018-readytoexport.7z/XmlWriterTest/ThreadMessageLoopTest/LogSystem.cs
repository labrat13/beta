﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;

namespace ThreadMessageLoopTest
{
    public class LogSystem
    {
        /// <summary>
        /// Завершить работу лога
        /// </summary>
        private bool m_Stop;
        private Thread m_workingThread;
        private JobList m_joblist;

        private StreamWriter m_file;//log file for debugging

        public LogSystem()
        {
            m_Stop = true;//остановить исполнение потока
        }

        /// <summary>
        /// NT-Рабочая функция потока
        /// </summary>
        protected void ThreadWork()
        {
            while (!m_Stop)
            {
                CommandMessage cmd = m_joblist.WaitCommand();
                //process command
                switch (cmd.Command)
                {
                    case CommandMessageCode.AddLogMessage:
                        this.m_file.WriteLine( cmd.Argument.ToString());
                        break;
                    case CommandMessageCode.CloseLogFiles:
                        this.m_file.WriteLine("Command CloseLogFiles");
                        break;
                    case CommandMessageCode.FinishLogLoop:
                        m_Stop = true;//break while loop
                        break;
                    default:
                        //nothing to do
                        break;
                }
            }

            return;
        }

        /// <summary>
        /// Начать работу
        /// </summary>
        public void Open()
        {
            //create log file writer
            m_file = new StreamWriter("C:\\Temp\\logtest.txt", true, Encoding.GetEncoding(1251));
            m_file.AutoFlush = true;

            //создать поток исполнения
            m_workingThread = new Thread(ThreadWork);
            m_Stop = false;//разрешить работу цикла
            m_joblist = new JobList();//создать очередь команд
            m_joblist.TooManyCommandsEvent += new EventHandler(m_joblist_TooManyCommandsEvent);
            //run thread
            m_workingThread.Start();

            //вписать начальное ссобщение в лог
            m_joblist.AddCommand(new CommandMessage(CommandMessageCode.AddLogMessage, "Log opened"));
            return;
        }

        void m_joblist_TooManyCommandsEvent(object sender, EventArgs e)
        {
            this.m_file.WriteLine("Too many commands event!");
        }

        /// <summary>
        /// NT-Завершить работу
        /// </summary>
        public void Close()
        {
            m_joblist.AddCommand(new CommandMessage(CommandMessageCode.AddLogMessage, "Log closing..."));
            //отправить потоку команду завершить цикл работы
            m_joblist.AddCommand(new CommandMessage(CommandMessageCode.FinishLogLoop));
            //ждать пока рабочий поток закончит работу
            m_workingThread.Join(10000);//wait for 10 seconds
            //очистить очередь сообщений
            m_joblist.Clear();

            m_file.Close();

            return;
        }
        /// <summary>
        /// NT-Добавить сообщение в лог
        /// </summary>
        /// <param name="messageText"></param>
        public void AddMessage(String messageText)
        {
            m_joblist.AddCommand(new CommandMessage(CommandMessageCode.AddLogMessage, messageText));
        }


    }
}
