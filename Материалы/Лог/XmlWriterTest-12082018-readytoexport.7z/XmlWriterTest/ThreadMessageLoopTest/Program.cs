﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ThreadMessageLoopTest
{
    /* Это тест подсистемы лога, основанной на очереди сообщений.
     * Внутри подсистемы работает собственный поток, который выполняет команды.
     * Команды посылаются сторонними потоками в очередь сообщений подсистемы лога.
     * Рабочий поток лога получает их и исполняет
     * Если сообщений нет, рабочий поток спит на WaitHandle.
     * Пока только один поток консоли генерирует сообщения, но можно сделать и десяток внешних потоков.
     * 
     * Сейчас надо проверить идею и реализацию.
     * -Работает. Хорошо бы на множестве потоков проверить.
     */ 

    class Program
    {
        
        static void Main(string[] args)
        {
            LogSystem sys = new LogSystem();
            //open system
            sys.Open();
            //add one msg
            sys.AddMessage("Log message1");
            Thread.Sleep(1000);
            //add lot of msg
            for (int i = 0; i < 4096; i++)
            {
                sys.AddMessage(String.Format("Log message {0}", i));
            }

            //Thread.Sleep(100000);
            //close system with 10 seconds of waiting for finalize work
            sys.Close();
            //exit
            return;
        }
    }
}
