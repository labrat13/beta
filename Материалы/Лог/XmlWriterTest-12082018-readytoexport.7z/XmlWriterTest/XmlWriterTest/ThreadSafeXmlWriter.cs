﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace XmlWriterTest
{
    public class ThreadSafeXmlWriter
    {
        /// <summary>
        /// Путь к файлу лога
        /// </summary>
        private String m_filePath;
        /// <summary>
        /// Объект для синхронизации потоков
        /// </summary>
        private Object m_SyncroObject;
        /// <summary>
        /// XML writer for file
        /// </summary>
        private XmlWriter m_writer;
        /// <summary>
        /// Stream for xml writer
        /// </summary>
        private Stream m_stream;

        //public ThreadSafeXmlWriter()
        //{

        //}

        public ThreadSafeXmlWriter(String filepath)
        {
            this.m_filePath = filepath;
            this.m_writer = null;
            this.m_SyncroObject = new object();
        }

        public void Open()
        {
            lock (this.m_SyncroObject)
            {
                if (!isClosed()) return;
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.CloseOutput = true;
                settings.ConformanceLevel = ConformanceLevel.Fragment;
                settings.NewLineHandling = NewLineHandling.Entitize;
                settings.OmitXmlDeclaration = true;
                settings.NewLineOnAttributes = false;

                //open underline file stream
                Stream fs = new FileStream(this.m_filePath, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read, 1024, FileOptions.WriteThrough);
                fs.Seek(0, SeekOrigin.End);
                m_stream = fs;
                //create xml writer
                this.m_writer = XmlWriter.Create(fs, settings);
                //вписать открывающий элемент сеанса записи в лог
                this.m_writer.WriteStartElement("s");
                this.m_writer.Flush();

                return;
            }
        }

        public void Close()
        {
            lock (this.m_SyncroObject)
            {
                if (!isClosed())
                {
                    //вписать закрывающий элемент сеанса записи в лог
                    this.m_writer.WriteEndElement();
                    this.m_writer.Flush();
                    //close file
                    this.m_writer.Close();
                    this.m_writer = null;
                    //поток уже должен быть закрыт
                    this.m_stream = null;
                }
                return;
            }
        }

        /// <summary>
        /// проверить что файл закрыт
        /// </summary>
        /// <returns></returns>
        private bool isClosed()
        {
            return ((this.m_stream == null) && (this.m_writer == null));
        }

        public void Write(String p1, String p2, String p3)
        {
            lock (this.m_SyncroObject)
            {
                //check file closed
                if (isClosed())
                    this.Open();
                //write file
                this.m_writer.WriteStartElement("row");
                this.m_writer.WriteAttributeString("p1", p1);
                this.m_writer.WriteAttributeString("p2", p2);
                //this.m_writer.WriteAttributeString("p3", p3);//write long string as attribute - плохо выглядит.
                this.m_writer.WriteString(p3);//пишем длинную строку как тело тега
                this.m_writer.WriteEndElement();
                this.m_writer.Flush();

                return;
            }
        }


        public Int64 getFileSize()
        {
            lock (this.m_SyncroObject)
            {
                Int64 result = 0;
                if (isClosed())
                {
                    FileInfo fi = new FileInfo(m_filePath);
                    result = fi.Length;
                }
                else
                {
                    result = m_stream.Length;
                }
                return result;
            }
        }
    }
}
