﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace WindowsFormsApplication1
{

    //Это более сложный вариант, здесь хоткей реализован с уникальным идентификатором
    //Тут можно зарегистрировать только один глобальный хоткей на каждый объект класса
    //Зато не надо вручную назначать идентификаторы хоткеев. И нет ламбда-функций.
    //И хоткей, вероятно, только один можно назначить для формы.
    //Этот класс можно добавить в мою библиотеку классов, если он будет удачно тестирован.

    /// <summary> This class allows you to manage a hotkey </summary>
    public class GlobalHotkeys : IDisposable
    {
        [DllImport( "user32", SetLastError = true )]
        [return: MarshalAs( UnmanagedType.Bool )]
        public static extern bool RegisterHotKey (IntPtr hwnd, int id, uint fsModifiers, uint vk);
        [DllImport( "user32", SetLastError = true )]
        public static extern int UnregisterHotKey (IntPtr hwnd, int id);
        [DllImport( "kernel32", SetLastError = true )]
        public static extern short GlobalAddAtom (string lpString);
        [DllImport( "kernel32", SetLastError = true )]
        public static extern short GlobalDeleteAtom (short nAtom);

        public const int MOD_ALT = 1;
        public const int MOD_CONTROL = 2;
        public const int MOD_SHIFT = 4;
        public const int MOD_WIN = 8;

        public const int WM_HOTKEY = 0x312;

        public GlobalHotkeys(IntPtr formHandle)
        {
            this.Handle = formHandle;
        }

        /// <summary>Handle of the current process or window</summary>
        public IntPtr Handle;

        /// <summary>The ID for the hotkey</summary>
        public short HotkeyID { get; private set; }

        /// <summary>Register the hotkey</summary>
        public void RegisterGlobalHotKey(int hotkey, int modifiers)
        {
            UnregisterGlobalHotKey();

            try
            {
                // use the GlobalAddAtom API to get a unique ID (as suggested by MSDN)
                string atomName = Thread.CurrentThread.ManagedThreadId.ToString("X8") + this.GetType().FullName;
                HotkeyID = GlobalAddAtom(atomName);
                if (HotkeyID == 0)
                    throw new Exception("Unable to generate unique hotkey ID. Error: " + Marshal.GetLastWin32Error().ToString());

                // register the hotkey, throw if any error
                if (!RegisterHotKey(this.Handle, HotkeyID, (uint)modifiers, (uint)hotkey))
                    throw new Exception("Unable to register hotkey. Error: " + Marshal.GetLastWin32Error().ToString());

            }
            catch (Exception ex)
            {
                // clean up if hotkey registration failed
                Dispose();
                Console.WriteLine(ex);
            }
        }

        /// <summary>Unregister the hotkey</summary>
        public void UnregisterGlobalHotKey()
        {
            if ( this.HotkeyID != 0 )
            {
                UnregisterHotKey(this.Handle, HotkeyID);
                // clean up the atom list
                GlobalDeleteAtom(HotkeyID);
                HotkeyID = 0;
            }
        }

        public void Dispose()
        {
            UnregisterGlobalHotKey();
        }
    }



////How to use :
//переменные формы:
//GlobalHotkeys hotkey;

//в конструкторе формы или Form_Load:
//hotkey = new GlobalHotkeys();
//hotkey.RegisterGlobalHotKey( (int) Keys.F11, GlobalHotkeys.MOD_CONTROL );

//в Form_Closing():
//hotkey.UnregisterGlobalHotKey();

//protected override void WndProc (ref Message m)
//{
//     const int WM_HOTKEY = 0x0312;

//     switch ( m.Msg )
//     {
//      case WM_HOTKEY:
//      {
//           if ((short)m.WParam == hotkey.HotkeyID)
//           {
//            // do your thing
//           }
//           break;
//      }
//      default:
//      {
//           base.WndProc(ref m);
//           break;
//      }
//     }
//}


}

//мой пример класса формы:

//namespace WindowsFormsApplication1
//{
//    public partial class Form1 : Form
//    {
//        GlobalHotkeys hotkey;

//        public Form1()
//        {
//            InitializeComponent();
//            hotkey = new GlobalHotkeys(this.Handle);
//            hotkey.RegisterGlobalHotKey((int)Keys.K, GlobalHotkeys.MOD_CONTROL);
//        }

//        private void Form1_Load(object sender, EventArgs e)
//        {

//        }

//        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
//        {
//            hotkey.UnregisterGlobalHotKey();
//        }

//        protected override void WndProc(ref Message m)
//        {
//            const int WM_HOTKEY = 0x0312;

//            switch (m.Msg)
//            {
//                case WM_HOTKEY:
//                    {
//                        if ((short)m.WParam == hotkey.HotkeyID)
//                        {
//                            //тут выполняем работу хоткея
//                            //обычно надо развернуть и показать окно приложения.
//                            //окно может быть свернуто в таскбар или в трей, так что надо его еще и развернуть

//                            //если окно было свернуто на таскбар, развернуть его в запомненное состояние
//                            //но надо сначала запомнить его было, так что это не та функция.
//                            if (this.WindowState == FormWindowState.Minimized)
//                                this.WindowState = FormWindowState.Normal;
//                            //показать окно, свернутые окна не показываются так.
//                            if (!this.Visible)
//                                this.Visible = true;
//                            this.Activate();//а тут это потребовалось, без него окно не показывается
//                        }
//                        break;
//                    }
//                default:
//                    {
//                        base.WndProc(ref m);
//                        break;
//                    }
//            }
//        }

//    }
//}