﻿

//Это первый, примитивный вариант глобального хоткея
//он тут встроен в класс формы и не обрабатывает отказы в регистрации хоткея


//using System;
//using System.Windows.Forms;
//using System.Runtime.InteropServices;

//namespace WindowsFormsApplication1
//{
//    public partial class Form1 : Form
//    {
//        [DllImport("user32")]
//        public static extern int RegisterHotKey(IntPtr hwnd, int id, int fsModifiers, int vk);

//        [DllImport("user32.dll")]
//        static extern bool UnregisterHotKey(IntPtr hWnd, int id);

//        private const int MOD_ALT = 0x1;
//        private const int MOD_CONTROL = 0x2;
//        private const int MOD_SHIFT = 0x4;
//        private const int MOD_WIN = 0x8;
//        private const int WM_HOTKEY = 0x312;

//        public Form1()
//        {
//            InitializeComponent();
//            // Assigns the hotkey CTRL+K
//            // 42 is a random identifier(and can be any thing you wish) of the hot key. 
//            // No other hot key in the calling thread should have the same identifier.
//            // An application must specify a value in the range 0x0000 through 0xBFFF
//            RegisterHotKey(this.Handle, 42, MOD_CONTROL, (int)Keys.K);
//        }

//        private void Form1_Load(object sender, EventArgs e)
//        {

//        }

//        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
//        {
//            //42 informs UnregisterHotKey to unregister the hotkey with identifier 42    
//            UnregisterHotKey(this.Handle, 42);
//        }

//        protected override void WndProc(ref Message m)
//        {
//            base.WndProc(ref m);

//            if ((m.Msg == WM_HOTKEY) && ((short)m.WParam == 42))
//            {
//                //тут выполняем работу хоткея
//                //обычно надо развернуть и показать окно приложения.
//                //окно может быть свернуто в таскбар или в трей, так что надо его еще и развернуть

//                //если окно было свернуто на таскбар, развернуть его в запомненное состояние
//                //но надо сначала запомнить его было, так что это не та функция.
//                if (this.WindowState == FormWindowState.Minimized)
//                    this.WindowState = FormWindowState.Normal;
//                if (!this.Visible)
//                    this.Visible = true;
//                this.Activate();
//            }
//        }

//    }
//}


