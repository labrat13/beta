﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace TaskNotifyTest
{
    public partial class Form1 : Form
    {
        
        //Handle the form’s Resize event. In this handler, you override the basic functionality of the 
        //    Resize event to make the form minimize to the system tray and not to the taskbar. 
        //This can be done by doing the following in your form’s Resize event handler: 
        //Check whether the form’s WindowState property is set to FormWindowState.Minimized. 
        //    If yes, hide your form, enable the NotifyIcon object, and show the balloon tip that 
        //        shows some information. Once the WindowState becomes FormWindowState.Normal, 
        //disable the NotifyIcon object by setting its Visible property to false. 
        //Now, you want the window to reappear when you double click on the NotifyIcon object in the taskbar. 
        //For this, handle the NotifyIcon’s MouseDoubleClick event. 
        //Here, you show the form using the Show() method.
        
        public Form1()
        {
            InitializeComponent();
        }
        #region Notify icon handler
        //При двойном клике срабатывает сначала Одиночный клик, а потом - двойной клик. Не раздельно.
        //И правый клик генерирует одиночный клик, и показывает контекстное меню.
        //Поэтому надо отличать в обработчике кликов левый клик от правого
        //И не использовать одновременно одиночный клик и двойной клик.
        //И если не назначить для notifyIcon иконку, то ничего не будет отображаться в трее.

        //А мессагобоксы выводятся и перекрываются уже существующими окнами рабочего стола.
        //Но они не останавливают исполняющий поток в такой реализации как здесь.

        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            Show();
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            notifyIcon1.Visible = false;
        }

        /// <summary>
        /// Обычно один левый клик по иконке показывает некий диалог информации.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Один клик по иконке");
        }
        //Это событие генерируется и при закрытии балуна нажатием на крестик, и по истечении таймаута балуна.
        private void notifyIcon1_BalloonTipClosed(object sender, EventArgs e)
        {
            //MessageBox.Show("Отрицательная реакция на сообщение");
        }

        private void notifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {
            MessageBox.Show("Положительная реакция на сообщение");
        }
#endregion

        #region Form handlers
        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                notifyIcon1.Visible = true;
                notifyIcon1.ShowBalloonTip(3000);
                this.ShowInTaskbar = false;
            }
            else if (this.WindowState != FormWindowState.Minimized)
            {
                notifyIcon1.Visible = false;
            }
        }
        #endregion
        #region Context Menu Handlers
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //close form exit app
            this.Close();
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //call form expand handler
            notifyIcon1_DoubleClick(sender, e);
        }
        #endregion

        
        private void ShowBaloon(String Title, String text, System.Windows.Forms.ToolTipIcon icon, int time)
        {
            //Этот вызов не изменяет установленные ранее тексты и иконку
            //Но он не показывает ничего, если notifyIcon невидим
            //Поэтому включаем нотификатор, а потом возвращаем в исходное состояние.
            //-Это не помогает, так как код выполняется раньше, чем балун завершится.
            // Так как это асинхронный процесс.
            // Надо перехватывать события балун кликед и балун клозед, и в них возвращать балун в исходное запомненное состояние.
            // Получается полностью асинхронная схема на обработчиках и переменных.
            // Можно сделать ее отдельным классом, только где его потом использовать?

            //bool oldVisible = notifyIcon1.Visible;
            //notifyIcon1.Visible = true;
            notifyIcon1.ShowBalloonTip(time, Title, text, icon);
            //notifyIcon1.Visible = oldVisible;
            return;
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            notifyIcon1.Visible = true;//включим балун на время показа сообщений
            ShowBaloon("Click", "Click occurs", ToolTipIcon.Info, 1000);
            Application.DoEvents();
            Thread.Sleep(1000);
            ShowBaloon("Click", "Click occurs", ToolTipIcon.Warning, 1000);
            Application.DoEvents();
            Thread.Sleep(1000);
            ShowBaloon("Click", "111111111111111111111\n111111111111111111111111111\n11111111111111111111111\n1111111111111111111111\n111111111111111111111111111111\n11111111111111111111111111\n1111111111111111111111111\n1111111111111111111\n1111111111111111111\n1111111111111111111111111\n11111111111111111111", ToolTipIcon.Error, 1000);
            Application.DoEvents();
            Thread.Sleep(1000);
            MessageBox.Show(notifyIcon1.BalloonTipTitle);
            notifyIcon1.Visible = false;//выключим балун после показа сообщений
        }
    }
}
