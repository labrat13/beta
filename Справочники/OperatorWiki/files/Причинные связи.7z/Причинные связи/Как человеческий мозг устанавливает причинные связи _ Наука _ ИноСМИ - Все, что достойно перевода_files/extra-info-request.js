$(function() {

    var windowExtraInfoRequestItems = $('.window-extra-info-request');

    windowExtraInfoRequest = windowExtraInfoRequestItems.filter('.modalWindow').modalWindow();

    var errorMessages = {
        firstName: {
            empty: GLOBAL.locale.id.errors.emptyFirstName
        },
        lastName: {
            empty: GLOBAL.locale.id.errors.emptyLastName
        },
        work: {
            empty: GLOBAL.locale.id.errors.emptyWork
        },
        places: {
            empty: GLOBAL.locale.id.errors.emptyPlaces
        },
        expert: {
            empty: GLOBAL.locale.id.errors.emptyExpert
        }
    };

    windowExtraInfoRequest.find('form').riaForm({
        errorInput: true,
        errorLabel: true,
        errorMessage: false,
        errorAlert: true,
        alert: '.window-extra-info-request .error-message',
        rules: {
            firstName: 'empty',
            lastName: 'empty',
            work: 'empty',
            places: 'empty',
            expert: 'empty'
        },
        messages: errorMessages,
        alerts: errorMessages,
        successCallback: function(data) {
             GLOBAL.events.trigger('modalWindowClose');
             GLOBAL.events.trigger('updateArticleBody');

             Cookies.set('ino_lg', data.ino_lg, { expires: 30, path: '/', domain: GLOBAL.cookie_domain });
        }
    });

});
