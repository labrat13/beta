(function() {
	(document.createElement('IMG')).src = 'https://t.trafmag.com/images/1px-matching-mgid.gif?id=i6eOMoeY04jk';
})()
