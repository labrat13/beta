/**
 * @file jQuery waForm
 * @version 1.1
 * @author Andrey Efremov <efremov@web-artel.ru>
 * @copyright (c) Web-Artel LLC
 * @requires jQuery, jQuery.Form, jQuery.waGlobal
 */
!function(r){"use strict";r.fn.waForm=function(n){function e(n,e){if("errors"in n&&n.errors instanceof Object){for(var i in n.errors)e.find(":input[name='"+i+"']").addClass("invalid");"captcha"in n.errors&&e.find("img.captcha").refreshCaptcha()}else r.waGlobal.openPopupError()}function i(r,n){n.find(":input.invalid").removeClass("invalid")}var n=r.extend({success:function(){}},n||{});return this.ajaxForm({dataType:"json",beforeSubmit:i,success:function(r,i,s,o){"success"in r?n.success(r,o):e(r,o)},error:r.waGlobal.openPopupError}),this}}(jQuery);