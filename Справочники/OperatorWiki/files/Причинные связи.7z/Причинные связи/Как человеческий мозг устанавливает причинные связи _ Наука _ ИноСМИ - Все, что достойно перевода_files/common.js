/**
 * @file Common JavaScript
 * @author Andrey Efremov <efremov@web-artel.ru>
 * @copyright (c) Web-Artel LLC
 * @requires jQuery, jQuery.Placeholder, Magnific Popup, jQuery.waGlobal, jQuery.waForm
 */
!function(o){"use strict";o(function(){o(":input[placeholder]").placeholder(),o(".layout__scroll-to-top").click(function(){return o("html, body").animate({scrollTop:0},"slow"),!1}).affix({offset:{top:o(window).height(),bottom:o(".footer").outerHeight(!0)+10}}),o(".popup-link").magnificPopup(o.extend(!0,{callbacks:{change:function(){this.content.find("img.captcha").refreshCaptcha()}}},o.waGlobal.mfpOptions)),o(".popup").on("click",".close",function(){o.magnificPopup.close()}),o("#popup-suggest").waForm({success:function(t,c){o.magnificPopup.close(),c.resetForm()}});var t=o(".sticky");Stickyfill.add(t)})}(jQuery);