/**
 * @file jQuery waGlobal
 * @version 1.0
 * @author Andrey Efremov <efremov@web-artel.ru>
 * @copyright (c) Web-Artel LLC
 * @requires jQuery, Magnific Popup
 */
!function(p){"use strict";p.waGlobal={mfpOptions:{type:"inline",midClick:!0,preloader:!1,removalDelay:300,mainClass:"mfp-fade"},popupError:"#popup-error",openPopupError:function(){p(p.waGlobal.popupError).openPopup()},popupLoginLink:"#popup-login-link",openPopupLogin:function(){p(p.waGlobal.popupLoginLink).magnificPopup("open")}},p.fn.refreshCaptcha=function(){var p=document.createElement("a");return p.href=this.attr("src"),p.search=(new Date).getTime(),this.attr("src",p.href),this},p.fn.openPopup=function(){return p.magnificPopup.open(p.extend(!0,{items:{src:this}},p.waGlobal.mfpOptions)),this}}(jQuery);