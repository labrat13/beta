;"use strict";
/* RADIO CHECKBOX */
(function ( $, window, document, undefined ) {
	var isbEasySwitchesFunc = function(el, options){
		var defaults = {
			htmlRadio: false,                                   // html for radio
			htmlCheckbox: false,                                // html for checkbox
			debug: false,                                       // debug messages in console
			hideEl: true,                                       // hide default element
			callback: false,                                    // callback function, data only function type
			classes : {
				main:           "isb-easySwitches",
				radio:          "isb-easySwitches-radio",
				checkbox:       "isb-easySwitches-checkbox",
				icon:           "isb-easySwitches-icon",
				inputChecked:   "isb-easySwitches-checked",
				inputDisabled:  "isb-easySwitches-disabled"
			}
		};
		var _this = this;
		_this.$el = $(el);
		_this.defOptions = defaults;
		_this.userOptions = options;
		_this.options = $.extend(true, {}, defaults, options);
		$.each(_this.options.classes, function(index,value){
			_this.options.classes[index] = _this.toStr(value);
		});
		_this.init();
	};
	isbEasySwitchesFunc.prototype = {
		init: function(){
			var _this = this;
			if ( this.options.debug ) {
				_this.cLog = function(el){console.log('isbEasySwitches: '+el)};
			}
			if ( _this.$el.attr('type') === 'radio' ){
				_this.$el.after(_this.createRadio());
				_this.cLog('radio create');
			} else if ( _this.$el.attr('type') === 'checkbox' ){
				_this.$el.after(_this.createCheckbox());
				_this.cLog('checkbox create');
			}
			if ( _this.options.hideEl ){
				_this.$el.hide();
			}
			_this.$customEl = _this.$el.next();
			_this.update();
			_this.addEvent();
			if (_this.options.callback && typeof _this.options.callback == "function") {
				_this.callbackFunction = _this.options.callback;
			}
		},
		update: function(){
			var _this = this;
			if ( _this.$el.is(':checked') ){
				_this.checkedEl();
			} else {
				_this.uncheckedEl();
			}
			if ( _this.$el.is(':disabled') ){
				_this.disabledEl();
			} else {
				_this.enabledEl();
			}
		},
		createRadio: function(){
			var _this = this,
				newSelect = '<span class="'+_this.options.classes.main+' '+_this.options.classes.radio+'">';
			if (_this.options.htmlRadio){
				newSelect += _this.options.htmlRadio;
			} else {
				newSelect += '<span class="'+_this.options.classes.icon+'"></span>';
			}
			newSelect += '</span>';
			return newSelect;
		},
		createCheckbox: function(){
			var _this = this,
				newSelect = '<span class="'+_this.options.classes.main+' '+_this.options.classes.checkbox+'">';
			if (_this.options.htmlCheckbox){
				newSelect += _this.options.htmlCheckbox;
			} else {
				newSelect += '<img class="'+_this.options.classes.icon+'" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RTBCMkEwQTRDRjFBMTFFNTlBRjA5QkVGRDlCRDk0RDUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RTBCMkEwQTVDRjFBMTFFNTlBRjA5QkVGRDlCRDk0RDUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpFMEIyQTBBMkNGMUExMUU1OUFGMDlCRUZEOUJEOTRENSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpFMEIyQTBBM0NGMUExMUU1OUFGMDlCRUZEOUJEOTRENSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PluI0lEAAAbuSURBVHja7FtriFVVFN4rJzWiSelFEdFUhEoR9ICKoggqKCgIESeiKEJ7WAo+aCqlrLRSIwoqpqIhLZmQtJcJaRFGEPSjJgwjC3pZBk1DP7KJydW3n2fvfc7MnXvvuec+t66z93ncfc5aez2+tc4ZYmbRzu0w0eatI4COADoC6AigrVtXqQtu2bxPkNuTI1Y94x8Fx/yWdawm7XTQk6CXQO8L+3SE+5vwzuZpBnrPaD0NAHMPoLsB9DroPtCR7WMCRHOxsjcbPZsBWovxII7NagcBnAwVX41+CoUGei2E8B6G843mt6QACEwuA812hhB6n9MgnE0YPgM6oWEEwDkRVP9qrPptFMybLDaTGk/BdYtA27B3WStpwEwkb4+hP0qQjUGkYpKUgfL41vujx/8LcWQrdldUHAZz09scNIg0I+eqEMz2OOuwZ4JzcD99eCYOz24FDZCqfLdceYoFK1fdxX3vrD7+LUYP1V0DqtEDrPIx+OXDSvWlaruZKMMJmrP61Cg2Mlr80OwasFB4zox80WQLzMplqwFJTe0EzwfDS3xf4PeU0i4yi8+/YCu15lBVuUD+wbCsdgQYkl7/OGHwvcX5NI6FsbkG0UDa/d5mB0J3gKWr2Do0E96yRanCnl59Zqn6A82OBM8BP8tj1+kreuz+zLFfSXv9sWYWwDTQSjByokl8stNtIs8nqNEhnNmAfqjIZEjOcUklqegE7UbQ9ezH84xoSl44JCUM/gg7LxaZDR4Negr0tumn5cB8D2gVWO6iFNcU2j/bMKgAz4jQ9YG/ihLARaB3cOfFCqMLsQD9K6DuiuMAkXweCVxOVUpO4/yaPSiUmIdcgM+KKIhMBS0FvQW6NNLKXgShjehPqjBI9mKm+da2Nd4nk+GxFZJh2vgALYxPsHmWKrTfctqZoI14pvUkY3O8Ngqn83UYvWbqdWWpPmL3g5ipy8V7i+59H2Bwvw2NuOpPDKTXHxE1FsBc3GgHbjwvsb1xUD6Jy7HdDJpTxvzLwfWshE/OrCck1mI9IcmC6K5qPHipdgponWGoh9xK+1ZpHBQHXvsC0CDovEnc4xrQrUHq64c+c7/gnlr1h9BvqDaElcrfJBRdZmEzpxiP18h/VHGWEcJEVZljweDjsPPpnpmHmT2nIQ/aQXR9uPiA+kEpqkIDBjHBsE4xyeXfNuUgv1xh09AgVSHpC94wq5zl+ftw+dnazq2XJ2P3Ge8XdLyXg5ex2Z4HiCnV3gXD8Po85laCsl58cABa2KEztX+8cYzzfEbQrsTp24WX4QvPwyd9VBkisQfdE3kgrsk6wQHceK1bAY5U3aiZB0v0WU/9oOIzsNPv2Xq3rtRwd5zZOxu3b3g8yAvNGMVkj+LEz64SNBmqNh2GUq7BTD2Y7CYyQiBjFvYhKUDqoe2aUCaR43PYm4oLZBi9WHjprS1qUoz03L3UGD6Ft+SFucupB/wDukeBHBZXUIzTOW0S5GmMYkEzMB0bCEH8F3q7xKzYOjrSAkngLv0kYfJkM72ccYB6jBFVmBS8zznoOA5QBFFtgULjdXNcQd7DzfKmilsWBlssQG56XjVRfa/WQMi2veDiTjzWsK2+6KU1sdr6B+sMKTQFdiuqljdBkBbi2rk40SAjgi2l6ntFCUC2nVihFSTV2DkZ66wkdo9tnwymdyNTwSFbwTHqY2GuDwjUiR+xeQT0b6MIQDYZh9cEMFWtWvLSIvHe5goOQqBzARRhKoojqxDr0X1Vi8pLZQJgl6BIAWwKsB9RZo7AIv1WgCOPn678qtEO0sIWjSMAPzIQLcFj7na2yh54ib7SiBMdouhlFpEnNOUTgEABd4X4u1EFINsfJKu3zN/HaDBA7lFJMyWY7K9qJNr7opbFx7yKol+Dg4W6HBUnHxzYAwvv9VUqyrKfvHwI6q919TXPqvBOod7g8EEL2IMEhiglEvJBEAXaM6Le6ek6X30FUPKjBWaX+LCqCdLTicenxNmxq+B4BsAZLlL5kecx+LiI+nsN3guo8tSglwkmb+uyIkXkMDH43BRgRJMKAGCF6F6w9Wls51khL8ohpLe/X6g6X/MKQLbfIYQFKmcIKrqh0nO6OPICth+IAttkSmJlkVe53aOyR+ZhPz+kaF6P+S+Ffq0lGkoAVTZZRe6z6es4BiE1Ycx4/f2tJgDJZj8YXGcLJOzCYvIpC/TiVZzYJurQCnk7DB5Xg+VBF+xMWDSfsnyHzUpR4kuOphaAqSYtBrbfHZXZJPSTzO8XdWpFfh9wAKu9yK/oQANkpfhNUcdW6AcSYHgI9n8XVh1Oj36DK5DV3dF6CqCr8Dsyb4feL1XVJEHfFPSHFeP7p84fTrZ56wigI4COADoCaOv2vwADAMTix/km1XTAAAAAAElFTkSuQmCC"/>';
			}
			newSelect += '</span>';
			return newSelect;
		},
		addEvent: function(){
			var _this = this;
			_this.$el.on('change', function(){
				_this.handleChange();
			});
			_this.$customEl.on('click', function(e){
				e.preventDefault();
				if ( !_this.$el.is(':disabled') ){
					if (_this.$el.is(':checked') && _this.$el.attr('type') === 'checkbox') {
						_this.$el.prop( "checked", false );
					} else {
						_this.$el.prop( "checked", true );
					}
					_this.$el.change();
				}
			});
		},
		handleChange: function(){
			var _this = this,
				newEl = _this.$customEl;
			if ( _this.$el.attr('type') === 'radio' ){
				newEl = $('input[name="'+_this.$el.attr('name')+'"]');
				newEl.each(function(){
					if($(this).data('isbEasySwitches')){
						$(this).data('isbEasySwitches').uncheckedEl();
					}
				});
			}
			if (_this.$el.is(':checked')) {
				_this.checkedEl();
			} else {
				_this.uncheckedEl();
			}
			_this.callbackFunction(_this.$el);
		},
		checkedEl: function(){
			var _this = this;
			_this.$customEl.addClass(_this.options.classes.inputChecked);
		},
		uncheckedEl: function(){
			var _this = this;
			_this.$customEl.removeClass(_this.options.classes.inputChecked);
		},
		disabledEl: function(){
			var _this = this;
			_this.$customEl.addClass(_this.options.classes.inputDisabled);
		},
		enabledEl: function(){
			var _this = this;
			_this.$customEl.removeClass(_this.options.classes.inputDisabled);
		},
		cLog: function(el){},
		callbackFunction: function(){},
		toStr: function(str){
			if(str.substr(0,1) == '.'){
				return str.substr(1);
			}
			return str;
		}
	};
	$.fn.isbEasySwitches = function(options) {
		return this.each(function(){
			if(!$.data(this, 'isbEasySwitches') && ($(this).attr('type') === 'radio' || $(this).attr('type') === 'checkbox')){
				$.data(this, 'isbEasySwitches', new isbEasySwitchesFunc(this, options));
			}
		});
	};

})( jQuery, window, document );