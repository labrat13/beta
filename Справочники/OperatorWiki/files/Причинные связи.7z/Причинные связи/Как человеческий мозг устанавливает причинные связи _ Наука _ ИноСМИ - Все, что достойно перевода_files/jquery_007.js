/**
 * @file jQuery waNavigator
 * @version 1.1
 * @author Andrey Efremov <efremov@web-artel.ru>
 * @copyright (c) Web-Artel LLC
 * @requires jQuery, jQuery Mobile Events
 */
!function(t){"use strict";t.fn.waNavigator=function(a){var a=t.extend({tab:".tab",current:"current",active:"active",delay:200},a||{}),i=this,n=this.find(a.tab),e=n.filter("."+a.current);return n.on("nav:activate",function(){t(this).data("timeout",setTimeout(t.proxy(function(){var n=t(this);n.addClass(a.active).siblings().removeClass(a.active),i.find("#"+n.data("id")).addClass(a.active).siblings().removeClass(a.active)},this),a.delay))}).on("nav:abort",function(){clearTimeout(t(this).data("timeout"))}),t.isTouchCapable()?n.click(!1).tap(function(){var n=t(this);if(n.hasClass(a.active)){var e=n.find("a");e.length&&window.location.assign(e.attr("href"))}else if(i.find("#"+n.data("id")).find("a").length)t(this).trigger("nav:activate");else{var e=n.find("a");e.length&&window.location.assign(e.attr("href"))}return!1}):(n.hover(function(){t(this).trigger("nav:activate")},function(){t(this).trigger("nav:abort")}),i.hover(function(){e.trigger("nav:abort")},function(){e.trigger("nav:activate")})),e.hasClass(a.active)||e.trigger("nav:activate"),this}}(jQuery);