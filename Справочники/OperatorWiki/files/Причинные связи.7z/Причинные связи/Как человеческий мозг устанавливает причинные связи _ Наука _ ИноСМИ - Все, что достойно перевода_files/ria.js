;"use strict";

(function ( $, window, document, undefined ) {
	var riaVote = function(el, options){
		var defaults = {
			settings: {
				localstore: 'ria.ru__ria-votes',        // префикс имен для хранения значений в localstorage
				indexLength: 100                        // максимальное кол-во записей в localstorage
			},
			classes : {
				mShowResult: 'm-result',
				mNotSelected: 'm-not-selected',
				form: 'b-vote__form',
				result: 'b-vote__result',
				disabled: 'b-vote__disabled',
				placeShowResult: 'b-vote__show-result',
				placeToVote: 'b-vote__to-vote'
			},
			dataAttr:{
				id: 'vote-id',
				showResult: 'show-result',
				voteType: 'vote-type'
			}
		};
		var _this = this;
		_this.$el = $(el);
		_this.defOptions = defaults;
		_this.userOptions = options;
		_this.options = $.extend(true, {}, defaults, options);
		_this.cl = _this.options.classes;
		_this.da = _this.options.dataAttr;
		_this.st = _this.options.settings;
		if (!_this.$el.hasClass(_this.cl.disabled)) {
			_this.init();
		}
	};
	riaVote.prototype = {
		init: function(){
			var _this = this;
			_this.id = _this.$el.attr('data-'+_this.da.id);
			_this.showResult = _this.$el.attr('data-'+_this.da.showResult);
			_this.$result = $('.'+_this.cl.result, _this.$el);
			_this.$form = $('.'+_this.cl.form, _this.$el);
			_this.$placeShowResult = $('.'+_this.cl.placeShowResult, _this.$el);
			_this.$placeToVote = $('.'+_this.cl.placeToVote, _this.$el);
			if ( _this.showResult == '' ){
				var localstoreData = _this.getLocalStorage(_this.st.localstore) || [];
				if (localstoreData.indexOf(_this.id) >= 0){
					_this.$form.remove();
					_this.$result.show();
					_this.$el.addClass(_this.cl.mShowResult);
					_this.$placeToVote.remove();
				}
			} else if ( _this.showResult == 1 ){
				_this.$placeToVote.remove();
			}
			_this.$form.bind('submit', function(e) {
				e.preventDefault();
				if (_this.$form.find('input').is(':checked') ){
					$.ajax({
						url: _this.$form.attr('action')+'?vote_type='+_this.$el.attr('data-'+_this.da.voteType),
						data: _this.$form.serialize(),
						dataType: 'html',
						type: 'POST',
						success: function(data) {
							_this.updateLocalStorage(_this.id);
							_this.$placeShowResult.insertBefore( ".b-vote__submit" );
							_this.$form.remove();
							_this.$result.html(data).show();
							_this.$el.addClass(_this.cl.mShowResult);
						}
					});
				} else {
					_this.$form.addClass(_this.cl.mNotSelected);
					setTimeout( function(){
						_this.$form.removeClass(_this.cl.mNotSelected);
					}, 1000);
				}
			});
			if ( _this.$result.length > 0 && _this.$form.length > 0 ){
				$('a', _this.$placeShowResult).on('click', function(e){
					e.preventDefault();
					_this.$result.show();
					_this.$form.hide();
				});
				$('a', _this.$placeToVote).on('click', function(e){
					e.preventDefault();
					_this.$form.show();
					_this.$result.hide();
				});
			} else {
				_this.$placeShowResult.remove();
				_this.$placeToVote.remove();
			}
		},
		getLocalStorage : function(name){
			return JSON.parse(localStorage.getItem(name));
		},
		setLocalStorage : function(name, data){
			localStorage.setItem(name, JSON.stringify(data));
		},
		updateLocalStorage : function(id){
			var _this = this,
				localstoreData = _this.getLocalStorage(_this.st.localstore) || [];
			var indexEl = localstoreData.indexOf(id);
			if (indexEl >= 0 && indexEl < localstoreData.length) {
				localstoreData.splice(indexEl,1);
			}
			localstoreData.push(id.toString());
			if ( localstoreData.length > _this.st.indexLength) localstoreData.splice(0,1);
			_this.setLocalStorage(_this.st.localstore, localstoreData);
		}
	};
	$.fn.riaVote = function(options) {
		return this.each(function(){
			if(!$.data(this, 'riaVote')){
				$.data(this, 'riaVote', new riaVote(this, options));
			}
		});
	};
})( jQuery, window, document );
