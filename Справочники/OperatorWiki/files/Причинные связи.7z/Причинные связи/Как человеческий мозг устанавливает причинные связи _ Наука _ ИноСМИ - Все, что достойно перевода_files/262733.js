
        if ("undefined" === typeof(__da_info_loaded)) {
            var newScript = document.createElement("script");
            newScript.type = "text/javascript";
            newScript.src =  "https://st.directadvert.ru/news/js/info.min.js?t=1531594016";
            document.getElementsByTagName("head")[0].appendChild(newScript);
            __da_info_loaded = 1;
        }
    if(document.getElementById('DIV_DA_262733')) { 
            if (typeof __da_widget_count == 'undefined') {
                __da_widget_count = 0;
            }
            __da_widget_count++;
        document.write('<script charset="windows-1251" type="text/javascript" src="//www.directadvert.net/data/262733.js?nnn=262733&div=DIV_DA_262733&t=0.592056644429533"></script>');eval("try {new Image().src = '//counter.yadro.ru/hit;All_da_nnn_dn_realty?r'+escape(document.referrer)+((typeof(screen)=='undefined')?'':';s'+screen.width+'*'+screen.height+'*'+(screen.colorDepth?screen.colorDepth:screen.pixelDepth))+';u'+escape(document.URL)+';'+Math.random();} catch (e) {}");} 