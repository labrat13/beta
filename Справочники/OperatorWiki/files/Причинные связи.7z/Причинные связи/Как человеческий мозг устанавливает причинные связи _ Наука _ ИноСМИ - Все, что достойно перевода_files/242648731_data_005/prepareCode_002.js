if (window.addSection) {

var lid = '';

if(lid != ''){
        lid = '<b>'+lid+'</b><br>';
}

addSection({
	tagName: 'div',
	attributes: {
		className: 'tiz_block0_item_03102016'
	},
	inner: [{
		tagName: 'a',
		attributes: {
			className: 'tiz_block0_a1_03102016',
			target: '_blank',
			href: 'https://ads.adfox.ru/249922/goLink?hash=dc48ca78c05ac8f0&rqs=9olYHwwAAABNRUpbo5CR4CW7NndGWU3A&pr=babwuzu&sj=bkE2JI57NNP1uEoVPtltZzUkNREjvvsy-E40XA_dvbjcFT387qiL6587xkatWrfkDeoeOQONOc9FTKoouqsue2pZFr2-YdnyFThQm3BdBg%3D%3D&p2=flqy&rand=btiujzj&p1=bwdqb&p5=frqpn@http://russian.people.com.cn/n3/2018/0712/c31516-9480098.html'
		},
		inner: [{
			tagName: 'img',
			attributes: {
				src: 'https://banners.adfox.ru/180712/adfox/639638/2594891_3.jpg'
			}
		}]
	}, {
		tagName: 'a',
		attributes: {
			className: 'tiz_block0_a2_03102016',
			target: '_blank',
			href: 'https://ads.adfox.ru/249922/goLink?hash=dc48ca78c05ac8f0&rqs=9olYHwwAAABNRUpbo5CR4CW7NndGWU3A&pr=babwuzu&sj=bkE2JI57NNP1uEoVPtltZzUkNREjvvsy-E40XA_dvbjcFT387qiL6587xkatWrfkDeoeOQONOc9FTKoouqsue2pZFr2-YdnyFThQm3BdBg%3D%3D&p2=flqy&rand=btiujzj&p1=bwdqb&p5=frqpn@http://russian.people.com.cn/n3/2018/0712/c31516-9480098.html'
		},
		inner: lid+'Тайфун \"Мария\" обрушился на восток Китая'
	}]
});
} else {
	document.write('<a href="http://russian.people.com.cn/n3/2018/0712/c31516-9480098.html" target="_blank">' +
		'	<img src="https://banners.adfox.ru/180712/adfox/639638/2594891_3.jpg">' +
		'</a>' +
		'<a href="http://russian.people.com.cn/n3/2018/0712/c31516-9480098.html" target="_blank">' +
		'	Тайфун \"Мария\" обрушился на восток Китая' +
		'</a>');
}
if (window.location.hostname === 'www.preview-adfox.ru') {
var div = document.createElement('div');
   div.innerHTML='<span style="">http://russian.people.com.cn/n3/2018/0712/c31516-9480098.html</span><br>';
document.body.appendChild(div);
}