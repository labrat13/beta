//v1.0.1
(function(URLs) {
	for (var i = 0; i < URLs.length && URLs[i]; i++) {
		if (!URLs[i].match(/adfox\.ru\/transparent\.gif$/)) {
			(function(url, img) {
				img.src = url;
			})(URLs[i], new Image());
		}
	}
})('https://banners.adfox.ru/transparent.gif'.split('|'));

(function() {
	var data = {
		url: {
			value: 'https://ads.adfox.ru/249922/prepareCode?pp=jdp&ps=cjnp&p2=flqy&puid1=&puid2=&puid3=&pr=309773614'
		},
		i: {
			value: '3'
		},
		titleText: {
			value: ''
		},
		titleImage: {
			value: 'https://banners.adfox.ru/170123/adfox/625402/1948650_4.png'
		},
		cssClassName: {
			value: 'inosmi_tiz_block_partners001_03102016'
		},
                cssFile: {
			value: 'https://banners.adfox.ru/180302/adfox/625402/1948650_6.css'
   		}
	 };
        

	var Banner = function() {
	/* global.banners v1.0.1 */
	var undoList = [];

	Banner.prototype.setUndo = function(undo) {
		undoList.push(undo);
	};

	Banner.prototype.init = function() {
		var async = !!527130316;
		var win = ( async ? parent : window );
		var doc = win.document;
		var rnd = 527130316 || 309773614;

		if (async) {
			setTimeout(function() {
				document.close();
			}, 100);
			self.adfoxRemoveBanner = function() {
				banner.remove();
				win.eval(''+
					'(function() {\n'+
					'	var _iframe = document.getElementById(\'AdFox_iframe_' + rnd + '\'),\n'+
					'		_parent = _iframe.parentNode;\n'+
					'		_parent.removeChild(_iframe);\n'+
					'		_parent.appendChild(_iframe);\n'+
					'})()'+
				'');
			};
			this.setUndo({
				func: function() {
					var wrapper = CreateParams.prototype.wrapper;
					wrapper.innerHTML = '';
					wrapper.style.cssText = '';
				}
			});
		} else {
			doc.write('<div id="AdFox_banner_' + rnd + '"></div>');
			this.setUndo({
				func: function() {
					CreateParams.prototype.wrapper.removeChild(this.wrapper);
				}
			});
		}

		CreateParams.prototype = {
			async: async,
			win: win,
			rnd: rnd,
			doc: doc,
			wrapper: doc.getElementById('AdFox_banner_' + rnd),
			bannerId: 2426091,
			validityErr: []
		};
	};

	this.remove = function() {
		for (var i = 0; i < undoList.length; i++) {
			undoList[i].func();
		}
		undoList = [];
	}
}
	var CreateParams = function(data) {
	/* global.createParams v1.0.1 */
	function validity(v, mask) {
		var 
			masks = {
				size: [
					/^\d+$/,
					/^\d+px$/,
					/^100%$/
				],
				bool: [
					/^(?:yes|no)$/,
					/^(?:true|false)$/,
					/^(?:1|0)$/
				]
			};

		if (typeof(mask) === 'string') {
			mask = masks[mask];
		} else {
			mask = mask || [];
		}

		return mask.some(function(m) {
			return v.match(m);
		});
	}

	var setParams = {
		manualy: function(v, mask, func) {
			if (validity(v, mask)) {
				if (func) {
					return func(v);
				} else {
					return v;
				}
			} else {
				CreateParams.prototype.validityErr.push('Указано не валидное значение размера: "' + v + '"');
			}
		},
		reference: function(v) {
			if (!v) {
				return false;
			} else if (v === 'https://ads.adfox.ru/249922/goLink?hash=c438bf280aed8bae&sj=Vpka6RxPPZlWZlUtWnYP7LGD48K1tDS9aNPGmFXW7NB4dp9dAPiLWq5TIe-EIdLZayoHeindHSR7ySCXM96Jf4cGnA6YsKFD4zW6z4gzDA%3D%3D&ad-session-id=3166421531594062100&p2=fkam&ybv=0.906&ylv=0.906&ytt=1573&pr=iqrexht&p1=bwcxa&p5=fiaxf&rand=fkcpozx&rqs=9olYHwwAAABJRUpbOxECUVMzE1w5PheR') {
				return {
					url: 'https://ads.adfox.ru/249922/goLink?hash=c438bf280aed8bae&sj=Vpka6RxPPZlWZlUtWnYP7LGD48K1tDS9aNPGmFXW7NB4dp9dAPiLWq5TIe-EIdLZayoHeindHSR7ySCXM96Jf4cGnA6YsKFD4zW6z4gzDA%3D%3D&ad-session-id=3166421531594062100&p2=fkam&ybv=0.906&ylv=0.906&ytt=1573&pr=iqrexht&p1=bwcxa&p5=fiaxf&rand=fkcpozx&rqs=9olYHwwAAABJRUpbOxECUVMzE1w5PheR',
					urlEnc: 'https%3A%2F%2Fads.adfox.ru%2F249922%2FgoLink%3Fhash%3Dc438bf280aed8bae%26sj%3DVpka6RxPPZlWZlUtWnYP7LGD48K1tDS9aNPGmFXW7NB4dp9dAPiLWq5TIe-EIdLZayoHeindHSR7ySCXM96Jf4cGnA6YsKFD4zW6z4gzDA%253D%253D%26ad-session-id%3D3166421531594062100%26p2%3Dfkam%26ybv%3D0.906%26ylv%3D0.906%26ytt%3D1573%26pr%3Diqrexht%26p1%3Dbwcxa%26p5%3Dfiaxf%26rand%3Dfkcpozx%26rqs%3D9olYHwwAAABJRUpbOxECUVMzE1w5PheR'
				}
			} else {
				return {
					url: 'https://ads.adfox.ru/249922/goLink?hash=c438bf280aed8bae&sj=Vpka6RxPPZlWZlUtWnYP7LGD48K1tDS9aNPGmFXW7NB4dp9dAPiLWq5TIe-EIdLZayoHeindHSR7ySCXM96Jf4cGnA6YsKFD4zW6z4gzDA%3D%3D&ad-session-id=3166421531594062100&p2=fkam&ybv=0.906&ylv=0.906&ytt=1573&pr=iqrexht&p1=bwcxa&p5=fiaxf&rand=fkcpozx&rqs=9olYHwwAAABJRUpbOxECUVMzE1w5PheR@' + v,
					urlEnc: 'https%3A%2F%2Fads.adfox.ru%2F249922%2FgoLink%3Fhash%3Dc438bf280aed8bae%26sj%3DVpka6RxPPZlWZlUtWnYP7LGD48K1tDS9aNPGmFXW7NB4dp9dAPiLWq5TIe-EIdLZayoHeindHSR7ySCXM96Jf4cGnA6YsKFD4zW6z4gzDA%253D%253D%26ad-session-id%3D3166421531594062100%26p2%3Dfkam%26ybv%3D0.906%26ylv%3D0.906%26ytt%3D1573%26pr%3Diqrexht%26p1%3Dbwcxa%26p5%3Dfiaxf%26rand%3Dfkcpozx%26rqs%3D9olYHwwAAABJRUpbOxECUVMzE1w5PheR@' + encodeURIComponent(v)
				}
			}
		},
		size: function(v) {
			if (validity(v, 'size')) {
				return {
					style: ( v.indexOf('%') != -1 ? v : parseInt(v)+'px' ),
					attribute: ( v.indexOf('%') != -1 ? v : parseInt(v) )
				};
			} else {
				CreateParams.prototype.validityErr.push('Указано не валидное значение размера: "' + v + '"');
			}
		},
		bool: function(v) {
			if (validity(v, 'bool')) {
				if (v.indexOf('yes') != -1 || v.indexOf('true') != -1 || v.indexOf('1') != -1) {
					return true;
				} else {
					return false;
				}
			} else {
				CreateParams.prototype.validityErr.push('Указано не валидное значение размера: "' + v + '"');
			}
		},
		func: function(v) {
			if (v && typeof(CreateParams.prototype.win[v]) !== 'undefined') {
				return CreateParams.prototype.win[v];
			} else {
				return function(){};
			}
		}
	};

	for (var i in data) {
		if (typeof(data[i].type) !== 'undefined') {
			this[i] = setParams[data[i].type](data[i].value);
		} else if (typeof(data[i].validity) !== 'undefined') {
			this[i] = setParams.manual(data[i].value, data[i].validity, data[i].func);
		} else {
			this[i] = data[i].value;
		}
	}
}
	var Tools = function() {
	/* global.tools v1.1.2 */
	this.getNewValuesFaces = function(fromX, fromY, toX, toY) {
		var
			p = parseInt,
			ratio = Math.min(
				fromX === '100%' || p(toX)/p(fromX),
				fromY === '100%' || p(toY)/p(fromY),
				1
			),
			res = [fromX, fromY].map(function (value) {
				return value === '100%' ? value : Math.ceil(p(value)*ratio) + 'px';
			});

		return {
			w: res[0],
			h: res[1]
		}

	};

	this.addEvent = function(elem, eventType, eventHandler) {
		if (typeof(eventType) === 'object') {
			eventType.map(setEvent);
		} else {
			setEvent(eventType);
		}

		function setEvent(v) {
			if(elem.addEventListener) {
				elem.addEventListener(v, eventHandler, false);
			} else if(elem.attachEvent)	{
				elem.attachEvent('on' + v, eventHandler);
			}
		}

	};

	this.removeEvent = function(elem, eventType, eventHandler) {
		if (typeof(eventType) === 'object') {
			eventType.map(delEvent);
		} else {
			delEvent(eventType);
		}

		function delEvent(v) {
			if(elem.removeEventListener) {
				elem.removeEventListener(v, eventHandler, false);
			} else if(elem.detachEvent)	{
				elem.detachEvent('on' + v, eventHandler);
			}
		}

	};

	this.checkSupportHTML5 = function() {
		return !!document.createElement('canvas').getContext && !(navigator.userAgent.indexOf('MSIE 9.0')+1) && !(navigator.userAgent.indexOf('Presto')+1);

	};

	this.cl = function(message) {
		var div = document.createElement('div');
		div.innerHTML = message;
		console.log(div.innerHTML);

	};

	this.preventAction = function(evnt) {
		var 
			e = evnt || _win.event;

		e.preventDefault();
	}
}
	var CreateHTML = function() {
	this.getHtml = function(data) {
		return createHTML(data);
	}

	this.getDOMElement = function(data) {
		return createDOMElement(data);
	}

	function createHTML(data) {
		var html = '';
		var attr, style, inner, close;

		for (var i = 0; i < data.length; i++) {
			attr = '';
			if (typeof(data[i].attributes) !== 'undefined') {
				attr = createAttributesHTML(data[i].attributes);
			}

			style = '';
			if (typeof(data[i].style) !== 'undefined') {
				style = createStyleHTML(data[i].style);
			}

			close = '';
			inner = '';
			if (typeof(data[i].inner) !== 'undefined') {
				close = '</' + data[i].tagName + '>';
				if (typeof(data[i].inner) === 'string') {
					inner = data[i].inner;
				} else if (data[i].inner.length > 0) {
					inner = createHTML(data[i].inner);
				}
			}

			html += '<' + data[i].tagName + attr + style + '>' + inner + close;
		}

		return html;
	}

	function createDOMElement(data, d) {
		var d = d || document;
		var fragment = d.createDocumentFragment();
		var element;

		for (var i = 0; i < data.length; i++) {
			element = d.createElement(data[i].tagName);

			if (typeof(data[i].attributes) !== 'undefined') {
				createAttributesElement(element, data[i].attributes);
			}

			if (typeof(data[i].style) !== 'undefined') {
				createStyleElement(element, data[i].style);
			}

			if (typeof(data[i].inner) !== 'undefined') {
				if (typeof(data[i].inner) === 'string') {
					element.innerHTML = data[i].inner;
				} else if (data[i].inner.length > 0) {
					element.appendChild(createDOMElement(data[i].inner));
				}
			}

			fragment.appendChild(element);
		}

		return fragment;
	}

	function createAttributesHTML(data) {
		var attr = '';
		for (var key in data) {
			if (key === 'className') {
				data['class'] = data[key];
				key = 'class';
			}
			attr += ' ' + convertCamelToKebab(key) + '="' + data[key] + '"';
		}
		return attr;
	}

	function createStyleHTML(data) {
		var style = '';

		style += ' style="' + getStyleText(data) + '"';

		return style;
	}

	function getStyleText(data) {
		var style = '';
		if (typeof(data.cssText) !== 'undefined') {
			style += (data.cssText + ';').replace(';;', ';');
		}

		for (var key in data) {
			if (key === 'cssText') {
				continue;
			}
			style += ' ' + convertCamelToKebab(key) + ': ' + data[key] + ';'
		}
		return style;
	}

	function createAttributesElement(element, data) {
		for (var key in data) {
			if (key === 'className') {
				data['class'] = data[key];
				key = 'class';
			}
			element.setAttribute(convertCamelToKebab(key), data[key]);
		}
	}

	function createStyleElement(element, data) {
		element.style.cssText = getStyleText(data);
	}

	function convertCamelToKebab (str) {
		return str.replace(/([A-Z])/, function(x) {
			return '-' + x.toLowerCase();
		});
	}
}

	var banner = new Banner();
	var tools = new Tools();
	var createHTML = new CreateHTML();
	banner.init();
	var params = new CreateParams(data);
	if (params.validityErr.length) {
		params.validityErr.map(function(v, div) {
			tools.cl(v);
		});
		return;
	}
        
        if(params.cssFile == '')
        {
               params.cssFile = 'https://pano.img.ria.ru/adfox/css/all_partners.css?rnd=![rnd]';    
        }

	var dataHTMLObject = [];
	var bannerHTMLObject = [{
		tagName: 'link',
		attributes: {
			rel: 'stylesheet',
			type: 'text/css',
			href: params.cssFile
		}
	}, {
		tagName: 'div',
		attributes: {
			className: params.cssClassName
		},
		inner: [{
			tagName: 'div',
			attributes: {
				className: 'tiz_block0_wrap0_03102016'
			},
			inner: [{
				tagName: 'div',
				attributes: {
					className: 'tiz_block0_wrap_03102016'
				},
				inner: [{
					tagName: 'div',
					attributes: {
						className: 'tiz_block0_header_03102016',
					},
					inner: [{
						tagName: 'div',
						attributes: {
							className: 'logo_tiz_block0_header_03102016'
						},
						inner: ( params.titleImage ? [{
							tagName: 'img',
							attributes: {
								src: params.titleImage
							}
						}] : params.titleText)
					}]
				}, {
					tagName: 'div',
					attributes: {
						className: 'tiz_block0_frame_03102016'
					},
					inner: dataHTMLObject
				}]
			}]
		}]
	}];

	self.addSection = function(data) {
		dataHTMLObject.push(data);
		if (--params.i === 0) {
			self.runBanner();
		} else {
			getData();
		}
	}

	self.runBanner = function() {
		banner.htmlDOM = createHTML.getDOMElement(bannerHTMLObject, parent.document);
		params.wrapper.appendChild(banner.htmlDOM);
	}

	function getData() {
		var e = document.getElementsByTagName('script')[0];
		var pr = parent.pr || Math.floor(Math.random() * 4294967295) + 1;
		var pr1 = Math.floor(Math.random() * 4294967295) + 1;
		var addate = new Date();
		var dl = encodeURIComponent(parent.document.location);
		var afReferrer = parent.afReferrer || '';
		var scrheight = '', scrwidth = '';
		if (parent.screen) {
			scrwidth = parent.screen.width;
			scrheight = parent.screen.height;
		} else if (parent.java) {
			var jkit = parent.java.awt.Toolkit.getDefaultToolkit();
			var scrsize = jkit.getScreenSize();
			scrwidth = scrsize.width;
			scrheight = scrsize.height;
		}	
		var url = params.url + '&pr=' + pr +
			'&pt=b&pd=' + addate.getDate() +
			'&pw=' + addate.getDay() +
			'&pv=' + addate.getHours() +
			'&prr=' + afReferrer +
			'&puid1=&puid2=&puid3=&puid4=&puid6=' +
			'&pdw=' +scrwidth +
			'&pdh=' + scrheight +
			'&dl=' + dl +
			'&pr1=' + pr1;

		e.parentNode.appendChild(createHTML.getDOMElement([{
			tagName: 'script',
			attributes: {
				type: 'text/javascript',
				src: url
			}
		}]));
	}

	getData();
})();