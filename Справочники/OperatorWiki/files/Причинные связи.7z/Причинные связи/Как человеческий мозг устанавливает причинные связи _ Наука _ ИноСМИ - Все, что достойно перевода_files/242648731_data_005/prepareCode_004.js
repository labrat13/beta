if (window.addSection) {

var lid = '';

if(lid != ''){
        lid = '<b>'+lid+'</b><br>';
}

addSection({
	tagName: 'div',
	attributes: {
		className: 'tiz_block0_item_03102016'
	},
	inner: [{
		tagName: 'a',
		attributes: {
			className: 'tiz_block0_a1_03102016',
			target: '_blank',
			href: 'https://ads.adfox.ru/249922/goLink?hash=b386845e476feafc&rqs=9olYHwwAAABORUpb3T5K72c-aWvoONOB&pr=babwuzu&sj=u045lFIBA_6WtxxIudx8oilVwTpXe5O1XH9nTR33Oe-_pYAyf4K8QAJalPDyapkDG9fSVuUZ_uUM9S-bFccqyqjFItGg0XDRTjSMJRwpQA%3D%3D&p2=flqy&rand=bpzbive&p1=bwdqb&p5=frqpo@http://russian.people.com.cn/n3/2018/0711/c31520-9479748.html'
		},
		inner: [{
			tagName: 'img',
			attributes: {
				src: 'https://banners.adfox.ru/180712/adfox/639638/2594892_3.jpg'
			}
		}]
	}, {
		tagName: 'a',
		attributes: {
			className: 'tiz_block0_a2_03102016',
			target: '_blank',
			href: 'https://ads.adfox.ru/249922/goLink?hash=b386845e476feafc&rqs=9olYHwwAAABORUpb3T5K72c-aWvoONOB&pr=babwuzu&sj=u045lFIBA_6WtxxIudx8oilVwTpXe5O1XH9nTR33Oe-_pYAyf4K8QAJalPDyapkDG9fSVuUZ_uUM9S-bFccqyqjFItGg0XDRTjSMJRwpQA%3D%3D&p2=flqy&rand=bpzbive&p1=bwdqb&p5=frqpo@http://russian.people.com.cn/n3/2018/0711/c31520-9479748.html'
		},
		inner: lid+'Завершено смыкание Моста дружбы Китая и Мальдив'
	}]
});
} else {
	document.write('<a href="http://russian.people.com.cn/n3/2018/0711/c31520-9479748.html" target="_blank">' +
		'	<img src="https://banners.adfox.ru/180712/adfox/639638/2594892_3.jpg">' +
		'</a>' +
		'<a href="http://russian.people.com.cn/n3/2018/0711/c31520-9479748.html" target="_blank">' +
		'	Завершено смыкание Моста дружбы Китая и Мальдив' +
		'</a>');
}
if (window.location.hostname === 'www.preview-adfox.ru') {
var div = document.createElement('div');
   div.innerHTML='<span style="">http://russian.people.com.cn/n3/2018/0711/c31520-9479748.html</span><br>';
document.body.appendChild(div);
}