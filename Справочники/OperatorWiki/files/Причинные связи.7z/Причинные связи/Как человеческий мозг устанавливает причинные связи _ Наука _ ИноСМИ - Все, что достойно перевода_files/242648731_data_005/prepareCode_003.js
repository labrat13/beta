if (window.addSection) {

var lid = '';

if(lid != ''){
        lid = '<b>'+lid+'</b><br>';
}

addSection({
	tagName: 'div',
	attributes: {
		className: 'tiz_block0_item_03102016'
	},
	inner: [{
		tagName: 'a',
		attributes: {
			className: 'tiz_block0_a1_03102016',
			target: '_blank',
			href: 'https://ads.adfox.ru/249922/goLink?hash=7af2b4f78ebcee18&rqs=9olYHwwAAABMRUpbF4BI72qnJ3Jd4VlP&pr=babwuzu&sj=I8Ufl7Ea5znVfyAwP2lIf020mnBHly8HORrmC1svFEv_nI3L_MZ8W4ydZoJG545mxxFRrNRJifKCj-62Mi9urbKyHVwA8KEXUo-onKOZlQ%3D%3D&p2=flqy&rand=fdarown&p1=bwdqb&p5=frqpp@http://russian.people.com.cn/n3/2018/0711/c31516-9479819.html'
		},
		inner: [{
			tagName: 'img',
			attributes: {
				src: 'https://banners.adfox.ru/180712/adfox/639638/2594893_3.jpg'
			}
		}]
	}, {
		tagName: 'a',
		attributes: {
			className: 'tiz_block0_a2_03102016',
			target: '_blank',
			href: 'https://ads.adfox.ru/249922/goLink?hash=7af2b4f78ebcee18&rqs=9olYHwwAAABMRUpbF4BI72qnJ3Jd4VlP&pr=babwuzu&sj=I8Ufl7Ea5znVfyAwP2lIf020mnBHly8HORrmC1svFEv_nI3L_MZ8W4ydZoJG545mxxFRrNRJifKCj-62Mi9urbKyHVwA8KEXUo-onKOZlQ%3D%3D&p2=flqy&rand=fdarown&p1=bwdqb&p5=frqpp@http://russian.people.com.cn/n3/2018/0711/c31516-9479819.html'
		},
		inner: lid+'В провинции Гуйчжоу отметили Фестиваль драконьих лодок народности мяо'
	}]
});
} else {
	document.write('<a href="http://russian.people.com.cn/n3/2018/0711/c31516-9479819.html" target="_blank">' +
		'	<img src="https://banners.adfox.ru/180712/adfox/639638/2594893_3.jpg">' +
		'</a>' +
		'<a href="http://russian.people.com.cn/n3/2018/0711/c31516-9479819.html" target="_blank">' +
		'	В провинции Гуйчжоу отметили Фестиваль драконьих лодок народности мяо' +
		'</a>');
}
if (window.location.hostname === 'www.preview-adfox.ru') {
var div = document.createElement('div');
   div.innerHTML='<span style="">http://russian.people.com.cn/n3/2018/0711/c31516-9479819.html</span><br>';
document.body.appendChild(div);
}